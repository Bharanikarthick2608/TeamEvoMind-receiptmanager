from fastapi import FastAPI, UploadFile, File, HTTPException, Request
from fastapi.responses import JSONResponse, HTMLResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import os
import tempfile
import json
import uuid
import asyncio
from typing import Dict, Any, List
import uvicorn
import sys

# Add the parent directory to Python path to import module1
def setup_module_imports():
    """Set up imports for module1.py with robust path handling."""
    try:
        parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        if parent_dir not in sys.path:
            sys.path.append(parent_dir)
        print(f"📦 Added to Python path: {parent_dir}")
        return True
    except Exception as e:
        print(f"❌ Failed to set up module imports: {e}")
        return False

# Set up imports
setup_module_imports()
from module1 import TextExtractorProcessor, process_receipt_to_wallet, process_receipt_to_database, process_receipt_with_analysis, process_receipt_with_wallet_and_analysis, get_currency_symbol
import sys
import os

# Add the parent directory to import SpendAnalysis
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if parent_dir not in sys.path:
    sys.path.append(parent_dir)

from SpendAnalysis import SpendingAnalyzer, get_spending_dashboard, get_spending_insights
from offersandsavings import get_offers_and_savings, get_existing_offers, save_offers_to_cache
from walletpasses import WalletPassesManager
from budgetmanager import BudgetManager

# Import routers and models
from routers import summary, categories, trends, suggestions
from models.summary import SummaryResponse
from models.receipt import Receipt, Item
from models.trend import TrendPoint, Transaction
from firestore_client import db

# ===== CHATBOT IMPORTS =====
# Google Cloud imports for chatbot
from google.cloud import speech, texttospeech
from google.cloud import firestore
from google.oauth2 import service_account
import google.genai as genai

# ADK imports for chatbot
try:
    from raseed.customer_service_agent.agent import router_agent
    from raseed.utils import add_user_query_to_history, call_agent_async, add_agent_response_to_history
    from google.genai import types
    from google.adk.runners import Runner
    from google.adk.sessions import InMemorySessionService
    from dotenv import load_dotenv
    CHATBOT_AVAILABLE = True
    print("✅ Chatbot modules imported successfully")
except ImportError as e:
    print(f"⚠️  Chatbot modules not available: {e}")
    CHATBOT_AVAILABLE = False

# Load environment variables for chatbot
try:
    load_dotenv()
except Exception as e:
    print(f"⚠️  Warning: Could not load .env file: {e}")

# ===== CHATBOT GLOBAL VARIABLES =====
session_service = None
SESSION_ID = None
runner = None
TEMP_AUDIO_DIR = None

# Initialize FastAPI app
app = FastAPI(
    title="Rasheed Receipt Management API",
    description="AI-powered receipt processing with Google Wallet integration and Firestore database",
    version="3.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc"
)

# Configure CORS for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify your frontend domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Setup Jinja2 templates
TEMPLATES_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'frontend')
templates = Jinja2Templates(directory=TEMPLATES_PATH)

# Include routers
app.include_router(summary.router, prefix="/api")
app.include_router(categories.router, prefix="/api")
app.include_router(trends.router, prefix="/api")
app.include_router(suggestions.router, prefix="/api")

# Configuration - Robust credentials path resolution
def find_credentials_file():
    """Find the Google Cloud credentials file in multiple possible locations."""
    filename = "project-rasheed-466518-5cdff45af981.json"
    
    # Possible locations to check
    possible_paths = [
        # Relative to backend directory (current approach)
        os.path.join(os.path.dirname(os.path.dirname(__file__)), filename),
        
        # Relative to current working directory
        os.path.join(os.getcwd(), filename),
        
        # In the same directory as this script
        os.path.join(os.path.dirname(__file__), filename),
        
        # One level up from current working directory
        os.path.join(os.path.dirname(os.getcwd()), filename),
        
        # Explicit path based on known structure
        os.path.join(os.path.dirname(__file__), "..", filename),
    ]
    
    print("🔍 Searching for credentials file...")
    for i, path in enumerate(possible_paths, 1):
        abs_path = os.path.abspath(path)
        print(f"   {i}. Checking: {abs_path}")
        if os.path.exists(abs_path):
            print(f"   ✅ Found credentials at: {abs_path}")
            return abs_path
    
    print("   ❌ Credentials file not found in any expected location!")
    print(f"   📁 Current working directory: {os.getcwd()}")
    print(f"   📁 Script directory: {os.path.dirname(__file__)}")
    raise FileNotFoundError(f"Could not find {filename} in any expected location")

# Global configuration variables
CREDENTIALS_PATH = None
PROJECT_ID = "project-rasheed-466518"
ISSUER_ID = "3388000000022971962"

# Initialize processor once on startup
processor = None

# Initialize budget manager
budget_manager = None
wallet_passes_manager = None

async def initialize_chatbot():
    """Initialize the chatbot components."""
    global session_service, SESSION_ID, runner, TEMP_AUDIO_DIR
    
    if not CHATBOT_AVAILABLE:
        print("⚠️  Chatbot not available - skipping initialization")
        return
    
    try:
        print("🤖 Initializing Intelligent Receipt Management Assistant...")
        
        # Create a temporary directory for audio files
        TEMP_AUDIO_DIR = tempfile.mkdtemp(prefix="raseed_voice_chatbot_")
        print(f"📁 Audio files directory: {TEMP_AUDIO_DIR}")
        
        # Initialize In-Memory Session Service
        session_service = InMemorySessionService()
        
        # Get spending data for initial state
        try:
            collection_ref = db.collection("spending_analysis")
            doc_ref = collection_ref.document("current_spending_analysis")
            doc = doc_ref.get()
            
            if doc.exists:
                analysis_data = doc.to_dict()
                spending_summary = analysis_data.get("detailed_summary", "No spending analysis available.")
            else:
                spending_summary = "No spending analysis available."
        except Exception as e:
            print(f"Error getting spending analysis: {e}")
            spending_summary = "No spending analysis available."
        
        # Define initial state
        initial_state = {
            "user_name": "Sundar Pichai",
            "spending_history": spending_summary,
            "interaction_history": [],
        }
        
        # Vertex AI Client Setup
        vertexai_project = os.getenv("GCP_PROJECT_ID") 
        vertexai_location = os.getenv("GCP_REGION") 
        
        client = genai.Client(
            vertexai=True,
            project=vertexai_project,
            location=vertexai_location,
        )
        
        # Agent Runner Setup
        APP_NAME = "Project Raseed"
        USER_ID = "sundarpichai"
        
        # Create initial session
        new_session = await session_service.create_session(
            app_name=APP_NAME,
            user_id=USER_ID,
            state=initial_state,
        )
        SESSION_ID = new_session.id
        print(f"🆔 Created new session: {SESSION_ID}")
        
        # Create a runner with the main customer service agent
        runner = Runner(
            agent=router_agent,
            app_name=APP_NAME,
            session_service=session_service,
        )
        
        print("✅ Intelligent Receipt Management Assistant initialized successfully!")
        
    except Exception as e:
        print(f"❌ Error initializing chatbot: {e}")
        session_service = None
        SESSION_ID = None
        runner = None
        TEMP_AUDIO_DIR = None

async def generate_agent_response(user_input: str) -> str:
    """Generate bot response using the ADK router agent"""
    try:
        # Check if session is initialized
        if SESSION_ID is None or runner is None:
            return "I'm still initializing. Please try again in a moment."
        
        # Update interaction history with the user's query
        add_user_query_to_history(
            session_service, "Project Raseed", "sundarpichai", SESSION_ID, user_input
        )
        
        # Process the user query through the agent
        content = types.Content(role="user", parts=[types.Part(text=user_input)])
        final_response_text = None
        agent_name = None
        
        print(f"\n--- Processing Query: {user_input} ---")
        
        async for event in runner.run_async(
            user_id="sundarpichai", session_id=SESSION_ID, new_message=content
        ):
            # Capture the agent name from the event if available
            if event.author:
                agent_name = event.author
            
            # Process agent response
            if event.is_final_response():
                if (
                    event.content
                    and event.content.parts
                    and hasattr(event.content.parts[0], "text")
                    and event.content.parts[0].text
                ):
                    final_response_text = event.content.parts[0].text.strip()
                    print(f"Agent Response: {final_response_text}")
        
        # Add the agent response to interaction history if we got a final response
        if final_response_text and agent_name:
            add_agent_response_to_history(
                session_service,
                "Project Raseed",
                "sundarpichai",
                SESSION_ID,
                agent_name,
                final_response_text,
            )
        
        # Return the response or a fallback
        if final_response_text:
            return final_response_text
        else:
            return "I'm sorry, I couldn't process your request at the moment. Please try again."
        
    except Exception as e:
        print(f"Error generating agent response: {e}")
        return f"I encountered an error while processing your request: {str(e)}"

@app.on_event("startup")
async def startup_event():
    """Initialize the TextExtractorProcessor and chatbot on startup."""
    global processor, wallet_passes_manager, budget_manager, CREDENTIALS_PATH
    
    try:
        # Find credentials file during startup
        print("🚀 Initializing Rasheed Receipt Management System...")
        CREDENTIALS_PATH = find_credentials_file()
        
        # Initialize the processor
        processor = TextExtractorProcessor(CREDENTIALS_PATH, PROJECT_ID)
        print("✅ TextExtractorProcessor initialized successfully")
        print("✅ Google Cloud services connected")
        print("✅ Firestore database connected")
        print("✅ Google Wallet API ready")
        
        # Initialize the wallet passes manager
        wallet_passes_manager = WalletPassesManager(CREDENTIALS_PATH, PROJECT_ID)
        print("✅ WalletPassesManager initialized successfully")
        
        # Initialize the budget manager
        budget_manager = BudgetManager(CREDENTIALS_PATH, PROJECT_ID)
        print("✅ BudgetManager initialized successfully")
        
        # Initialize the chatbot
        await initialize_chatbot()
        
    except FileNotFoundError as e:
        print(f"❌ Credentials file not found: {e}")
        print("💡 Make sure 'project-rasheed-466518-5cdff45af981.json' is in the correct location")
        processor = None
        wallet_passes_manager = None
        budget_manager = None
        
    except Exception as e:
        print(f"❌ Failed to initialize processor: {e}")
        print("💡 Check your Google Cloud credentials and project configuration")
        processor = None
        wallet_passes_manager = None
        budget_manager = None

@app.get("/api/health")
async def health_check():
    """Health check endpoint with system status."""
    from datetime import datetime
    
    # Check system components
    credentials_status = "found" if CREDENTIALS_PATH and os.path.exists(CREDENTIALS_PATH) else "missing"
    processor_status = "initialized" if processor else "failed"
    chatbot_status = "available" if CHATBOT_AVAILABLE and SESSION_ID else "unavailable"
    
    return {
        "status": "healthy" if processor else "degraded",
        "service": "Rasheed Receipt Management API",
        "version": "3.0.0",
        "timestamp": datetime.now().isoformat(),
        "components": {
            "credentials_file": credentials_status,
            "processor": processor_status,
            "google_cloud": "connected" if processor else "disconnected",
            "firestore": "connected" if processor else "disconnected",
            "google_wallet": "connected" if processor else "disconnected",
            "chatbot": chatbot_status
        },
        "credentials_path": CREDENTIALS_PATH if CREDENTIALS_PATH else "not found",
        "project_id": PROJECT_ID,
        "issuer_id": ISSUER_ID,
        "chatbot": {
            "available": CHATBOT_AVAILABLE,
            "session_id": SESSION_ID,
            "status": chatbot_status
        }
    }

@app.get("/api/")
async def api_root():
    """API information endpoint."""
    return {
        "service": "Rasheed Receipt Management API",
        "version": "3.0.0",
        "description": "AI-powered receipt processing with Google Wallet integration and Intelligent Receipt Management Assistant",
        "endpoints": {
            "POST /api/receipt/process": "Full processing with wallet pass, database saving, and automatic spending analysis",
            "POST /api/receipt/process-simple": "Process without wallet pass, save to database with automatic spending analysis",
            "POST /api/receipt/process-no-save": "Process only without saving anywhere",
            "GET /api/receipts": "Get all saved receipts from database",
            "GET /api/receipts/{receipt_id}": "Get specific receipt by ID",
            "POST /api/analytics/generate": "Manually trigger spending analysis generation",
            "GET /api/analytics/summary": "Get spending analytics summary (LLM-generated or manual fallback)",
            "GET /api/analytics/dashboard": "Get complete spending dashboard with charts and insights",
            "GET /api/analytics/insights": "Get spending insights only",
            "GET /api/wallet/passes": "Get wallet passes information",
            "GET /api/offers/savings": "Get offers and savings analysis",
            "POST /api/offers/refresh": "Refresh offers and savings analysis",
            "POST /api/chat/process_speech": "Process text input and return bot response with audio",
            "POST /api/chat/process_audio": "Process audio file and return bot response with audio",
            "GET /api/chat/get_audio/{filename}": "Serve audio files from chatbot",
            "GET /api/chat/session_state": "Get current chatbot session state",
            "GET /api/chat/health": "Health check for chatbot"
        },
        "documentation": {
            "swagger": "/api/docs",
            "redoc": "/api/redoc"
        },
        "features": {
            "receipt_processing": True,
            "wallet_integration": True,
            "spending_analytics": True,
            "chatbot": CHATBOT_AVAILABLE
        }
    }

@app.post("/api/receipt/process")
async def process_receipt_full(
    file: UploadFile = File(...),
    save_to_database: bool = True,
    create_wallet_pass: bool = True
):
    """
    Full receipt processing with all features.
    
    Args:
        file: Uploaded receipt image or video file
        save_to_database: Whether to save to Firestore database
        create_wallet_pass: Whether to create Google Wallet pass
    
    Returns:
        JSON with processed data, wallet link (if requested), and database ID (if saved)
    """
    print(f"🔍 Processing receipt: {file.filename}")
    print(f"🔍 File content type: {file.content_type}")
    print(f"🔍 Save to database: {save_to_database}")
    print(f"🔍 Create wallet pass: {create_wallet_pass}")
    
    if not processor:
        raise HTTPException(
            status_code=503, 
            detail="Service not initialized properly. Check server logs for Google Cloud credentials and configuration issues."
        )
    
    # Handle missing filename
    if not file.filename:
        file.filename = "uploaded_receipt.jpg"
    
    # Validate file type
    allowed_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', '.webp', '.mp4', '.avi', '.mov', '.wmv', '.flv', '.webm', '.mkv'}
    file_ext = os.path.splitext(file.filename.lower())[1]
    
    if file_ext not in allowed_extensions:
        raise HTTPException(
            status_code=400, 
            detail=f"Unsupported file type: {file_ext}. Supported types: {', '.join(allowed_extensions)}"
        )
    
    try:
        # Save uploaded file temporarily
        temp_dir = tempfile.mkdtemp()
        temp_file_path = os.path.join(temp_dir, file.filename)
        
        with open(temp_file_path, "wb") as temp_file:
            content = await file.read()
            temp_file.write(content)
        
        print(f"✅ File saved temporarily: {temp_file_path}")
        
        # Process based on requirements with automatic spending analysis
        if create_wallet_pass:
            # Full processing with wallet pass and spending analysis
            print("🔄 Processing with wallet pass and spending analysis...")
            combined_result = process_receipt_with_wallet_and_analysis(temp_file_path, ISSUER_ID, CREDENTIALS_PATH)
            result = combined_result["receipt_processing"]  # Return only receipt data to frontend
            # Spending analysis is automatically saved to Firestore in background
        elif save_to_database:
            # Process and save to database with spending analysis
            print("🔄 Processing with database save and spending analysis...")
            combined_result = process_receipt_with_analysis(temp_file_path, CREDENTIALS_PATH)
            result = combined_result["receipt_processing"]  # Return only receipt data to frontend
            # Spending analysis is automatically saved to Firestore in background
        else:
            # Process only, no saving
            result = processor.process_input(temp_file_path, save_to_firestore=False)
        
        # Add processing metadata
        result["processing_options"] = {
            "save_to_database": save_to_database,
            "create_wallet_pass": create_wallet_pass,
            "file_name": file.filename,
            "file_size": len(content),
            "file_type": file.content_type
        }
        
        # Clean up temp file
        try:
            os.remove(temp_file_path)
            os.rmdir(temp_dir)
        except:
            pass
        
        print("✅ Receipt processing completed successfully")
        return JSONResponse(content=result)
        
    except Exception as e:
        print(f"❌ Error processing receipt: {e}")
        # Clean up temp file on error
        try:
            if 'temp_file_path' in locals():
                os.remove(temp_file_path)
                os.rmdir(temp_dir)
        except:
            pass
        
        raise HTTPException(status_code=500, detail=f"Processing failed: {str(e)}")

@app.post("/api/receipt/process-simple")
async def process_receipt_simple(file: UploadFile = File(...)):
    """Process receipt and save to database without creating wallet pass."""
    return await process_receipt_full(file, save_to_database=True, create_wallet_pass=False)

@app.post("/api/receipt/process-no-save")
async def process_receipt_no_save(file: UploadFile = File(...)):
    """Process receipt without saving to database or creating wallet pass."""
    return await process_receipt_full(file, save_to_database=False, create_wallet_pass=False)

@app.get("/api/receipts")
async def get_all_receipts(limit: int = 50, offset: int = 0):
    """
    Retrieve all receipts from Firestore database.
    
    Args:
        limit: Maximum number of receipts to return (default: 50)
        offset: Number of receipts to skip (default: 0)
    
    Returns:
        JSON with list of receipts and pagination info
    """
    if not processor:
        raise HTTPException(status_code=503, detail="Service not initialized")
    
    try:
        # Get receipts from Firestore
        receipts_ref = processor.firestore_client.collection("Receipts detail")
        
        # Apply pagination
        query = receipts_ref.order_by("processing_timestamp", direction="DESCENDING").limit(limit).offset(offset)
        docs = query.stream()
        
        receipts = []
        for doc in docs:
            receipt_data = doc.to_dict()
            receipt_data["id"] = doc.id
            receipts.append(receipt_data)
        
        # Get total count (this is expensive, consider caching in production)
        total_count = len(list(receipts_ref.stream()))
        
        return {
            "receipts": receipts,
            "pagination": {
                "total": total_count,
                "limit": limit,
                "offset": offset,
                "has_more": offset + limit < total_count
            }
        }
        
    except Exception as e:
        print(f"❌ Error retrieving receipts: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve receipts: {str(e)}")

@app.get("/api/receipts/{receipt_id}")
async def get_receipt_by_id(receipt_id: str):
    """
    Get a specific receipt by ID.
    
    Args:
        receipt_id: The receipt ID to retrieve
    
    Returns:
        JSON with receipt data
    """
    if not processor:
        raise HTTPException(status_code=503, detail="Service not initialized")
    
    try:
        doc_ref = processor.firestore_client.collection("Receipts detail").document(receipt_id)
        doc = doc_ref.get()
        
        if not doc.exists:
            raise HTTPException(status_code=404, detail=f"Receipt {receipt_id} not found")
        
        receipt_data = doc.to_dict()
        receipt_data["id"] = doc.id
        
        return receipt_data
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Error retrieving receipt {receipt_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve receipt: {str(e)}")

@app.post("/api/analytics/generate")
async def generate_spending_analysis():
    """
    Manually trigger spending analysis generation.
    This will fetch all receipts from Firestore and generate a new analysis using Gemini LLM.
    
    Returns:
        JSON with the generated spending analysis
    """
    if not processor:
        raise HTTPException(status_code=503, detail="Service not initialized")
    
    try:
        print("🔄 Manually triggering spending analysis generation...")
        
        # Generate spending analysis using the processor
        analysis_result = processor.generate_spending_analysis()
        
        return {
            "message": "Spending analysis generated successfully",
            "analysis_id": analysis_result.get("analysis_id"),
            "analysis_timestamp": analysis_result.get("analysis_timestamp"),
            "firestore_document_id": analysis_result.get("firestore_document_id"),
            "summary": {
                "total_receipts": analysis_result.get("total_receipts", 0),
                "total_spending": analysis_result.get("total_spending", 0),
                "average_receipt": analysis_result.get("average_receipt_value", 0)
            }
        }
        
    except Exception as e:
        print(f"❌ Error generating spending analysis: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to generate spending analysis: {str(e)}")

@app.get("/api/analytics/summary")
async def get_analytics_summary():
    """
    Get spending analytics summary from the latest analysis in Firestore.
    
    Returns:
        JSON with analytics data including totals, categories, trends
    """
    if not processor:
        raise HTTPException(status_code=503, detail="Service not initialized")
    
    try:
        # Try to get the latest spending analysis from Firestore
        analysis_doc = processor.firestore_client.collection("spending_analysis").document("current_spending_analysis").get()
        
        if analysis_doc.exists:
            # Use the LLM-generated analysis
            analysis_data = analysis_doc.to_dict()
            return {
                "source": "llm_analysis",
                "analysis_id": analysis_data.get("analysis_id"),
                "analysis_timestamp": analysis_data.get("analysis_timestamp"),
                "summary": {
                    "total_receipts": analysis_data.get("total_receipts", 0),
                    "total_spending": analysis_data.get("total_spending", 0),
                    "average_receipt": analysis_data.get("average_receipt_value", 0),
                    "categories_count": len(analysis_data.get("category_totals", {})),
                    "currency": list(analysis_data.get("currency_breakdown", {}).keys())[0] if analysis_data.get("currency_breakdown") else "USD"
                },
                "category_breakdown": analysis_data.get("category_totals", {}),
                "category_percentages": analysis_data.get("category_percentages", {}),
                "merchant_analysis": {
                    "merchant_totals": analysis_data.get("merchant_totals", {}),
                    "top_merchant": [analysis_data.get("top_merchant_name", ""), analysis_data.get("top_merchant_amount", 0)]
                },
                "monthly_analysis": {
                    "monthly_totals": analysis_data.get("monthly_totals", {}),
                    "highest_spending_month": [analysis_data.get("highest_spending_month", ""), analysis_data.get("highest_spending_month_amount", 0)]
                },
                "spending_insights": {
                    "highest_category": [analysis_data.get("highest_category_name", ""), analysis_data.get("highest_category_amount", 0)],
                    "lowest_category": [analysis_data.get("lowest_category_name", ""), analysis_data.get("lowest_category_amount", 0)],
                    "most_frequent_merchant": [analysis_data.get("most_frequent_merchant_name", ""), analysis_data.get("most_frequent_merchant_amount", 0)]
                },
                "detailed_summary": analysis_data.get("detailed_summary", ""),
                "saving_suggestion": analysis_data.get("saving_suggestion", ""),
                "generated_at": analysis_data.get("analysis_timestamp")
            }
        else:
            # Fallback to manual calculation if no LLM analysis exists
            return await _generate_manual_analytics()
        
    except Exception as e:
        print(f"❌ Error retrieving analytics: {e}")
        # Fallback to manual calculation
        return await _generate_manual_analytics()

async def _generate_manual_analytics():
    """Fallback method to generate analytics manually if LLM analysis is not available."""
    try:
        # Get all receipts for analytics
        receipts_ref = processor.firestore_client.collection("Receipts detail")
        docs = receipts_ref.stream()
        
        total_amount = 0
        category_totals = {}
        receipt_count = 0
        recent_receipts = []
        primary_currency = "USD"  # Default currency
        currency_symbol = "$"  # Default symbol
        
        for doc in docs:
            receipt_data = doc.to_dict()
            receipt_count += 1
            
            # Get currency from first receipt as primary currency
            if receipt_count == 1:
                primary_currency = receipt_data.get("currency", "USD")
                currency_symbol = get_currency_symbol(primary_currency)
            
            # Add to total amount
            try:
                amount = float(receipt_data.get("total_amount", "0").replace("$", "").replace(",", ""))
                total_amount += amount
            except (ValueError, AttributeError):
                pass
            
            # Add to category totals
            category_total = receipt_data.get("category_total", {})
            for category, amount_str in category_total.items():
                try:
                    amount = float(amount_str.replace("$", "").replace(",", ""))
                    category_totals[category] = category_totals.get(category, 0) + amount
                except (ValueError, AttributeError):
                    pass
            
            # Collect recent receipts (limit to last 5)
            if len(recent_receipts) < 5:
                recent_receipts.append({
                    "id": doc.id,
                    "merchant_name": receipt_data.get("merchant_name", "Unknown"),
                    "total_amount": receipt_data.get("total_amount", "0.00"),
                    "date": receipt_data.get("date", "Unknown"),
                    "processing_timestamp": receipt_data.get("processing_timestamp", "")
                })
        
        return {
            "source": "manual_calculation",
            "summary": {
                "total_receipts": receipt_count,
                "total_spending": f"{currency_symbol}{total_amount:.2f}",
                "average_receipt": f"{currency_symbol}{(total_amount / receipt_count if receipt_count > 0 else 0):.2f}",
                "categories_count": len(category_totals),
                "currency": primary_currency
            },
            "category_breakdown": {
                category: f"{currency_symbol}{amount:.2f}" 
                for category, amount in sorted(category_totals.items(), key=lambda x: x[1], reverse=True)
            },
            "recent_receipts": recent_receipts,
            "currency_info": {
                "code": primary_currency,
                "symbol": currency_symbol
            },
            "generated_at": "2024-01-01T00:00:00Z"
        }
        
    except Exception as e:
        print(f"❌ Error generating manual analytics: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to generate analytics: {str(e)}")

@app.get("/api/analytics/dashboard")
async def get_spending_dashboard():
    """
    Get complete spending dashboard with charts and insights.
    
    Returns:
        JSON with complete dashboard data including charts and insights
    """
    if not processor:
        raise HTTPException(status_code=503, detail="Service not initialized")
    
    try:
        print("🔄 Generating spending dashboard...")
        
        # Import the function here to avoid naming conflict
        from SpendAnalysis import get_spending_dashboard as get_dashboard
        
        # Get complete dashboard data using the same credentials path as the main app
        dashboard_data = get_dashboard(CREDENTIALS_PATH)
        
        if "error" in dashboard_data:
            print(f"⚠️  Dashboard error: {dashboard_data['error']}")
            raise HTTPException(status_code=404, detail=dashboard_data["error"])
        
        return dashboard_data
        
    except Exception as e:
        print(f"❌ Error generating spending dashboard: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to generate spending dashboard: {str(e)}")

@app.get("/api/analytics/insights")
async def get_spending_insights():
    """
    Get spending insights only (without charts).
    
    Returns:
        JSON with spending insights
    """
    if not processor:
        raise HTTPException(status_code=503, detail="Service not initialized")
    
    try:
        print("🔄 Generating spending insights...")
        
        # Import the function here to avoid naming conflict
        from SpendAnalysis import get_spending_insights as get_insights
        
        # Get spending insights using the same credentials path as the main app
        insights_data = get_insights(CREDENTIALS_PATH)
        
        if "error" in insights_data:
            print(f"⚠️  Insights error: {insights_data['error']}")
            raise HTTPException(status_code=404, detail=insights_data["error"])
        
        return insights_data
        
    except Exception as e:
        print(f"❌ Error generating spending insights: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to generate spending insights: {str(e)}")

@app.get("/api/wallet/passes")
async def get_wallet_passes():
    """
    Get information about Google Wallet passes.
    
    Returns:
        JSON with wallet passes information
    """
    # This would integrate with Google Wallet API to get actual pass information
    # For now, return mock data based on receipts with wallet links
    
    if not processor:
        raise HTTPException(status_code=503, detail="Service not initialized")
    
    try:
        # Get receipts that have wallet passes
        receipts_ref = processor.firestore_client.collection("Receipts detail")
        query = receipts_ref.where("google_wallet_link", "!=", None)
        docs = query.stream()
        
        wallet_passes = []
        for doc in docs:
            receipt_data = doc.to_dict()
            if receipt_data.get("google_wallet_link"):
                wallet_passes.append({
                    "receipt_id": doc.id,
                    "merchant_name": receipt_data.get("merchant_name", "Unknown"),
                    "total_amount": receipt_data.get("total_amount", "0.00"),
                    "date": receipt_data.get("date", "Unknown"),
                    "wallet_link": receipt_data.get("google_wallet_link"),
                    "status": "active"
                })
        
        return {
            "wallet_passes": wallet_passes,
            "total_passes": len(wallet_passes),
            "issuer_id": ISSUER_ID
        }
        
    except Exception as e:
        print(f"❌ Error retrieving wallet passes: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve wallet passes: {str(e)}")

@app.get("/api/wallet/receipts")
async def get_wallet_receipts(limit: int = 50, offset: int = 0):
    """
    Get all receipts formatted for wallet passes display.
    
    Args:
        limit: Maximum number of receipts to return
        offset: Number of receipts to skip for pagination
    
    Returns:
        JSON with formatted receipts data for wallet passes interface
    """
    if not wallet_passes_manager:
        raise HTTPException(status_code=503, detail="Wallet passes manager not initialized")
    
    try:
        result = wallet_passes_manager.get_all_receipts(limit=limit, offset=offset)
        
        if "error" in result:
            raise HTTPException(status_code=500, detail=result["error"])
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Error retrieving wallet receipts: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve wallet receipts: {str(e)}")

@app.get("/api/wallet/receipts/{receipt_id}")
async def get_wallet_receipt_detail(receipt_id: str):
    """
    Get detailed receipt information for wallet passes preview.
    
    Args:
        receipt_id: The receipt ID to retrieve
    
    Returns:
        JSON with detailed receipt data
    """
    if not wallet_passes_manager:
        raise HTTPException(status_code=503, detail="Wallet passes manager not initialized")
    
    try:
        result = wallet_passes_manager.get_receipt_by_id(receipt_id)
        
        if "error" in result:
            raise HTTPException(status_code=404, detail=result["error"])
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Error retrieving wallet receipt detail: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve receipt detail: {str(e)}")

@app.get("/api/wallet/summary")
async def get_wallet_summary():
    """
    Get summary statistics for wallet passes.
    
    Returns:
        JSON with wallet passes summary data
    """
    if not wallet_passes_manager:
        raise HTTPException(status_code=503, detail="Wallet passes manager not initialized")
    
    try:
        result = wallet_passes_manager.get_wallet_passes_summary()
        
        if "error" in result:
            raise HTTPException(status_code=500, detail=result["error"])
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Error retrieving wallet summary: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve wallet summary: {str(e)}")

@app.delete("/api/receipts/{receipt_id}")
async def delete_receipt(receipt_id: str):
    """
    Delete a specific receipt.
    
    Args:
        receipt_id: The receipt ID to delete
    
    Returns:
        JSON confirmation of deletion
    """
    if not processor:
        raise HTTPException(status_code=503, detail="Service not initialized")
    
    try:
        doc_ref = processor.firestore_client.collection("Receipts detail").document(receipt_id)
        doc = doc_ref.get()
        
        if not doc.exists:
            raise HTTPException(status_code=404, detail=f"Receipt {receipt_id} not found")
        
        doc_ref.delete()
        
        return {
            "message": f"Receipt {receipt_id} deleted successfully",
            "deleted_id": receipt_id
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Error deleting receipt {receipt_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to delete receipt: {str(e)}")

@app.get("/api/offers/savings")
async def get_offers_and_savings_endpoint():
    """
    Get offers and savings analysis based on spending patterns.
    
    Returns:
        JSON with product savings analysis and category offers
    """
    try:
        print("🔄 Fetching offers and savings analysis...")
        
        # First try to get cached data
        cached_data = get_existing_offers()
        
        if cached_data:
            print("✅ Returning cached offers data")
            return {
                "status": "success",
                "source": "cached",
                "data": cached_data.get("data", {"raw_response": "No cached data available"}),
                "timestamp": cached_data.get("timestamp")
            }
        
        # If no cached data, generate new analysis
        print("🔄 Generating new offers and savings analysis...")
        analysis_result = get_offers_and_savings()
        
        if analysis_result.get("status") == "success":
            # Return the raw response directly for simple display
            agent_data = analysis_result.get("data", {})
            raw_response = agent_data.get("raw_response", "No response available")
            
            # Save to cache
            cache_data = {
                "status": "success",
                "data": {"raw_response": raw_response},
                "timestamp": analysis_result.get("timestamp")
            }
            save_offers_to_cache(cache_data)
            
            return {
                "status": "success",
                "source": "fresh_analysis",
                "data": {"raw_response": raw_response},
                "timestamp": analysis_result.get("timestamp")
            }
        else:
            raise HTTPException(
                status_code=500, 
                detail=f"Failed to generate offers analysis: {analysis_result.get('error', 'Unknown error')}"
            )
        
    except Exception as e:
        print(f"❌ Error in offers and savings endpoint: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get offers and savings: {str(e)}")

@app.post("/api/offers/refresh")
async def refresh_offers_and_savings():
    """
    Force refresh of offers and savings analysis.
    
    Returns:
        JSON with fresh offers and savings analysis
    """
    try:
        print("🔄 Forcing refresh of offers and savings analysis...")
        
        # Generate fresh analysis
        analysis_result = get_offers_and_savings()
        
        if analysis_result.get("status") == "success":
            # Return the raw response directly for simple display
            agent_data = analysis_result.get("data", {})
            raw_response = agent_data.get("raw_response", "No response available")
            
            # Save to cache
            cache_data = {
                "status": "success",
                "data": {"raw_response": raw_response},
                "timestamp": analysis_result.get("timestamp")
            }
            save_offers_to_cache(cache_data)
            
            return {
                "status": "success",
                "message": "Offers and savings analysis refreshed successfully",
                "data": {"raw_response": raw_response},
                "timestamp": analysis_result.get("timestamp")
            }
        else:
            raise HTTPException(
                status_code=500, 
                detail=f"Failed to refresh offers analysis: {analysis_result.get('error', 'Unknown error')}"
            )
        
    except Exception as e:
        print(f"❌ Error refreshing offers and savings: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to refresh offers and savings: {str(e)}")

@app.get("/api/debug/routes")
async def debug_routes():
    """Debug endpoint to list all available routes - helpful for troubleshooting."""
    routes = []
    for route in app.routes:
        if hasattr(route, 'methods') and hasattr(route, 'path'):
            routes.append({
                "path": route.path,
                "methods": list(route.methods),
                "name": getattr(route, 'name', 'Unknown')
            })
    
    return {
        "message": "Available API routes",
        "total_routes": len(routes),
        "routes": sorted(routes, key=lambda x: x['path']),
        "note": "Static file serving is mounted at / and comes after API routes"
    }

@app.get("/api/offers/test-adk")
async def test_adk_agent():
    """Test if the ADK agent is working properly."""
    try:
        print("🧪 Testing ADK agent functionality...")
        
        # Import the test function from offersandsavings
        from offersandsavings import get_offers_and_savings
        
        # Run a quick test
        result = get_offers_and_savings()
        
        if result.get("status") == "success":
            return {
                "status": "success",
                "message": "ADK agent is working properly",
                "test_result": {
                    "has_data": "data" in result,
                    "has_timestamp": "timestamp" in result,
                    "response_type": "raw_response" if result.get("data", {}).get("raw_response") else "structured"
                }
            }
        else:
            return {
                "status": "error",
                "message": "ADK agent test failed",
                "error": result.get("error", "Unknown error")
            }
            
    except Exception as e:
        print(f"❌ Error testing ADK agent: {e}")
        return {
            "status": "error",
            "message": f"ADK agent test failed: {str(e)}"
        }

@app.get("/api/offers/debug-data")
async def debug_offers_data():
    """Test data fetching from Firestore and product/category extraction."""
    try:
        print("🔍 Testing data fetching and extraction...")
        
        # Import functions from offersandsavings
        from offersandsavings import fetch_receipt_data, fetch_spending_analysis, extract_products_from_receipts, get_high_spending_categories
        
        # Test data fetching
        receipts = fetch_receipt_data()
        spending_analysis = fetch_spending_analysis()
        
        if not receipts:
            return {
                "status": "error",
                "message": "No receipt data found in Firestore"
            }
        
        # Test extraction
        products = extract_products_from_receipts(receipts)
        categories = get_high_spending_categories(spending_analysis)
        
        return {
            "status": "success",
            "message": "Data fetching and extraction successful",
            "data": {
                "total_receipts": len(receipts),
                "products_found": len(products),
                "categories_found": len(categories),
                "sample_products": products[:3] if products else [],
                "sample_categories": categories[:3] if categories else []
            }
        }
        
    except Exception as e:
        print(f"❌ Error in debug data test: {e}")
        return {
            "status": "error",
            "message": f"Debug data test failed: {str(e)}"
        }

# ===== CHATBOT ENDPOINTS =====

@app.post("/api/chat/process_speech")
async def process_speech(request: Request):
    """Process text input and return bot response"""
    try:
        if not CHATBOT_AVAILABLE:
            raise HTTPException(status_code=503, detail="Chatbot not available")
        
        data = await request.json()
        user_text = data.get("text", "")
        
        if not user_text:
            return JSONResponse({"error": "No text provided"})
        
        # Generate bot response using ADK agent
        bot_response = await generate_agent_response(user_text)
        
        # Text-to-speech conversion
        tts_client = texttospeech.TextToSpeechClient()
        synthesis_input = texttospeech.SynthesisInput(text=bot_response)
        voice = texttospeech.VoiceSelectionParams(
            language_code="en-US", 
            ssml_gender=texttospeech.SsmlVoiceGender.NEUTRAL
        )
        audio_config = texttospeech.AudioConfig(audio_encoding=texttospeech.AudioEncoding.MP3)

        tts_response = tts_client.synthesize_speech(
            input=synthesis_input, 
            voice=voice, 
            audio_config=audio_config
        )

        # Save response audio with unique filename
        audio_filename = f"response_{uuid.uuid4().hex}.mp3"
        audio_path = os.path.join(TEMP_AUDIO_DIR, audio_filename)
        with open(audio_path, "wb") as out:
            out.write(tts_response.audio_content)

        return JSONResponse({
            "status": "success",
            "assistant_message": bot_response,
            "audio_filename": audio_filename
        })
    
    except Exception as e:
        print(f"Error in process_speech endpoint: {str(e)}")
        return JSONResponse({"error": str(e)}, status_code=500)

@app.post("/api/chat/process_audio")
async def process_audio(audio_file: UploadFile = File(...)):
    """Handle audio file upload and return bot response"""
    try:
        if not CHATBOT_AVAILABLE:
            raise HTTPException(status_code=503, detail="Chatbot not available")
        
        # Save uploaded audio file
        with tempfile.NamedTemporaryFile(delete=False, suffix=".webm") as tmp_audio:
            tmp_audio.write(await audio_file.read())
            tmp_audio_path = tmp_audio.name

        # Speech-to-text conversion
        speech_client = speech.SpeechClient()
        with open(tmp_audio_path, "rb") as f:
            audio_data = f.read()

        audio = speech.RecognitionAudio(content=audio_data)
        config = speech.RecognitionConfig(
            encoding=speech.RecognitionConfig.AudioEncoding.WEBM_OPUS,
            language_code="en-US",
            enable_automatic_punctuation=True
        )
        
        response = speech_client.recognize(config=config, audio=audio)

        if not response.results:
            return {"error": "Could not recognize speech"}

        user_text = response.results[0].alternatives[0].transcript
        print("You said:", user_text)

        # Generate bot response using ADK agent
        bot_response = await generate_agent_response(user_text)

        # Text-to-speech conversion
        tts_client = texttospeech.TextToSpeechClient()
        synthesis_input = texttospeech.SynthesisInput(text=bot_response)
        voice = texttospeech.VoiceSelectionParams(
            language_code="en-US", 
            ssml_gender=texttospeech.SsmlVoiceGender.NEUTRAL
        )
        audio_config = texttospeech.AudioConfig(audio_encoding=texttospeech.AudioEncoding.MP3)

        tts_response = tts_client.synthesize_speech(
            input=synthesis_input, 
            voice=voice, 
            audio_config=audio_config
        )

        # Save response audio with unique filename
        audio_filename = f"response_{uuid.uuid4().hex}.mp3"
        audio_path = os.path.join(TEMP_AUDIO_DIR, audio_filename)
        with open(audio_path, "wb") as out:
            out.write(tts_response.audio_content)

        # Clean up temporary files
        os.unlink(tmp_audio_path)

        return FileResponse(audio_path, media_type="audio/mpeg", filename="response.mp3")
    
    except Exception as e:
        print(f"Error in chat endpoint: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/chat/get_audio/{filename}")
async def get_audio(filename: str):
    """Serve audio files"""
    try:
        if not TEMP_AUDIO_DIR:
            raise HTTPException(status_code=404, detail="Audio directory not available")
        
        audio_path = os.path.join(TEMP_AUDIO_DIR, filename)
        if os.path.exists(audio_path):
            return FileResponse(audio_path, media_type="audio/mpeg")
        else:
            raise HTTPException(status_code=404, detail="Audio file not found")
    except Exception as e:
        raise HTTPException(status_code=404, detail="Audio file not found")

@app.get("/api/chat/session_state")
async def get_chat_session_state():
    """Get current session state for debugging"""
    try:
        if not CHATBOT_AVAILABLE:
            return JSONResponse({
                "error": "Chatbot not available"
            })
        
        if SESSION_ID is None:
            return JSONResponse({
                "status": "error",
                "message": "Session not initialized yet"
            })
        
        session = session_service.get_session(
            app_name="Project Raseed", user_id="sundarpichai", session_id=SESSION_ID
        )
        return JSONResponse({
            "status": "success",
            "session_state": session.state
        })
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/api/chat/health")
async def chat_health_check():
    """Health check endpoint for chatbot"""
    return JSONResponse({
        "status": "healthy" if CHATBOT_AVAILABLE and SESSION_ID is not None else "initializing",
        "service": "Intelligent Receipt Management Assistant",
        "chatbot_available": CHATBOT_AVAILABLE,
        "session_id": SESSION_ID,
        "user_id": "sundarpichai"
    })

# Budget Management Endpoints
@app.get("/api/budget/get")
async def get_budget_data():
    """Get budget data from Firestore."""
    try:
        if not budget_manager:
            return JSONResponse(
                status_code=500,
                content={
                    "error": "Budget manager not initialized",
                    "message": "Budget manager is not available"
                }
            )
        
        budget_data = budget_manager.get_budget_data()
        
        return JSONResponse(
            status_code=200,
            content={
                "message": "Budget data retrieved successfully",
                "budget_data": budget_data
            }
        )
        
    except Exception as e:
        print(f"❌ Error in get_budget_data: {e}")
        return JSONResponse(
            status_code=500,
            content={
                "error": "Failed to retrieve budget data",
                "message": str(e)
            }
        )

@app.post("/api/budget/save")
async def save_budget_data(request: Dict[str, Any]):
    """Save budget data to Firestore."""
    try:
        if not budget_manager:
            return JSONResponse(
                status_code=500,
                content={
                    "error": "Budget manager not initialized",
                    "message": "Budget manager is not available"
                }
            )
        
        budget_data = request.get("budget_data", {})
        
        if not budget_data:
            return JSONResponse(
                status_code=400,
                content={
                    "error": "Invalid budget data",
                    "message": "No budget data provided"
                }
            )
        
        # Validate budget data structure
        expected_categories = [
            "Housing", "Food & Drinks", "Transportation", "Vehicle", 
            "Shopping", "Life & Entertainment", "Communication, PC", 
            "Financial Expenses", "Investments", "Others"
        ]
        
        for category in expected_categories:
            if category not in budget_data:
                return JSONResponse(
                    status_code=400,
                    content={
                        "error": "Invalid budget data",
                        "message": f"Missing required category: {category}"
                    }
                )
        
        # Save to Firestore
        budget_manager.save_budget_data(budget_data)
        
        return JSONResponse(
            status_code=200,
            content={
                "message": "Budget data saved successfully",
                "budget_data": budget_data
            }
        )
        
    except Exception as e:
        print(f"❌ Error in save_budget_data: {e}")
        return JSONResponse(
            status_code=500,
            content={
                "error": "Failed to save budget data",
                "message": str(e)
            }
        )

# Dashboard and Calendar Heatmap Routes
@app.get('/dashboard', response_class=HTMLResponse)
def dashboard(request: Request, start_date: str = None, end_date: str = None, month: int = None, year: int = None):
    try:
        from datetime import datetime
        from collections import OrderedDict
        from dateutil.relativedelta import relativedelta
        from collections import defaultdict
        from calendar import monthrange
        
        docs = db.collection('Receipts detail').stream()
        receipts = []
        for doc in docs:
            data = doc.to_dict()
            # Use 'date' and 'category_total' fields
            date_str = data.get('date', '')  # format: YYYY-MM-DD
            cat_total = data.get('category_total', {})
            # Sum all values in category_total except 'currency'
            day_total = 0
            for k, v in cat_total.items():
                if k == 'currency':
                    continue
                try:
                    day_total += float(v.replace(',', ''))
                except Exception:
                    continue
            receipts.append({
                'date': date_str,
                'category_total': cat_total,
                'day_total': day_total,
                'receipt_id': data.get('receipt_id', ''),
            })

        # Optionally filter by date
        def parse_date(ts):
            try:
                return datetime.strptime(ts, '%Y-%m-%d')
            except Exception:
                return None
        if start_date:
            start_date_dt = datetime.fromisoformat(start_date)
        else:
            start_date_dt = None
        if end_date:
            end_date_dt = datetime.fromisoformat(end_date)
        else:
            end_date_dt = None
        filtered_receipts = []
        for r in receipts:
            dt = parse_date(r['date'])
            if not dt:
                continue
            if start_date_dt and dt < start_date_dt:
                continue
            if end_date_dt and dt > end_date_dt:
                continue
            filtered_receipts.append(r)
        receipts = filtered_receipts if (start_date or end_date) else receipts

        # Calculate spend_per_day
        spend_per_day = {}
        for r in receipts:
            date = r['date']
            spend_per_day[date] = spend_per_day.get(date, 0) + r['day_total']

        # Calculate total_spend
        total_spend = sum(r['day_total'] for r in receipts)

        # Calculate category_spend
        category_spend = {}
        for r in receipts:
            for k, v in r['category_total'].items():
                if k == 'currency':
                    continue
                try:
                    category_spend[k] = category_spend.get(k, 0) + float(v.replace(',', ''))
                except Exception:
                    continue
        top_category = max(category_spend, key=category_spend.get) if category_spend else ''
        num_receipts = len(receipts)
        avg_spend = total_spend / num_receipts if num_receipts else 0

        # Transactions for table (one per category per day)
        transactions = []
        for r in receipts:
            date_str = r['date']
            for k, v in r['category_total'].items():
                if k == 'currency':
                    continue
                try:
                    amt = float(v.replace(',', ''))
                except Exception:
                    amt = 0
                transactions.append({
                    "receipt_id": r["receipt_id"],
                    "date": date_str,
                    "category": k,
                    "item": "",
                    "price": f"₹{amt:.2f}",
                    "quantity": 1,
                    "total_price": f"₹{amt:.2f}"
                })

        def move_others_last(d):
            if 'Others' in d:
                others_val = d.pop('Others')
                d['Others'] = others_val
            return d

        def get_last_n_days(n):
            today = datetime.now()
            dates = []
            for i in range(n):
                date = today - relativedelta(days=i)
                dates.append(date.strftime('%Y-%m-%d'))
            return dates[::-1]

        # Get last 30 days for spend_per_day
        last_30_days = get_last_n_days(30)
        spend_per_day_30 = {}
        for date in last_30_days:
            spend_per_day_30[date] = spend_per_day.get(date, 0)

        # Get last 7 days for spend_per_day
        last_7_days = get_last_n_days(7)
        spend_per_day_7 = {}
        for date in last_7_days:
            spend_per_day_7[date] = spend_per_day.get(date, 0)

        # Sort category_spend by value
        category_spend = OrderedDict(sorted(category_spend.items(), key=lambda x: x[1], reverse=True))
        category_spend = move_others_last(category_spend)

        # Calculate additional variables for template
        daily_avg_spend = total_spend / 30 if total_spend > 0 else 0
        top_category_percent = (category_spend.get(top_category, 0) / total_spend * 100) if total_spend > 0 else 0
        min_spend = min(r['day_total'] for r in receipts) if receipts else 0
        max_spend = max(r['day_total'] for r in receipts) if receipts else 0
        most_recent_date = max(r['date'] for r in receipts) if receipts else ""
        most_recent_date_fmt = most_recent_date if most_recent_date else "No receipts"
        total_spend_year = total_spend  # For now, using total spend as yearly total
        
        # Calendar variables
        calendar_month = month if month else datetime.now().month
        calendar_year = year if year else datetime.now().year
        calendar_min_spend = min(spend_per_day.values()) if spend_per_day else 0
        calendar_max_spend = max(spend_per_day.values()) if spend_per_day else 0
        
        # Trend variables
        trend_daily = spend_per_day_7
        trend_monthly = {}  # Placeholder for monthly trends
        trend_yearly = {}   # Placeholder for yearly trends
        trend_kpi_daily = sum(trend_daily.values()) / len(trend_daily) if trend_daily else 0
        trend_kpi_monthly = 0  # Placeholder
        trend_kpi_yearly = 0   # Placeholder
        
        # Category legend
        category_legend = []
        for cat, amount in category_spend.items():
            percent = (amount / total_spend * 100) if total_spend > 0 else 0
            category_legend.append({
                'name': cat,
                'amount': amount,
                'percent': percent
            })
        
        # Google colors for charts
        google_colors = ['#4285F4', '#EA4335', '#FBBC05', '#34A853', '#FF6D01', '#46BDC6', '#7B1FA2', '#FF5722']
        
        # Icon map for categories
        icon_map = {
            'Food': '🍕',
            'Utilities': '⚡',
            'Travel': '✈️',
            'Entertainment': '🎬',
            'Shopping': '🛍️',
            'Healthcare': '🏥',
            'Transportation': '🚗',
            'Education': '📚',
            'Others': '💸',
        }
        
        # Budget variables (placeholders)
        percent_change = 0
        budget_data = {}
        spent_data = {}
        for cat in category_spend.keys():
            spent = category_spend[cat]
            budget = spent * 1.2  # Placeholder budget
            percent = (spent / budget * 100) if budget > 0 else 0
            budget_data[cat] = budget
            spent_data[cat] = spent
        
        # Calendar grid data
        calendar_years = [calendar_year - 1, calendar_year, calendar_year + 1]
        
        # Generate calendar grid for the current month
        import calendar as cal
        cal_obj = cal.monthcalendar(calendar_year, calendar_month)
        calendar_grid = []
        for week in cal_obj:
            week_data = []
            for day in week:
                if day == 0:
                    week_data.append({'day': '', 'spend': None})
                else:
                    date_str = f"{calendar_year:04d}-{calendar_month:02d}-{day:02d}"
                    spend = spend_per_day.get(date_str, 0)
                    week_data.append({'day': day, 'spend': spend})
            calendar_grid.append(week_data)
        
        # Prepare context for template
        context = {
            "request": request,
            "total_spend": f"₹{total_spend:.2f}",
            "top_category": top_category,
            "num_receipts": num_receipts,
            "avg_spend_per_receipt": f"₹{avg_spend:.2f}",
            "avg_spend": f"₹{avg_spend:.2f}",
            "daily_avg_spend": daily_avg_spend,
            "top_category_percent": top_category_percent,
            "min_spend": min_spend,
            "max_spend": max_spend,
            "most_recent_date_fmt": most_recent_date_fmt,
            "total_spend_year": f"₹{total_spend_year:.2f}",
            "spend_per_day": spend_per_day,
            "spend_per_day_30": spend_per_day_30,
            "spend_per_day_7": spend_per_day_7,
            "category_spend": category_spend,
            "transactions": transactions,
            "start_date": start_date,
            "end_date": end_date,
            "month": month,
            "year": year,
            "calendar_month": calendar_month,
            "calendar_year": calendar_year,
            "calendar_min_spend": calendar_min_spend,
            "calendar_max_spend": calendar_max_spend,
            "trend_daily": trend_daily,
            "trend_monthly": trend_monthly,
            "trend_yearly": trend_yearly,
            "trend_kpi_daily": trend_kpi_daily,
            "trend_kpi_monthly": trend_kpi_monthly,
            "trend_kpi_yearly": trend_kpi_yearly,
            "category_legend": category_legend,
            "google_colors": google_colors,
            "percent_change": percent_change,
            "budget_data": budget_data,
            "spent_data": spent_data,
            "icon_map": icon_map,
            "calendar_years": calendar_years,
            "calendar_grid": calendar_grid
        }

        return templates.TemplateResponse("dashboard.html", context)
    except Exception as e:
        print(f"❌ Error in dashboard route: {e}")
        return JSONResponse(
            status_code=500,
            content={
                "error": "Dashboard error",
                "message": f"Failed to load dashboard: {str(e)}"
            }
        )

@app.get('/calendar-heatmap', response_class=HTMLResponse)
def calendar_heatmap(request: Request, month: int = None, year: int = None):
    try:
        from datetime import datetime
        from collections import OrderedDict
        from dateutil.relativedelta import relativedelta
        from collections import defaultdict
        from calendar import monthrange
        
        # --- Calendar Heatmap Data (same as dashboard) ---
        docs = db.collection('Receipts detail').stream()
        receipts = []
        for doc in docs:
            data = doc.to_dict()
            # Use 'date' and 'category_total' fields
            date_str = data.get('date', '')  # format: YYYY-MM-DD
            cat_total = data.get('category_total', {})
            # Sum all values in category_total except 'currency'
            day_total = 0
            for k, v in cat_total.items():
                if k == 'currency':
                    continue
                try:
                    day_total += float(v.replace(',', ''))
                except Exception:
                    continue
            receipts.append({
                'date': date_str,
                'category_total': cat_total,
                'day_total': day_total,
                'receipt_id': data.get('receipt_id', ''),
            })

        # Optionally filter by date
        def parse_date(ts):
            try:
                return datetime.strptime(ts, '%Y-%m-%d')
            except Exception:
                return None

        # Calculate spend_per_day
        spend_per_day = {}
        for r in receipts:
            date = r['date']
            spend_per_day[date] = spend_per_day.get(date, 0) + r['day_total']

        # Prepare context for template
        context = {
            "request": request,
            "spend_per_day": spend_per_day,
            "month": month,
            "year": year
        }

        return templates.TemplateResponse("calendar_heatmap.html", context)
    except Exception as e:
        print(f"❌ Error in calendar heatmap route: {e}")
        return JSONResponse(
            status_code=500,
            content={
                "error": "Calendar heatmap error",
                "message": f"Failed to load calendar heatmap: {str(e)}"
            }
        )

# Error handlers
@app.exception_handler(404)
async def not_found_handler(request, exc):
    return JSONResponse(
        status_code=404,
        content={"error": "Not found", "message": "The requested resource was not found"}
    )

@app.exception_handler(500)
async def server_error_handler(request, exc):
    return JSONResponse(
        status_code=500,
        content={"error": "Internal server error", "message": "An unexpected error occurred"}
    )

# Serve static files (frontend) - MUST come AFTER all API routes
frontend_path = os.path.join(os.path.dirname(__file__), "..", "frontend")
if os.path.exists(frontend_path):
    app.mount("/", StaticFiles(directory=frontend_path, html=True), name="frontend")

if __name__ == "__main__":
    print("🚀 Starting Rasheed Receipt Management API...")
    print("=" * 60)
    print("📱 Frontend Application:")
    print("   ➤ http://localhost:8000")
    print("   ➤ http://127.0.0.1:8000")
    print()
    print("📋 API Documentation:")
    print("   ➤ Swagger UI: http://localhost:8000/api/docs")
    print("   ➤ ReDoc: http://localhost:8000/api/redoc")
    print()
    print("🔗 Quick Links:")
    print("   ➤ Landing Page: http://localhost:8000/")
    print("   ➤ Main Dashboard: http://localhost:8000/app.html")
    print()
    print("🔧 Diagnostics:")
    print("   ➤ Health Check: http://localhost:8000/api/health")
    print("   ➤ Debug Routes: http://localhost:8000/api/debug/routes")
    print("=" * 60)
    print("✨ Click any link above to open in your browser!")
    print("🔄 Server will auto-reload on file changes...")
    print("💡 Check Health Check if you encounter any issues!")
    print()
    
    uvicorn.run(
        "app_backend:app", 
        host="0.0.0.0", 
        port=8000,
        reload=True,
        log_level="info"
    ) 