# Intelligent Receipt Management Assistant Integration

## Overview

The Intelligent Receipt Management Assistant has been successfully integrated into the Rasheed Receipt Management System. This AI-powered chatbot provides voice and text-based assistance for receipt management and spending analysis.

## Features

### 🤖 AI-Powered Assistant
- **Voice Recognition**: Speak naturally using WebAudio API
- **Text Input**: Type questions and get instant responses
- **Text-to-Speech**: Hear responses with natural voice synthesis
- **Context Awareness**: Remembers conversation history and spending data
- **Smart Responses**: Powered by Google's ADK (Agent Development Kit)

### 💬 Conversation Capabilities
- **Spending Analysis**: Ask about your spending patterns
- **Budget Recommendations**: Get personalized budget advice
- **Trend Insights**: Understand your financial trends
- **Money-Saving Tips**: Receive actionable financial advice
- **Receipt Management**: Get help with receipt organization

### 🎯 Quick Actions
- **Spending Summary**: One-click access to spending overview
- **Top Categories**: View your highest spending categories
- **Budget Tips**: Get personalized budget recommendations
- **Save Money**: Receive money-saving suggestions

## Technical Implementation

### Backend Integration (`app_backend.py`)

#### New Endpoints Added:
- `POST /api/chat/process_speech` - Process text input and return bot response
- `POST /api/chat/process_audio` - Handle audio file upload and return bot response
- `GET /api/chat/get_audio/{filename}` - Serve audio files from chatbot
- `GET /api/chat/session_state` - Get current chatbot session state
- `GET /api/chat/health` - Health check for chatbot

#### Key Components:
- **Session Management**: In-memory session service for conversation continuity
- **Speech Processing**: Google Cloud Speech-to-Text integration
- **Text-to-Speech**: Google Cloud Text-to-Speech for voice responses
- **ADK Integration**: Google's Agent Development Kit for intelligent responses
- **Memory Management**: Conversation history and spending data integration

### Frontend Integration (`app.html`)

#### New UI Components:
- **Chat Interface**: Modern, responsive chat UI
- **Voice Controls**: Start/stop voice recognition buttons
- **Text Input**: Real-time text messaging
- **Quick Actions**: One-click question buttons
- **Status Indicators**: Real-time connection and processing status

#### Features:
- **Real-time Messaging**: Instant message display with timestamps
- **Voice Recognition**: Browser-based speech recognition
- **Audio Playback**: Automatic audio response playback
- **Responsive Design**: Works on desktop and mobile devices
- **Error Handling**: Graceful error handling and retry mechanisms

## Setup Instructions

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Environment Variables
Create a `.env` file in the project root:
```env
GCP_PROJECT_ID=your-project-id
GCP_REGION=your-region
GOOGLE_APPLICATION_CREDENTIALS=path/to/credentials.json
```

### 3. Start the Server
```bash
cd Backend
python app_backend.py
```

### 4. Access the Application
- **Main Application**: http://localhost:8000/app.html
- **API Documentation**: http://localhost:8000/api/docs
- **Health Check**: http://localhost:8000/api/health

## Usage Guide

### Accessing the Assistant
1. Open the application at http://localhost:8000/app.html
2. Click on "Intelligent Assistant" in the sidebar
3. The assistant will greet you with available capabilities

### Using Voice Input
1. Click the "Start Voice" button
2. Speak your question clearly
3. The assistant will process your speech and respond
4. Audio responses will play automatically

### Using Text Input
1. Type your question in the text input field
2. Press Enter or click the send button
3. Receive instant text and audio responses

### Quick Actions
Use the quick action buttons for common questions:
- **Spending Summary**: Get an overview of your spending
- **Top Categories**: See your highest spending categories
- **Budget Tips**: Receive personalized budget advice
- **Save Money**: Get money-saving suggestions

## API Endpoints

### Chat Endpoints
```bash
# Process text input
POST /api/chat/process_speech
{
  "text": "Your question here"
}

# Process audio file
POST /api/chat/process_audio
# Upload audio file

# Get audio file
GET /api/chat/get_audio/{filename}

# Get session state
GET /api/chat/session_state

# Health check
GET /api/chat/health
```

### Response Format
```json
{
  "status": "success",
  "assistant_message": "Bot response text",
  "audio_filename": "response_abc123.mp3"
}
```

## Testing

### Run Integration Tests
```bash
python test_chatbot_integration.py
```

### Manual Testing
1. Start the server
2. Open the application
3. Navigate to Intelligent Assistant
4. Test voice and text input
5. Verify audio responses

## Troubleshooting

### Common Issues

#### 1. Speech Recognition Not Working
- **Cause**: Browser doesn't support Web Speech API
- **Solution**: Use Chrome or Edge browser
- **Alternative**: Use text input instead

#### 2. Audio Not Playing
- **Cause**: Browser autoplay restrictions
- **Solution**: Click on the page first, then try voice input
- **Alternative**: Check browser audio settings

#### 3. Assistant Not Responding
- **Cause**: Backend service not running
- **Solution**: Check server logs and restart if needed
- **Check**: Visit `/api/chat/health` endpoint

#### 4. Session Errors
- **Cause**: ADK session initialization failed
- **Solution**: Check Google Cloud credentials and project settings
- **Check**: Verify environment variables are set correctly

### Debug Information
- **Health Check**: `/api/health` - Overall system status
- **Chatbot Health**: `/api/chat/health` - Chatbot-specific status
- **Session State**: `/api/chat/session_state` - Current conversation state

## Architecture

### System Components
```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Frontend      │    │   Backend       │    │   Google Cloud  │
│                 │    │                 │    │                 │
│ • WebAudio API  │◄──►│ • FastAPI       │◄──►│ • Speech API    │
│ • Voice Input   │    │ • ADK Agent     │    │ • TTS API       │
│ • Text Input    │    │ • Session Mgmt  │    │ • Vertex AI     │
│ • Audio Output  │    │ • Memory Store  │    │ • Firestore     │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

### Data Flow
1. **User Input**: Voice or text input from frontend
2. **Speech Processing**: Convert voice to text (if needed)
3. **ADK Processing**: Send to Google ADK agent
4. **Response Generation**: Generate intelligent response
5. **Audio Synthesis**: Convert response to speech
6. **Output**: Send text and audio back to frontend

## Memory and Context

The assistant maintains conversation context through:
- **Session Management**: Persistent conversation sessions
- **Spending Data**: Access to user's receipt and spending data
- **Interaction History**: Previous conversation context
- **User Preferences**: Personalized responses based on spending patterns

## Security Considerations

- **HTTPS Required**: Voice recognition requires secure connection
- **Credential Management**: Google Cloud credentials properly secured
- **Session Isolation**: Each user has isolated conversation sessions
- **Data Privacy**: No sensitive data stored in client-side storage

## Performance Optimization

- **Async Processing**: Non-blocking voice and text processing
- **Audio Caching**: Temporary audio file management
- **Session Reuse**: Efficient session management
- **Error Recovery**: Graceful handling of API failures

## Future Enhancements

- **Multi-language Support**: Support for additional languages
- **Advanced Analytics**: Deeper spending insights
- **Personalization**: User-specific recommendations
- **Integration**: Connect with external financial services
- **Mobile App**: Native mobile application

## Support

For issues or questions:
1. Check the troubleshooting section above
2. Review server logs for error messages
3. Test individual endpoints using the health checks
4. Verify Google Cloud service configuration

---

**Note**: This integration provides a seamless AI-powered assistant experience while maintaining all existing functionality of the Rasheed Receipt Management System. 