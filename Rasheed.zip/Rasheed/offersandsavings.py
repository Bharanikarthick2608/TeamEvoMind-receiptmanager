from google.adk.agents import Agent
from google.adk.tools.google_search_tool import google_search   
import os
from google.cloud import firestore
from google.oauth2 import service_account
import json
from datetime import datetime
from typing import Dict, List, Any
import asyncio
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

# Direct API key configuration for ADK
GOOGLE_API_KEY = "AIzaSyCd_1JUMdkwFLQbSPo3MThUOdPIRZ9KtVg"
GOOGLE_GENAI_USE_VERTEXAI = False

# Set environment variables for ADK configuration
os.environ["GOOGLE_GENAI_USE_VERTEXAI"] = str(GOOGLE_GENAI_USE_VERTEXAI)
os.environ["GOOGLE_API_KEY"] = GOOGLE_API_KEY

# Firestore configuration
def get_credentials_path():
    """Get the credentials file path with fallback options."""
    filename = "project-rasheed-466518-5cdff45af981.json"
    
    possible_paths = [
        filename,
        os.path.join(os.path.dirname(__file__), filename),
        os.path.join(os.path.dirname(__file__), "..", filename),
        os.path.join(os.path.dirname(__file__), "..", "..", filename),
        os.path.join(os.path.dirname(__file__), "..", "..", "..", filename),
    ]
    
    print("🔍 Searching for credentials file...")
    for i, path in enumerate(possible_paths, 1):
        abs_path = os.path.abspath(path)
        print(f"   {i}. Checking: {abs_path}")
        if os.path.exists(abs_path):
            print(f"   ✅ Found credentials at: {abs_path}")
            return abs_path
    
    print("   ❌ Credentials file not found!")
    raise FileNotFoundError(f"Could not find {filename}")

CREDENTIALS_PATH = get_credentials_path()
PROJECT_ID = "project-rasheed-466518"

def get_firestore_client():
    """Initialize and return Firestore client."""
    try:
        credentials = service_account.Credentials.from_service_account_file(
            CREDENTIALS_PATH,
            scopes=['https://www.googleapis.com/auth/cloud-platform']
        )
        db = firestore.Client(project=PROJECT_ID, credentials=credentials)
        print("✅ Firestore client initialized successfully!")
        return db
    except Exception as e:
        print(f"❌ Error initializing Firestore client: {e}")
        return None

# Simple ADK Agent
savings_agent = Agent(
    name="savings_agent",
    model="gemini-2.5-pro",
    description="Agent that analyzes spending data and provides savings suggestions",
    instruction="""
    You are a savings analysis agent. Analyze the provided spending data and give savings suggestions.
    
    Use google_search to find current prices and offers for products.
    
    Provide your response in a clear, natural format with bullet points and sections. Focus on:
    
    1. **PRODUCTS YOU FREQUENTLY BUY** - Find current prices and better alternatives
    2. **HIGH-SPENDING CATEGORIES** - Suggest ways to save in your top spending categories
    3. **GENERAL SAVINGS TIPS** - Provide actionable advice based on spending patterns
    
    Format your response exactly like this:
    
    **PRODUCTS YOU FREQUENTLY BUY**
    • [Product Name] - Current price: ₹[price], Savings tip: [specific tip with actionable advice]
    • [Product Name] - Current price: ₹[price], Savings tip: [specific tip with actionable advice]
    
    **HIGH-SPENDING CATEGORIES**
    • [Category Name] - You spent ₹[amount], Savings tip: [specific tip with actionable advice]
    • [Category Name] - You spent ₹[amount], Savings tip: [specific tip with actionable advice]
    
    **GENERAL SAVINGS TIPS**
    • [Actionable tip 1]
    • [Actionable tip 2]
    • [Actionable tip 3]
    
    Be helpful, specific, and include actual prices and offers you find through search.
    """,
    tools=[google_search],
)

def fetch_receipt_data():
    """Fetch all receipt data from Firestore."""
    try:
        db = get_firestore_client()
        if not db:
            return None
        
        receipts_ref = db.collection("Receipts detail")
        docs = receipts_ref.stream()
        
        receipts = []
        for doc in docs:
            receipt_data = doc.to_dict()
            receipt_data["id"] = doc.id
            receipts.append(receipt_data)
        
        print(f"✅ Fetched {len(receipts)} receipts from Firestore")
        return receipts
    except Exception as e:
        print(f"❌ Error fetching receipt data: {e}")
        return None

def fetch_spending_analysis():
    """Fetch spending analysis from Firestore."""
    try:
        db = get_firestore_client()
        if not db:
            return None
        
        analysis_doc = db.collection("spending_analysis").document("current_spending_analysis").get()
        
        if analysis_doc.exists:
            analysis_data = analysis_doc.to_dict()
            print(f"✅ Fetched spending analysis from Firestore")
            return analysis_data
        else:
            print("⚠️ No spending analysis found in Firestore")
            return None
    except Exception as e:
        print(f"❌ Error fetching spending analysis: {e}")
        return None

def extract_products_from_receipts(receipts: List[Dict]) -> List[Dict]:
    """Extract unique products from receipts for analysis."""
    products = []
    product_frequency = {}
    
    for receipt in receipts:
        details = receipt.get("details", {})
        for category, category_items in details.items():
            for product_name, product_data in category_items.items():
                if isinstance(product_data, dict):
                    price = product_data.get("price", "0")
                    quantity = product_data.get("quantity", "1")
                    
                    clean_name = product_name.strip()
                    
                    if clean_name not in product_frequency:
                        product_frequency[clean_name] = {
                            "name": clean_name,
                            "category": category,
                            "frequency": 0,
                            "total_spent": 0,
                            "avg_price": 0,
                            "prices": []
                        }
                    
                    try:
                        price_float = float(str(price).replace(",", "").replace("₹", "").replace("$", ""))
                        quantity_float = float(str(quantity).replace(",", ""))
                        total_spent = price_float * quantity_float
                        
                        product_frequency[clean_name]["frequency"] += 1
                        product_frequency[clean_name]["total_spent"] += total_spent
                        product_frequency[clean_name]["prices"].append(price_float)
                    except (ValueError, TypeError):
                        continue
    
    # Calculate average prices and sort by frequency and total spent
    for product in product_frequency.values():
        if product["prices"]:
            product["avg_price"] = sum(product["prices"]) / len(product["prices"])
    
    sorted_products = sorted(
        product_frequency.values(),
        key=lambda x: (x["frequency"], x["total_spent"]),
        reverse=True
    )
    
    return sorted_products[:10]

def get_high_spending_categories(spending_analysis: Dict) -> List[Dict]:
    """Get categories with highest spending for analysis."""
    if not spending_analysis:
        return []
    
    category_totals = spending_analysis.get("category_totals", {})
    category_percentages = spending_analysis.get("category_percentages", {})
    
    sorted_categories = sorted(
        category_totals.items(),
        key=lambda x: float(str(x[1]).replace(",", "").replace("₹", "").replace("$", "")) if x[1] else 0,
        reverse=True
    )
    
    high_spending_categories = []
    for category_name, total_amount in sorted_categories[:5]:
        try:
            amount_float = float(str(total_amount).replace(",", "").replace("₹", "").replace("$", ""))
            percentage = category_percentages.get(category_name, 0)
            
            high_spending_categories.append({
                "name": category_name,
                "total_spent": amount_float,
                "percentage": percentage,
                "formatted_amount": str(total_amount)
            })
        except (ValueError, TypeError):
            continue
    
    return high_spending_categories

async def analyze_savings_simple():
    """Simple analysis using ADK agent."""
    try:
        print("🔄 Starting simple savings analysis...")
        
        # Fetch data
        receipts = fetch_receipt_data()
        spending_analysis = fetch_spending_analysis()
        
        if not receipts:
            return {"error": "No receipt data found"}
        
        # Extract data
        products = extract_products_from_receipts(receipts)
        categories = get_high_spending_categories(spending_analysis)
        
        print(f"📦 Found {len(products)} products and {len(categories)} categories")
        
        # Prepare data for agent
        data_for_agent = {
            "products": products[:5],  # Top 5 products
            "categories": categories,
            "total_receipts": len(receipts),
            "total_spending": spending_analysis.get("total_spending", 0) if spending_analysis else 0
        }
        
        # Create prompt with all data
        prompt = f"""
        Hey! I found some great savings opportunities for you based on your spending patterns.
        
        Here's what I analyzed:
        - You've spent ₹{data_for_agent['total_spending']:,.2f} across {data_for_agent['total_receipts']} receipts
        - Your top products: {', '.join([p['name'] for p in data_for_agent['products'][:3]])}
        - Your high-spending categories: {', '.join([c['name'] for c in data_for_agent['categories'][:3]])}
        
        Please search for current prices and offers for these products and categories, then give me specific savings recommendations. 
        
        Format your response like this:
        
        **PRODUCTS YOU FREQUENTLY BUY**
        • [Product Name] - Current price: ₹[price], Savings tip: [specific tip with actionable advice]
        • [Product Name] - Current price: ₹[price], Savings tip: [specific tip with actionable advice]
        
        **HIGH-SPENDING CATEGORIES**
        • [Category Name] - You spent ₹[amount], Savings tip: [specific tip with actionable advice]
        • [Category Name] - You spent ₹[amount], Savings tip: [specific tip with actionable advice]
        
        **GENERAL SAVINGS TIPS**
        • [Actionable tip 1]
        • [Actionable tip 2]
        • [Actionable tip 3]
        
        Make it personal, actionable, and include specific prices and offers you find!
        """
        
        # Run agent
        session_service = InMemorySessionService()
        runner = Runner(
            agent=savings_agent,
            app_name="savings_analysis",
            session_service=session_service
        )
        
        session_id = "analysis_session"
        user_id = "user"
        
        await session_service.create_session(
            app_name="savings_analysis",
            session_id=session_id,
            user_id=user_id
        )
        
        user_content = types.Content(
            role='user',
            parts=[types.Part(text=prompt)]
        )
        
        print("🚀 Running ADK agent...")
        
        final_response = ""
        async for event in runner.run_async(
            user_id=user_id,
            session_id=session_id,
            new_message=user_content
        ):
            if hasattr(event, 'is_final_response') and event.is_final_response() and event.content and event.content.parts:
                final_response = event.content.parts[0].text
                break
            elif hasattr(event, 'content') and event.content and event.content.parts:
                final_response = event.content.parts[0].text
                break
        
        if final_response:
            # Always return the raw response as text for simple display
            print("✅ Analysis completed successfully!")
            return {
                "status": "success",
                "data": {"raw_response": final_response},
                "timestamp": datetime.now().isoformat()
            }
        else:
            return {"error": "No response from agent"}
            
    except Exception as e:
        print(f"❌ Error in analysis: {e}")
        return {"error": f"Analysis failed: {str(e)}"}

def get_offers_and_savings():
    """Main function - simple approach."""
    return asyncio.run(analyze_savings_simple())

def get_existing_offers():
    """Get cached offers data."""
    try:
        db = get_firestore_client()
        if not db:
            return None
        
        offers_doc = db.collection("offers_cache").document("current_offers").get()
        
        if offers_doc.exists:
            offers_data = offers_doc.to_dict()
            if offers_data.get("timestamp"):
                try:
                    timestamp = datetime.fromisoformat(offers_data["timestamp"])
                    if (datetime.now() - timestamp).total_seconds() < 86400:  # 24 hours
                        print("✅ Using cached offers data")
                        return offers_data
                except:
                    pass
        
        print("🔄 No recent cached data found")
        return None
        
    except Exception as e:
        print(f"❌ Error fetching existing offers: {e}")
        return None

def save_offers_to_cache(offers_data: Dict):
    """Save offers data to Firestore cache."""
    try:
        db = get_firestore_client()
        if not db:
            return False
        
        db.collection("offers_cache").document("current_offers").set(offers_data)
        print("✅ Offers data saved to cache")
        return True
        
    except Exception as e:
        print(f"❌ Error saving offers to cache: {e}")
        return False

# Test function
if __name__ == "__main__":
    print("🚀 Testing Simple Offers and Savings Agent...")
    
    results = get_offers_and_savings()
    
    if results.get("status") == "success":
        print("✅ Analysis completed successfully!")
        print(f"📊 Results: {json.dumps(results['data'], indent=2)}")
        
        # Save to cache
        save_offers_to_cache(results)
    else:
        print(f"❌ Analysis failed: {results.get('error')}")
