import os
import json
from typing import Dict, Any, Optional
from google.cloud import firestore
from google.oauth2 import service_account

class BudgetManager:
    """Manages budget data operations with Firestore."""
    
    def __init__(self, credentials_path: str, project_id: str = "project-rasheed-466518"):
        """Initialize the BudgetManager with Firestore credentials."""
        self.credentials_path = credentials_path
        self.project_id = project_id
        self.db = None
        self._initialize_firestore()
        
        # Default budget structure
        self.default_budget = {
            "Housing": 15000,
            "Food & Drinks": 5000,
            "Transportation": 2000,
            "Vehicle": 5000,
            "Shopping": 10000,
            "Life & Entertainment": 10000,
            "Communication, PC": 3000,
            "Financial Expenses": 3000,
            "Investments": 25000,
            "Others": 12000
        }
    
    def _initialize_firestore(self):
        """Initialize Firestore client with credentials."""
        try:
            # Load credentials
            credentials = service_account.Credentials.from_service_account_file(
                self.credentials_path
            )
            
            # Initialize Firestore client
            self.db = firestore.Client(
                credentials=credentials,
                project=self.project_id
            )
            
            print(f"✅ BudgetManager initialized with Firestore")
            
        except Exception as e:
            print(f"❌ Error initializing BudgetManager: {e}")
            raise
    
    def get_budget_data(self) -> Dict[str, int]:
        """Get budget data from Firestore Budget collection."""
        try:
            if not self.db:
                print("❌ Firestore client not initialized")
                return self.default_budget
            
            # Get the budget document
            budget_doc = self.db.collection('Budget').document('budget_data').get()
            
            if budget_doc.exists:
                budget_data = budget_doc.to_dict()
                print(f"✅ Retrieved budget data from Firestore: {budget_data}")
                return budget_data
            else:
                print("⚠️ No budget data found in Firestore, using default")
                # Initialize with default data
                self.save_budget_data(self.default_budget)
                return self.default_budget
                
        except Exception as e:
            print(f"❌ Error getting budget data: {e}")
            return self.default_budget
    
    def save_budget_data(self, budget_data: Dict[str, int]) -> bool:
        """Save budget data to Firestore Budget collection."""
        try:
            if not self.db:
                print("❌ Firestore client not initialized")
                return False
            
            # Validate budget data structure
            expected_categories = [
                "Housing", "Food & Drinks", "Transportation", "Vehicle", 
                "Shopping", "Life & Entertainment", "Communication, PC", 
                "Financial Expenses", "Investments", "Others"
            ]
            
            # Ensure all categories are present
            for category in expected_categories:
                if category not in budget_data:
                    budget_data[category] = self.default_budget[category]
            
            # Save to Firestore
            self.db.collection('Budget').document('budget_data').set(budget_data)
            
            print(f"✅ Budget data saved to Firestore: {budget_data}")
            return True
            
        except Exception as e:
            print(f"❌ Error saving budget data: {e}")
            return False
    
    def update_budget_category(self, category: str, amount: int) -> bool:
        """Update a specific budget category."""
        try:
            current_budget = self.get_budget_data()
            current_budget[category] = amount
            return self.save_budget_data(current_budget)
        except Exception as e:
            print(f"❌ Error updating budget category {category}: {e}")
            return False
    
    def get_budget_summary(self) -> Dict[str, Any]:
        """Get budget summary statistics."""
        try:
            budget_data = self.get_budget_data()
            total_budget = sum(budget_data.values())
            
            return {
                "total_budget": total_budget,
                "categories_count": len(budget_data),
                "average_per_category": round(total_budget / len(budget_data)),
                "highest_category": max(budget_data, key=budget_data.get),
                "highest_amount": budget_data[max(budget_data, key=budget_data.get)],
                "budget_data": budget_data
            }
        except Exception as e:
            print(f"❌ Error getting budget summary: {e}")
            return {} 