import os
import tempfile
import json
import asyncio
import uuid
from datetime import datetime
from typing import Dict, Any
from contextlib import asynccontextmanager

# FastAPI imports
from fastapi import FastAPI, File, UploadFile, Request, HTTPException
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware

# Google Cloud imports
from google.cloud import speech, texttospeech
from google.cloud import firestore
from google.oauth2 import service_account
import google.genai as genai

# ADK imports
from customer_service_agent.agent import router_agent
from dotenv import load_dotenv
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from utils import add_user_query_to_history, call_agent_async, add_agent_response_to_history
from google.genai import types
from dotenv import load_dotenv

# Load environment variables (with error handling)
try:
    load_dotenv()
except Exception as e:
    print(f"⚠️  Warning: Could not load .env file: {e}")

# Set Google credentials
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "project-rasheed-466518-5cdff45af981.json"

# ===== PART 1: Initialize In-Memory Session Service =====
session_service = InMemorySessionService()

# ===== PART 2: Initialize Firestore and Get Spending Data =====
credentials_path = "project-rasheed-466518-5cdff45af981.json"

# Load service account credentials
credentials = service_account.Credentials.from_service_account_file(
    credentials_path,
    scopes=["https://www.googleapis.com/auth/cloud-platform"]
)

# Initialize Firestore client
db = firestore.Client(project="project-rasheed-466518", credentials=credentials)
print("✅ Firestore client initialized successfully!")

try:
    # Reference to 'spending_analysis' collection
    collection_ref = db.collection("spending_analysis")
    
    # Get the current spending analysis document
    doc_ref = collection_ref.document("current_spending_analysis")
    doc = doc_ref.get()
    
    if doc.exists:
        # Get the detailed_summary from the document
        analysis_data = doc.to_dict()
        spending_summary = analysis_data.get("detailed_summary", "No spending analysis available.")
    else:
        spending_summary = "No spending analysis available."
except Exception as e:
    print(f"Error getting spending analysis: {e}")
    spending_summary = "No spending analysis available."

# ===== PART 3: Define Initial State =====
initial_state = {
    "user_name": "Sundar Pichai",
    "spending_history": spending_summary,
    "interaction_history": [],
}

# ===== PART 4: Vertex AI Client Setup =====
vertexai_project = os.getenv("GCP_PROJECT_ID") 
vertexai_location = os.getenv("GCP_REGION") 

client = genai.Client(
    vertexai=True,
    project=vertexai_project,
    location=vertexai_location,
)

# ===== PART 5: Agent Runner Setup =====
APP_NAME = "Project Raseed"
USER_ID = "sundarpichai"

# Global variables for session management
SESSION_ID = None
runner = None

async def initialize_session():
    """Initialize the session and runner asynchronously"""
    global SESSION_ID, runner
    
    # Create initial session
    new_session = await session_service.create_session(
        app_name=APP_NAME,
        user_id=USER_ID,
        state=initial_state,
    )
    SESSION_ID = new_session.id
    print(f"Created new session: {SESSION_ID}")

    # Create a runner with the main customer service agent
    runner = Runner(
        agent=router_agent,
        app_name=APP_NAME,
        session_service=session_service,
    )

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan context manager for FastAPI app"""
    # Startup
    await initialize_session()
    print("🚀 Raseed Voice Chatbot initialized successfully!")
    yield
    # Shutdown
    print("🛑 Raseed Voice Chatbot shutting down...")

# Initialize FastAPI app with lifespan
app = FastAPI(title="Raseed Voice Chatbot API", lifespan=lifespan)

# Mount static files only if directory exists
if os.path.exists("static"):
    app.mount("/static", StaticFiles(directory="static"), name="static")
    print("✅ Static files directory mounted")
else:
    print("⚠️  Static directory not found - static files will not be served")

# Mount templates only if directory exists
if os.path.exists("templates"):
    templates = Jinja2Templates(directory="templates")
    print("✅ Templates directory mounted")
else:
    print("⚠️  Templates directory not found - HTML responses may not work")
    templates = None

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create a temporary directory for audio files
TEMP_AUDIO_DIR = tempfile.mkdtemp(prefix="raseed_voice_chatbot_")
print(f"Audio files will be stored in: {TEMP_AUDIO_DIR}")

# ===== PART 6: FastAPI Routes =====

@app.get("/", response_class=HTMLResponse)
async def get_home(request: Request):
    """Serve the main HTML page"""
    if templates is None:
        return JSONResponse({
            "error": "Templates directory not found",
            "message": "Please ensure the templates directory exists with index.html"
        })
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/chat")
async def chat(audio_file: UploadFile = File(...)):
    """Handle audio file upload and return bot response"""
    try:
        # Save uploaded audio file
        with tempfile.NamedTemporaryFile(delete=False, suffix=".webm") as tmp_audio:
            tmp_audio.write(await audio_file.read())
            tmp_audio_path = tmp_audio.name

        # Speech-to-text conversion
        speech_client = speech.SpeechClient()
        with open(tmp_audio_path, "rb") as f:
            audio_data = f.read()

        audio = speech.RecognitionAudio(content=audio_data)
        config = speech.RecognitionConfig(
            encoding=speech.RecognitionConfig.AudioEncoding.WEBM_OPUS,
            language_code="en-US",
            enable_automatic_punctuation=True
        )
        
        response = speech_client.recognize(config=config, audio=audio)

        if not response.results:
            return {"error": "Could not recognize speech"}

        user_text = response.results[0].alternatives[0].transcript
        print("You said:", user_text)

        # Generate bot response using ADK agent
        bot_response = await generate_agent_response(user_text)

        # Text-to-speech conversion
        tts_client = texttospeech.TextToSpeechClient()
        synthesis_input = texttospeech.SynthesisInput(text=bot_response)
        voice = texttospeech.VoiceSelectionParams(
            language_code="en-US", 
            ssml_gender=texttospeech.SsmlVoiceGender.NEUTRAL
        )
        audio_config = texttospeech.AudioConfig(audio_encoding=texttospeech.AudioEncoding.MP3)

        tts_response = tts_client.synthesize_speech(
            input=synthesis_input, 
            voice=voice, 
            audio_config=audio_config
        )

        # Save response audio with unique filename
        audio_filename = f"response_{uuid.uuid4().hex}.mp3"
        audio_path = os.path.join(TEMP_AUDIO_DIR, audio_filename)
        with open(audio_path, "wb") as out:
            out.write(tts_response.audio_content)

        # Clean up temporary files
        os.unlink(tmp_audio_path)

        return FileResponse(audio_path, media_type="audio/mpeg", filename="response.mp3")
    
    except Exception as e:
        print(f"Error in chat endpoint: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/process_speech")
async def process_speech(request: Request):
    """Process text input and return bot response"""
    try:
        data = await request.json()
        user_text = data.get("text", "")
        
        if not user_text:
            return JSONResponse({"error": "No text provided"})
        
        # Generate bot response using ADK agent
        bot_response = await generate_agent_response(user_text)
        
        # Text-to-speech conversion
        tts_client = texttospeech.TextToSpeechClient()
        synthesis_input = texttospeech.SynthesisInput(text=bot_response)
        voice = texttospeech.VoiceSelectionParams(
            language_code="en-US", 
            ssml_gender=texttospeech.SsmlVoiceGender.NEUTRAL
        )
        audio_config = texttospeech.AudioConfig(audio_encoding=texttospeech.AudioEncoding.MP3)

        tts_response = tts_client.synthesize_speech(
            input=synthesis_input, 
            voice=voice, 
            audio_config=audio_config
        )

        # Save response audio with unique filename
        audio_filename = f"response_{uuid.uuid4().hex}.mp3"
        audio_path = os.path.join(TEMP_AUDIO_DIR, audio_filename)
        with open(audio_path, "wb") as out:
            out.write(tts_response.audio_content)

        return JSONResponse({
            "status": "success",
            "assistant_message": bot_response,
            "audio_filename": audio_filename
        })
    
    except Exception as e:
        print(f"Error in process_speech endpoint: {str(e)}")
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/get_audio/{filename}")
async def get_audio(filename: str):
    """Serve audio files"""
    try:
        audio_path = os.path.join(TEMP_AUDIO_DIR, filename)
        if os.path.exists(audio_path):
            return FileResponse(audio_path, media_type="audio/mpeg")
        else:
            raise HTTPException(status_code=404, detail="Audio file not found")
    except Exception as e:
        raise HTTPException(status_code=404, detail="Audio file not found")

@app.get("/session_state")
async def get_session_state():
    """Get current session state for debugging"""
    try:
        if SESSION_ID is None:
            return JSONResponse({
                "status": "error",
                "message": "Session not initialized yet"
            })
        
        session = session_service.get_session(
            app_name=APP_NAME, user_id=USER_ID, session_id=SESSION_ID
        )
        return JSONResponse({
            "status": "success",
            "session_state": session.state
        })
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)

# ===== PART 7: Agent Response Generation =====

async def generate_agent_response(user_input: str) -> str:
    """Generate bot response using the ADK router agent"""
    try:
        # Check if session is initialized
        if SESSION_ID is None or runner is None:
            return "I'm still initializing. Please try again in a moment."
        
        # Update interaction history with the user's query
        add_user_query_to_history(
            session_service, APP_NAME, USER_ID, SESSION_ID, user_input
        )

        # Process the user query through the agent
        content = types.Content(role="user", parts=[types.Part(text=user_input)])
        final_response_text = None
        agent_name = None

        print(f"\n--- Processing Query: {user_input} ---")

        async for event in runner.run_async(
            user_id=USER_ID, session_id=SESSION_ID, new_message=content
        ):
            # Capture the agent name from the event if available
            if event.author:
                agent_name = event.author

            # Process agent response
            if event.is_final_response():
                if (
                    event.content
                    and event.content.parts
                    and hasattr(event.content.parts[0], "text")
                    and event.content.parts[0].text
                ):
                    final_response_text = event.content.parts[0].text.strip()
                    print(f"Agent Response: {final_response_text}")

        # Add the agent response to interaction history if we got a final response
        if final_response_text and agent_name:
            add_agent_response_to_history(
                session_service,
                APP_NAME,
                USER_ID,
                SESSION_ID,
                agent_name,
                final_response_text,
            )

        # Return the response or a fallback
        if final_response_text:
            return final_response_text
        else:
            return "I'm sorry, I couldn't process your request at the moment. Please try again."

    except Exception as e:
        print(f"Error generating agent response: {e}")
        return f"I encountered an error while processing your request: {str(e)}"

# ===== PART 8: Health Check and Info Endpoints =====

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return JSONResponse({
        "status": "healthy" if SESSION_ID is not None else "initializing",
        "service": "Raseed Voice Chatbot",
        "session_id": SESSION_ID,
        "user_id": USER_ID
    })

@app.get("/info")
async def get_info():
    """Get service information"""
    return JSONResponse({
        "service": "Raseed Voice Chatbot",
        "version": "1.0.0",
        "features": [
            "Voice-to-text conversion",
            "Text-to-speech synthesis",
            "ADK Agent-based responses",
            "Session management",
            "Spending analysis integration"
        ],
        "endpoints": {
            "POST /chat": "Process audio file and return voice response",
            "POST /process_speech": "Process text and return voice response",
            "GET /get_audio/{filename}": "Serve audio files",
            "GET /session_state": "Get current session state",
            "GET /health": "Health check"
        }
    })

if __name__ == "__main__":
    import uvicorn
    print("🚀 Starting Raseed Voice Chatbot...")
    print(f"📁 Audio files directory: {TEMP_AUDIO_DIR}")
    print(f"👤 User ID: {USER_ID}")
    print("🔄 Session will be initialized on startup...")
    uvicorn.run(app, host="127.0.0.1", port=8000) 