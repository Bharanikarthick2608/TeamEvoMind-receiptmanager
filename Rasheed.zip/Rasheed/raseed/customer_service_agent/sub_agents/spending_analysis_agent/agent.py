from datetime import datetime
from google.adk.tools import agent_tool
from google.adk.agents import Agent
from google.adk.tools.tool_context import ToolContext
# from ..sql_agent.agent import sql_agent

# Create the order agent
spending_analysis_agent = Agent(
    name="spending_analysis_agent",
    model="gemini-2.5-pro",
    description="Agent for analyzing the spending behaviour of users.",
    instruction="""Your job is to help users analyze their spending behaviour in the past.
    Understand user query and use the appropriate tool to answer the query. 

    <user_info>
    Name: {user_name}
    </user_info>

    <spending_history>
    Spending History: {spending_history}
    </spending_history>

    <interaction_history>
    {interaction_history}
    </interaction_history>

    Analyze the spending history of user and if there are no  useful info, use the tools at your disposal.

    1. Use sql_tool if you require any analysis on the data.

    Remember:
    - Be clear and professional
    - Direct questions that you cannot answer to other agents.
    - Direct product availability inquiries to inventory_agent.
    """,
    tools=[agent_tool.AgentTool(sql_agent)],
)
