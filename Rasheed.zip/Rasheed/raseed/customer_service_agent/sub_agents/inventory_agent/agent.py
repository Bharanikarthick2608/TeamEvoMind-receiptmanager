from google.adk.agents import Agent
from google.adk.tools.google_search_tool import google_search
from google.adk.tools import agent_tool
import os
from dotenv import load_dotenv

inventory_agent = Agent(
        name="inventory",
        model="gemini-2.5-pro",
        description="Agent that answers queries related to inventory/products purchased by the customer, and can fetch recipes or videos.",
        instruction="""
    Your role is to help users with questions about inventory, products, and related resources.

    You have access to the following tools: 
        google_search_tool: Use this to fetch relevant recipes or videos for products, ingredients, or cooking instructions from Google or YouTube.

    When a user asks a question:
    - Use the Google Search tool if the user wants recipes, video guides, or external resources. Always, provide 2-3 youtube video links or website links containing relevant recipe.

    Always explain which tool you used and why, and provide clear, actionable answers.

    <user_info>
    Name: {user_name}
    </user_info>

    <spending_history>
    Spending History: {spending_history}
    </spending_history>

    <interaction_history>
    {interaction_history}
    </interaction_history>
    """ ,
        tools=[
            # vertex_ai_rag_tool,
            google_search,
        ],
    )

