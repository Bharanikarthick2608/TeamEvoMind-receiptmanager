from google.adk.agents import SequentialAgent
from google.adk.tools import agent_tool
from langchain.chains import LLMChain
from typing import List, Union, Dict, Any
import google.generativeai as genai
import os
import logging
import mysql.connector
from datetime import datetime
import time
from google.oauth2 import service_account
from google.cloud import aiplatform
import re
from dotenv import load_dotenv

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

load_dotenv()

# MySQL Configuration
DB_CONFIG = {
    'host': '34.10.48.227',
    'user': 'root',
    'password': '',  # Update if needed
    'database': 'Receiptsdetails',
    'port': 3306,
    'connect_timeout': 10,
    'allow_local_infile': True,
    'raise_on_warnings': True
}
def get_db_connection():
    """Create and return a database connection with retry logic"""
    max_retries = 3
    retry_delay = 2  # seconds
    
    for attempt in range(max_retries):
        try:
            connection = mysql.connector.connect(**DB_CONFIG)
            connection.ping(reconnect=True, attempts=3, delay=5)
            return connection
        except mysql.connector.Error as err:
            logger.error(f"Database connection attempt {attempt + 1} failed: {err}")
            if attempt == max_retries - 1:
                raise
            time.sleep(retry_delay * (attempt + 1))

# Initialize database connection
try:
    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)
    logger.info("Successfully connected to database")
except Exception as e:
    logger.error(f"Failed to connect to database: {e}")
    raise

def get_recent_food_items():
    """
    Retrieve item names and total quantity bought in 'Food & Drinks' category in the last 2 weeks.
    Returns a dictionary: {item_name: total_quantity, ...}
    """
    query = """
    SELECT
        r.item_name,
        SUM(r.quantity) AS total_quantity
    FROM
        receipt r
    WHERE
        TRIM(LOWER(r.category)) = 'food & drinks'
        AND r.purchase_date BETWEEN CURDATE() - INTERVAL 14 DAY AND CURDATE()
    GROUP BY
        r.item_name
    ORDER BY
        total_quantity DESC;
    """
    try:
        cursor.execute(query)
        rows = cursor.fetchall()
        # rows is a list of dicts if cursor is dictionary=True, else list of tuples
        if rows and isinstance(rows[0], dict):
            return {row['item_name']: row['total_quantity'] for row in rows}
        else:
            # fallback for tuple rows
            return {row[0]: row[1] for row in rows}
    except Exception as e:
        logging.error(f"Error fetching recent food items: {e}")
        return {}

# def recipe_creater(user_query: str) -> str:
#     prompt = f""" You are a cooking recipe expert. Given a user query, create a recipe for the user.
#     User query: {user_query}. Clearly list out the ingredients required for the recipe in the beginning of the recipe itself. Refrain from using any markdown characters like bullet points or asterisks."""
#     try:
#         model = genai.GenerativeModel("gemini-2.5-flash")
#         response = model.generate_content(prompt)
#         return response.text.strip()
#     except Exception as e:
#         logging.error(f"Error generating conversational response: {str(e)}")
#         return "Sorry, I couldn't generate a response at this time. Please try again later."

#     return response


# def extract_and_compare_agent(recipe_output: str) -> list:
#     """
#     Given the recipe output and a list of purchased items, return a list of missing items.
#     """
#     existing_items = get_recent_food_items()
#     prompt = f"""
#     You are a helpful assistant. Given the recipe output and a list of existing items, return a list of missing items so that can be added to the shopping_list.
#     Be intelligent and add items based on quantity bought, if an existing item is of less quantity, assume that it is probably finished and add the item to the shopping list.
#     Recipe output: {recipe_output}
#     Existing items: {existing_items}

#     You will have to provide the output in the following format:


#     """
#     try:
#         model = genai.GenerativeModel("gemini-2.5-flash")
#         response = model.generate_content(prompt)
#         return response.text.strip()
#     except Exception as e:
#         logging.error(f"Error generating conversational response: {str(e)}")
#         return "Sorry, I couldn't generate a response at this time. Please try again later."

#     return response

def generate_recipe_and_missing_items(user_query: str) -> Dict[str, Any]:
    """
    One-shot LLM call to:
    1. Generate a recipe from the user's query.
    2. Compare it against existing items from recent purchases.
    
    Returns:
    {
        "output": <recipe_text>,
        "missing_items": [<list_of_missing_items>]
    }
    """
    existing_items = get_recent_food_items()

    # Construct prompt that includes the user query and user's purchased items
    prompt = f"""
You are a cooking recipe expert. Based on {existing_items}, create a relevant recipe. 
Then, compare the ingredients required in the recipe with the following list of purchased items from the last 2 weeks: {existing_items}

Your response must follow this exact JSON format:
{{
  "output": "<the recipe here as a string. Start by listing ingredients, then method. No markdown or formatting characters.>",
  "missing_items": [<list of missing ingredients as plain strings>]
}}

User query: {user_query}
    """

    try:
        model = genai.GenerativeModel("gemini-2.5-flash")
        response = model.generate_content(prompt)
        text = response.text.strip()

        # Attempt to parse JSON from response
        match = re.search(r'\{[\s\S]*\}', text)
        if match:
            import json
            print(json.loads(match.group()))
        else:
            logging.warning("LLM response could not be parsed as JSON. Returning raw.")
            return {
                "output": text,
                "missing_items": []
            }
    except Exception as e:
        logging.error(f"Error generating recipe and missing items: {str(e)}")
        return {
            "output": "Sorry, I couldn't generate a recipe right now.",
            "missing_items": []
        }




def pass_adder(missing_items):
    """
    Dummy tool for testing. Returns 'worked' and echoes the input.
    """
    print(f"pass_adder called with: {missing_items}")
    return f"worked: {missing_items}"

def items_adder_agent(query: str):
    """
    tool for getting recipe and adding missing items to the shopping list.
    Output format: { missing_item: [], output: []}"""
    missing_items = generate_recipe_and_missing_items
    pass_adder(missing_items)
    return f"success: {missing_items}"
