from vertexai import rag
from vertexai.generative_models import GenerativeModel, Tool
import vertexai
from typing import List, Dict


# gcloud projects add-iam-policy-binding vertex-ai-experminent --member="bharanikarthick@project-rasheed-466518.iam.gserviceaccount.com" --role="roles/aiplatform.user" 
# gcloud projects add-iam-policy-binding vertex-ai-experminent --member="user:YOUR_EMAIL@domain.com" --role="roles/storage.objectAdmin"

from google.cloud import discoveryengine_v1beta
import os
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Vertex AI
vertexai.init(
    project="project-rasheed-466518",
    location="us-central1",
)

# Initialize Discovery Engine (Vertex AI Search) client
search_client = discoveryengine_v1beta.SearchServiceClient()

class VertexSearchRAGAgent:
    def __init__(
        self,
        project_id: str = "project-rasheed-466518",
        location: str = "us-central1",
        search_engine_id: str = None,  # You'll need to provide this
        data_store_id: str = None,     # You'll need to provide this
    ):
        """
        Initialize the Vertex AI Search RAG Agent.
        
        Args:
            project_id: Google Cloud project ID
            location: Google Cloud location
            search_engine_id: Vertex AI Search engine ID
            data_store_id: Vertex AI Search data store ID
        """
        self.project_id = project_id
        self.location = location
        self.search_engine_id = search_engine_id
        self.data_store_id = data_store_id
        
        # Construct the search engine path
        self.search_engine_path = search_client.search_service_path(
            project=project_id,
            location=location,
            data_store=data_store_id,
            engine=search_engine_id
        )
        
        # Initialize Vertex AI client for embeddings
        self.embedding_model = "textembedding-gecko@latest"
        
    def search_documents(self, query: str, max_results: int = 5) -> List[Dict]:
        """
        Search documents using Vertex AI Search.
        
        Args:
            query: Search query string
            max_results: Maximum number of results to return
            
        Returns:
            List of documents with their metadata and relevance scores
        """
        try:
            # Create the search request
            request = discoveryengine_v1beta.SearchRequest(
                serving_config=self.search_engine_path,
                query=query,
                page_size=max_results,
                query_expansion_spec=discoveryengine_v1beta.SearchRequest.QueryExpansionSpec(
                    condition=discoveryengine_v1beta.SearchRequest.QueryExpansionSpec.Condition.AUTO,
                ),
                spell_correction_spec=discoveryengine_v1beta.SearchRequest.SpellCorrectionSpec(
                    mode=discoveryengine_v1beta.SearchRequest.SpellCorrectionSpec.Mode.AUTO,
                )
            )
            
            # Execute the search
            response = search_client.search(request)
            
            # Process and format the results
            results = []
            for result in response.results:
                document = {
                    'id': result.document.id,
                    'content': result.document.derived_struct_data,
                    'score': result.relevance_score,
                    'metadata': dict(result.document.struct_data)
                }
                results.append(document)
            
            return results
            
        except Exception as e:
            logger.error(f"Error searching documents: {str(e)}")
            raise
            
    def generate_response(self, query: str, context_docs: List[Dict]) -> str:
        """
        Generate a response using Vertex AI Gemini model with retrieved context.
        
        Args:
            query: User query
            context_docs: Retrieved documents to use as context
            
        Returns:
            Generated response string
        """
        try:
            # Prepare context from retrieved documents
            context = "\n\n".join([
                f"Document {i+1}:\n{doc['content']}"
                for i, doc in enumerate(context_docs)
            ])
            
            # Create prompt with query and context
            prompt = f"""
            Based on the following context documents, please answer the query.
            
            Query: {query}
            
            Context:
            {context}
            
            Please provide a clear and concise answer based on the context provided.
            If the context doesn't contain enough information to answer the query,
            please indicate that.
            """
            
            # Generate response using Vertex AI Gemini
            model = vertexai.GenerativeModel('gemini-pro')
            response = model.generate_content(prompt)
            
            return response.text
            
        except Exception as e:
            logger.error(f"Error generating response: {str(e)}")
            raise
            
    def process_query(self, query: str, max_results: int = 5) -> str:
        """
        Process a user query using the RAG pipeline.
        
        Args:
            query: User query string
            max_results: Maximum number of documents to retrieve
            
        Returns:
            Generated response string
        """
        try:
            # 1. Search for relevant documents
            relevant_docs = self.search_documents(query, max_results)
            
            # 2. Generate response using retrieved documents
            response = self.generate_response(query, relevant_docs)
            
            return response
            
        except Exception as e:
            logger.error(f"Error processing query: {str(e)}")
            raise

def vertex_rag_search_tool(query: str, max_results: int = 3):
    """
    Retrieve top N relevant documents from Vertex AI Search based on the user query.
    Returns a list of document snippets or summaries.
    """
    SEARCH_ENGINE_ID = os.getenv("VERTEX_SEARCH_ENGINE_ID")
    DATA_STORE_ID = os.getenv("VERTEX_DATA_STORE_ID")
    PROJECT_ID = os.getenv("VERTEX_PROJECT_ID", "project-rasheed-466518")
    LOCATION = os.getenv("VERTEX_LOCATION", "us-central1")

    search_engine_path = search_client.search_service_path(
        project=PROJECT_ID,
        location=LOCATION,
        data_store=DATA_STORE_ID,
        engine=SEARCH_ENGINE_ID
    )
    try:
        request = discoveryengine_v1beta.SearchRequest(
            serving_config=search_engine_path,
            query=query,
            page_size=max_results,
            query_expansion_spec=discoveryengine_v1beta.SearchRequest.QueryExpansionSpec(
                condition=discoveryengine_v1beta.SearchRequest.QueryExpansionSpec.Condition.AUTO,
            ),
            spell_correction_spec=discoveryengine_v1beta.SearchRequest.SpellCorrectionSpec(
                mode=discoveryengine_v1beta.SearchRequest.SpellCorrectionSpec.Mode.AUTO,
            )
        )
        response = search_client.search(request)
        results = []
        for result in response.results:
            snippet = result.document.derived_struct_data or str(result.document.struct_data)
            results.append(snippet)
        return results
    except Exception as e:
        logger.error(f"Error in vertex_rag_search_tool: {e}")
        return []

