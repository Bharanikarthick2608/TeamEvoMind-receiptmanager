import mysql.connector
import csv
from datetime import datetime

# Step 1: Connect to MySQL
connection = mysql.connector.connect(
    host='34.10.48.227',
    user='root',
    password='',
    database='Receiptsdetails'
)

cursor = connection.cursor()

# Step 2: Drop and Create Table (optional reset)
create_table_query = """
DROP TABLE IF EXISTS receipt;
"""

cursor.execute(create_table_query)

create_table_query = """
CREATE TABLE IF NOT EXISTS receipt (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    receipt_id VARCHAR(200),
    item_name VARCHAR(255) NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    total_price DECIMAL(10, 2) NOT NULL,
    category VARCHAR(100),
    purchase_date DATE NOT NULL,
    store_address VARCHAR(255),
    merchant_name VARCHAR(255),
    month VARCHAR(20),
    unit VARCHAR(50)
);
"""

cursor.execute(create_table_query)
connection.commit()

# Step 3: Read CSV & Insert Data
csv_file_path = r'C:\Users\Ria Liz Luke\Desktop\Google Hackathon\hackathonday1\raseed_chatbot\raseed\receipt_data.csv'  # 🔁 Change this to your CSV file path

all_values = []
with open(csv_file_path, mode='r', encoding='utf-8') as file:
    reader = csv.DictReader(file)
    for row in reader:
        # Clean and convert fields
        receipt_id = row['receipt_id']
        item_name = row['item_name']
        quantity = int(row['quantity']) if row['quantity'] else 0
        unit_price = float(row['unit_price']) if row['unit_price'] else 0.0
        total_price = float(row['total_price']) if row['total_price'] else 0.0
        category = row['category']
        purchase_date_raw = row['purchase_date']
        # Try to parse as DD-MM-YYYY, fallback to YYYY-MM-DD
        try:
            # Try DD-MM-YYYY
            purchase_date = datetime.strptime(purchase_date_raw, "%d-%m-%Y").date()
        except ValueError:
            try:
                # Try YYYY-MM-DD
                purchase_date = datetime.strptime(purchase_date_raw, "%Y-%m-%d").date()
            except ValueError:
                # Fallback to a default date
                purchase_date = datetime.strptime("2000-01-01", "%Y-%m-%d").date()
       
        store_address = row['store_address']
        merchant_name = row['merchant_name']
        month = row['month']
        unit = row['unit']

        insert_query = """
INSERT INTO receipt (
    receipt_id, item_name, quantity, unit_price, total_price, category, 
    purchase_date, store_address, merchant_name, month, unit
) VALUES (
    %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
)
"""

        values = (
            receipt_id, item_name, quantity, unit_price, total_price, category, 
            purchase_date, store_address, merchant_name, month, unit
        )
        all_values.append(values)

cursor.executemany(insert_query, all_values)
connection.commit()

# Step 4: Commit and Close
connection.commit()
cursor.close()
connection.close()

print("✅ CSV data inserted into 'receipt' table.")
