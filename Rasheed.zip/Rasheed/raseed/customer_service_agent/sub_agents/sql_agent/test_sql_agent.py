import logging
from agent import sql_data_querying_tool, execute_query

# Configure logging
logging.basicConfig(level=logging.INFO)

def debug_database():
    """Check actual data in the database"""
    print("\n=== Debugging Database Content ===")
    
    # Check unique categories
    category_query = "SELECT DISTINCT TRIM(category) as category FROM receipt"
    print("\nChecking all unique categories:")
    result = execute_query(category_query)
    print(result)
    
    # Check data for April
    april_query = "SELECT TRIM(category) as category, TRIM(month) as month, total_price FROM receipt WHERE LOWER(TRIM(month)) = 'april'"
    print("\nChecking all April records:")
    result = execute_query(april_query)
    print(result)

# Run debug queries
debug_database()

# Original test
test_query = "What's my total spending on groceries in April?"
print(f"\nTesting question: {test_query}")
sql_query = sql_data_querying_tool(test_query)
print("\nGenerated SQL query:")
print(sql_query)
try:
    result = execute_query(sql_query)
    print("\nQuery result:")
    print(result)
except Exception as e:
    print(f"Error executing query: {e}") 


    