from google.adk.agents import Agent, SequentialAgent
from langchain_community.tools.sql_database.tool import QuerySQLDatabaseTool
# from google.adk.tools.sql_data_querying_tool import sql_data_querying_tool 
import google.generativeai as genai
import os 
import sys
import re
import logging
from typing import Dict, Any, List
import mysql.connector
from datetime import datetime
from google.oauth2 import service_account
from google.cloud import aiplatform
import time
from google.adk.tools import agent_tool
from google.adk.tools import FunctionTool
from google.adk.tools import LongRunningFunctionTool
import re
# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load service account credentials with correct path
credentials_path = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))),
    "project-rasheed-466518-5cdff45af981.json"
)

# Add debug logging
logger.info(f"Looking for credentials file at: {credentials_path}")
if not os.path.exists(credentials_path):
    raise FileNotFoundError(f"Service account JSON file not found at: {credentials_path}")

credentials = service_account.Credentials.from_service_account_file(
    credentials_path,
    scopes=[
        'https://www.googleapis.com/auth/cloud-platform',
        'https://www.googleapis.com/auth/generative-language'
    ]
)

# Initialize Vertex AI with service account
aiplatform.init(
    project="project-rasheed-466518",
    location="us-central1",
    credentials=credentials
)

# Set up environment for google.generativeai
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = credentials_path

# MySQL Configuration
DB_CONFIG = {
    'host': '34.10.48.227',
    'user': 'root',
    'password': '',  # Update if needed
    'database': 'Receiptsdetails',
    'port': 3306,
    'connect_timeout': 10,
    'allow_local_infile': True,
    'raise_on_warnings': True
}

def get_db_connection():
    """Create and return a database connection with retry logic"""
    max_retries = 3
    retry_delay = 2  # seconds
    
    for attempt in range(max_retries):
        try:
            connection = mysql.connector.connect(**DB_CONFIG)
            connection.ping(reconnect=True, attempts=3, delay=5)
            return connection
        except mysql.connector.Error as err:
            logger.error(f"Database connection attempt {attempt + 1} failed: {err}")
            if attempt == max_retries - 1:
                raise
            time.sleep(retry_delay * (attempt + 1))

# Initialize database connection
try:
    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)
    logger.info("Successfully connected to database")
except Exception as e:
    logger.error(f"Failed to connect to database: {e}")
    raise

current_date = datetime.now().strftime("%Y-%m-%d")

def sql_data_querying_tool(query: str) -> str:
    """
    Generate a SQL query based on the user input for the table "receipt".
    """
    schema_description = """
# Table Name: receipt  
**Table Description:** This table is in a MySQL database (Google Cloud SQL). It contains all the products that the user has bought and added to receipts in google wallet until now.

### Columns:
item_name : name of the item purchased (e.g., 'Nandini Fresh Milk', 'MTR Rava Idli Mix')
quantity : quantity of item purchased (numeric)
unit_price : price per unit (numeric with decimals)
total_price : total price for the quantity (numeric)
category : category of item (IMPORTANT: [Food & Drinks, Shopping, Housing, communication and PC, Life & Entertainment] are valid categories)
purchase_date : date of purchase (format: YYYY-MM-DD)
store_address : full store address (e.g., 'Brigade Road Bengaluru Karnataka 560001')
merchant_name : store name (e.g., 'More Megastore')
month : month of purchase (lowercase, e.g., 'april')
unit : unit of measurement (e.g., 'ltr', 'kg', 'gm', 'pcs', 'pair')

Note: When users ask about groceries or food items, use category = 'Food & Drinks'
"""

    prompt = f"""
You are the SQL specialist on our customer service team. You handle all queries about users' purchase history, spending patterns, and receipt data.

Sample user queries:
- Questions about past purchases ("What did I buy last month?")
- Spending analysis ("How much did I spend on groceries?")
- Receipt lookups ("Show me my purchases from More Megastore")
- Category analysis ("What's my biggest spending category?")
- Time-based queries ("What did I buy in April?")
- Store-specific spending ("How much did I spend at Apollo?")

table_schema : {schema_description}

Technical Requirements for SQL Queries:
1. Always use TRIM() for string comparisons: TRIM(column_name)
2. Handle case for all columns: LOWER(TRIM(month))
3. Use exact category names as listed above (make it lower while comparing)
4. Use IFNULL/COALESCE for totals
5. Use table alias 'r' for receipt table
6. Use proper date format: purchase_date = 'YYYY-MM-DD'
7. All whitespace characters are standard spaces (ASCII U+0020).
8. Do NOT use non-breaking spaces (U+00A0) or other non-standard whitespace.
9. The query must be syntactically correct and copy-pasteable into MySQL without modification.
10. Strictly Write the query in one single line, not multiple lines.

Response Style:
- STRICT: Output ONLY the SQL query, and nothing else, inside a single code block formatted as ```sql ...```.
- Do NOT include any explanation, comments, or extra text before or after the code block.
- The code block must start with ```sql on its own line, and end with ``` on its own line.

Now, based on the user's question: {query}

SQL Query:
"""
    try:
        model = genai.GenerativeModel("gemini-2.5-flash")
        response = model.generate_content(prompt)
        sql_query = response.text.strip()
        if sql_query.startswith('```sql'):
            sql_query = sql_query[6:]
        if sql_query.endswith('```'):
            sql_query = sql_query[:-3]
        return sql_query.strip()
    except Exception as e:
        logging.error(f"Error generating SQL query: {str(e)}")
        raise

def execute_query(query: str, max_retries: int = 3):
    """
    Execute a SQL query on the MySQL database with retry logic.
    Will attempt to execute the query up to max_retries times if there are errors.
    """
    for attempt in range(max_retries):
        try:
            logging.info(f"Executing query (attempt {attempt + 1}/{max_retries}): {query}")
            cursor.execute(query)
            result = cursor.fetchall()
            logging.info(f"Query executed successfully, retrieved {len(result)} records.")
            return result
        except Exception as e:
            logging.error(f"Error executing query (attempt {attempt + 1}/{max_retries}): {e}")
            if attempt == max_retries - 1:  # Last attempt
                raise  # Re-raise the last error if all retries failed
            else:
                # Wait a bit before retrying (exponential backoff)
                wait_time = (2 ** attempt) * 0.1  # 0.1s, 0.2s, 0.4s
                logging.info(f"Waiting {wait_time:.1f}s before retry...")
                time.sleep(wait_time)
                continue


def draft_response(user_query: str, query_result: Any) -> str:
    """
    Draft a conversational, helpful response for the user based on their question and the SQL query result.
    Uses Gemini LLM to generate the response.
    """
    prompt = f"""
You are a friendly, helpful assistant. Given the user's question and the data retrieved from their purchase history, draft a conversational, clear, and context-aware response. 
- Reference the user's question.
- Summarize or highlight the most relevant information from the data.
- Do NOT mention SQL, queries, or technical details.
- Be enthusiastic and polite.
- If the data is empty or no results are found, apologize and suggest what the user can try next.
- Always return Rs for currency, dont use any other currency symbol.
User question: {user_query}

Data retrieved: {query_result}

Your response:
"""
    try:
        model = genai.GenerativeModel("gemini-2.5-flash")
        response = model.generate_content(prompt)
        return response.text.strip()
    except Exception as e:
        logging.error(f"Error generating conversational response: {str(e)}")
        return "Sorry, I couldn't generate a response at this time. Please try again later."

def sanitize_sql_query(raw_query: str) -> str:
    """
    Replaces all non-breaking spaces and non-standard whitespace characters
    in a SQL query with standard ASCII space (U+0020), and normalizes spacing.
    
    Args:
        raw_query (str): The original SQL query with potential non-breaking spaces.

    Returns:
        str: A sanitized, MySQL-safe SQL query string.
    """
    # Replace all types of whitespace (including U+00A0) with regular spaces
    cleaned_query = re.sub(r'[\s\u00A0]+', ' ', raw_query)
    
    # Strip leading/trailing whitespace
    return cleaned_query.strip()

def sql_agent(query: str) -> str:
    """
    Generate a SQL query based on the user input for the table "receipt" and execute it, retrying up to 3 times if execution fails (regenerating the SQL each time).
    """
    max_retries = 3
    for attempt in range(max_retries):
        sql_query = sql_data_querying_tool(query)
        sql_query_sanitized = sanitize_sql_query(sql_query)
        try:
            result = execute_query(sql_query_sanitized)
            response = draft_response(query, result)
            return response
        except Exception as e:
            logging.error(f"Attempt {attempt+1}/{max_retries}: Error executing generated SQL: {e}")
            if attempt == max_retries - 1:
                raise  # Re-raise the last error if all retries failed
            logging.info(f"Retrying: Regenerating SQL and trying again...")
    # Should not reach here
    raise RuntimeError("Failed to generate and execute a valid SQL query after 3 attempts.")

