from google.cloud import firestore
from google.oauth2 import service_account

# Load service account credentials
credentials_path = "project-rasheed-466518-5cdff45af981.json"
credentials = service_account.Credentials.from_service_account_file(
    credentials_path,
    scopes=['https://www.googleapis.com/auth/cloud-platform']
)

# will act on behalf of. If not supplied, the client falls back to the default
# project inferred from the environment.
db = firestore.Client(project="project-rasheed-466518", credentials=credentials)