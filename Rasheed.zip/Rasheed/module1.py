import os
import io
from google.cloud import vision
from google.cloud import videointelligence
from google.cloud import translate_v2 as translate
from google.oauth2 import service_account
from google.cloud import firestore
import vertexai
from vertexai.generative_models import GenerativeModel
from typing import Dict, Any, List
import json
import time
import uuid
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from google.auth import jwt, crypt

def get_currency_symbol(currency_code: str) -> str:
    """
    Map currency code to currency symbol.
    
    Args:
        currency_code (str): ISO currency code (e.g., 'INR', 'USD', 'EUR')
        
    Returns:
        str: Currency symbol (e.g., '₹', '$', '€')
    """
    currency_symbols = {
        'INR': '₹',
        'USD': '$',
        'EUR': '€',
        'GBP': '£',
        'JPY': '¥',
        'CNY': '¥',
        'AED': 'د.إ',
        'SAR': '﷼',
        'CAD': 'C$',
        'AUD': 'A$',
        'CHF': 'CHF',
        'SGD': 'S$',
        'HKD': 'HK$',
        'KRW': '₩',
        'THB': '฿',
        'MYR': 'RM',
        'PHP': '₱',
        'IDR': 'Rp',
        'VND': '₫',
        'BRL': 'R$',
        'MXN': 'MX$',
        'RUB': '₽',
        'TRY': '₺',
        'ZAR': 'R',
        'PLN': 'zł',
        'CZK': 'Kč',
        'HUF': 'Ft',
        'NOK': 'kr',
        'SEK': 'kr',
        'DKK': 'kr',
        'ILS': '₪',
        'EGP': 'E£',
        'LKR': 'Rs',
        'PKR': 'Rs',
        'BDT': '৳',
        'NPR': 'Rs',
        'MMK': 'K',
        'LAK': '₭',
        'KHR': '៛',
        'TWD': 'NT$',
        'QAR': '﷼',
        'KWD': 'د.ك',
        'BHD': 'د.ب',
        'OMR': '﷼',
        'JOD': 'د.ا',
        'LBP': 'ل.ل',
        'SYP': '£',
        'IQD': 'د.ع',
        'IRR': '﷼',
        'AFN': '؋',
        'UZS': 'лв',
        'KZT': '₸',
        'KGS': 'лв',
        'TJS': 'SM',
        'TMT': 'T',
        'GEL': '₾',
        'AMD': '֏',
        'AZN': '₼',
        'BYN': 'Br',
        'MDL': 'L',
        'UAH': '₴',
        'RON': 'lei',
        'BGN': 'лв',
        'HRK': 'kn',
        'RSD': 'РСД',
        'BAM': 'KM',
        'MKD': 'ден',
        'ALL': 'L',
        'COP': '$',
        'PEN': 'S/',
        'CLP': '$',
        'UYU': '$U',
        'BOB': 'Bs',
        'VES': 'Bs',
        'GYD': '$',
        'SRD': '$',
        'XCD': '$',
        'BBD': '$',
        'JMD': 'J$',
        'HTG': 'G',
        'DOP': 'RD$',
        'CUP': '$',
        'GTQ': 'Q',
        'BZD': 'BZ$',
        'NIO': 'C$',
        'CRC': '₡',
        'PAB': 'B/.',
        'HNL': 'L',
        'SVC': '$',
    }
    
    return currency_symbols.get(currency_code, currency_code)

class TextExtractorProcessor:
    def __init__(self, credentials_path: str, project_id: str):
        """
        Initialize Google Cloud APIs with service account credentials.
        
        Args:
            credentials_path (str): Path to Google Cloud service account JSON
            project_id (str): Google Cloud project ID
        """
        self.credentials_path = credentials_path
        self.project_id = project_id
        self.credentials = self._load_credentials()
        
        # Initialize clients
        self.vision_client = self._initialize_vision_client()
        self.video_client = self._initialize_video_client()
        self.translate_client = self._initialize_translate_client()
        self._initialize_vertex_ai()
        self.wallet_client = self._initialize_wallet_client()
        self.firestore_client = self._initialize_firestore_client()
        
    def _load_credentials(self) -> service_account.Credentials:
        """Load service account credentials."""
        try:
            credentials = service_account.Credentials.from_service_account_file(
                self.credentials_path,
                scopes=[
                    'https://www.googleapis.com/auth/cloud-platform',
                    'https://www.googleapis.com/auth/wallet_object.issuer'
                ]
            )
            print("✅ Service account credentials loaded")
            return credentials
        except Exception as e:
            print(f"❌ Error loading credentials: {e}")
            raise
    
    def _initialize_vision_client(self) -> vision.ImageAnnotatorClient:
        """Initialize Google Vision API client."""
        try:
            client = vision.ImageAnnotatorClient(credentials=self.credentials)
            print("✅ Vision API client initialized")
            return client
        except Exception as e:
            print(f"❌ Error initializing Vision API: {e}")
            raise
    
    def _initialize_video_client(self) -> videointelligence.VideoIntelligenceServiceClient:
        """Initialize Google Video Intelligence API client."""
        try:
            client = videointelligence.VideoIntelligenceServiceClient(credentials=self.credentials)
            print("✅ Video Intelligence API client initialized")
            return client
        except Exception as e:
            print(f"❌ Error initializing Video Intelligence API: {e}")
            raise
    
    def _initialize_translate_client(self) -> translate.Client:
        """Initialize Google Cloud Translation API client."""
        try:
            client = translate.Client(credentials=self.credentials)
            print("✅ Translation API client initialized")
            return client
        except Exception as e:
            print(f"❌ Error initializing Translation API: {e}")
            raise
    
    def _initialize_vertex_ai(self) -> None:
        """Initialize Vertex AI for gemini-2.5-flash Pro."""
        try:
            vertexai.init(
                project=self.project_id,
                credentials=self.credentials,
                location="us-central1"
            )
            self.gemini_model = GenerativeModel("gemini-2.5-flash")
            print("✅ Vertex AI (gemini-2.5-flash Pro) initialized")
        except Exception as e:
            print(f"❌ Error initializing Vertex AI: {e}")
            raise
    
    def _initialize_wallet_client(self):
        """Initialize Google Wallet API client."""
        try:
            client = build('walletobjects', 'v1', credentials=self.credentials)
            print("✅ Google Wallet API client initialized")
            return client
        except Exception as e:
            print(f"❌ Error initializing Wallet API: {e}")
            raise
    
    def _initialize_firestore_client(self) -> firestore.Client:
        """Initialize Google Cloud Firestore client."""
        try:
            client = firestore.Client(credentials=self.credentials)
            print("✅ Firestore client initialized")
            return client
        except Exception as e:
            print(f"❌ Error initializing Firestore client: {e}")
            raise
    
    def extract_text_from_image(self, image_path: str) -> str:
        """
        Extract text from image using Vision API.
        
        Args:
            image_path (str): Path to the image file
            
        Returns:
            str: Extracted text
        """
        try:
            with io.open(image_path, 'rb') as image_file:
                content = image_file.read()
            
            image = vision.Image(content=content)
            
            # Use document text detection for better OCR results
            response = self.vision_client.document_text_detection(image=image)
            
            if response.error.message:
                raise Exception(f"Vision API Error: {response.error.message}")
            
            if response.full_text_annotation:
                extracted_text = response.full_text_annotation.text.strip()
                print("✅ Text extracted successfully")
                return extracted_text
            else:
                print("⚠️  No text found in image")
                return ""
                
        except Exception as e:
            print(f"❌ Error extracting text: {e}")
            raise
    
    def extract_text_from_video(self, video_path: str) -> str:
        """
        Extract text from video using Video Intelligence API.
        
        Args:
            video_path (str): Path to the video file or GCS URI
            
        Returns:
            str: Extracted text from video
        """
        try:
            # Read video file
            if video_path.startswith('gs://'):
                # GCS URI
                input_uri = video_path
                with_file = False
            else:
                # Local file
                with io.open(video_path, 'rb') as video_file:
                    input_content = video_file.read()
                with_file = True
            
            # Configure the request
            features = [videointelligence.Feature.TEXT_DETECTION]
            
            if with_file:
                operation = self.video_client.annotate_video(
                    request={
                        "input_content": input_content,
                        "features": features,
                    }
                )
            else:
                operation = self.video_client.annotate_video(
                    request={
                        "input_uri": input_uri,
                        "features": features,
                    }
                )
            
            print("🎬 Processing video for text detection...")
            result = operation.result(timeout=100)  #  seconds timeout
            
            # Extract text annotations
            extracted_texts = []
            for video_annotation in result.annotation_results:
                for text_annotation in video_annotation.text_annotations:
                    for segment in text_annotation.segments:
                        extracted_texts.append(text_annotation.text)
            
            if extracted_texts:
                combined_text = " ".join(set(extracted_texts))  # Remove duplicates
                print("✅ Text extracted from video successfully")
                return combined_text
            else:
                print("⚠️  No text found in video")
                return ""
                
        except Exception as e:
            print(f"❌ Error extracting text from video: {e}")
            raise
    

    
    def translate_to_english(self, text: str) -> str:
        """
        Translate text to English using Cloud Translation API.
        
        Args:
            text (str): Text to translate
            
        Returns:
            str: Translated text in English
        """
        if not text.strip():
            return text
            
        try:
            # Detect language first
            detection = self.translate_client.detect_language(text)
            detected_language = detection['language']
            
            # Translate to English if not already in English
            if detected_language != 'en':
                result = self.translate_client.translate(
                    text,
                    target_language='en',
                    source_language=detected_language
                )
                translated_text = result['translatedText']
                print(f"✅ Text translated from {detected_language} to English")
                return translated_text
            else:
                print("✅ Text already in English")
                return text
                
        except Exception as e:
            print(f"❌ Error translating text: {e}")
            raise
    
    def structure_with_gemini(self, original_text: str, translated_text: str, image_path: str) -> Dict[str, Any]:
        """
        Use gemini-2.5-flash Pro to structure the data into key-value pairs.
        
        Args:
            original_text (str): Original extracted text
            translated_text (str): English translated text
            image_path (str): Path to the processed image
            
        Returns:
            Dict: Structured key-value pairs
        """
        try:
            # Generate unique receipt ID
            receipt_id = f"REC_{int(time.time())}_{str(uuid.uuid4())[:8].upper()}"
            
            # Determine input type for context
            input_type = self.detect_input_type(image_path)
            
            prompt = f"""
            You are a highly accurate data extraction and structuring agent. Your task is to analyze the provided text extracted from a {input_type} (e.g., image, video frame, PDF, or OCR output) and generate a well-structured, machine-readable JSON object.

            ### English Translation:
            {translated_text}

            ### Objective:
            Identify and extract all relevant fields from the receipt and classify items into appropriate categories.

            Your output should contain **cleaned and normalized key-value pairs** with items grouped by categories. Focus especially on:
            - Total amount (regardless of label variation like "toal", "total payable", "grand total", "amount due", etc.)
            - Taxes (extract individual tax lines like CGST, SGST, VAT, etc., and compute a combined "tax_total")
            - Merchant name (from headers, logos, or phrases like "Thank you for shopping at ...")
            - Purchase date (in standard ISO format YYYY-MM-DD)
            - Itemized purchases grouped by category with price, quantity, and unit of measurement
            - Calculate totals for each category

            ---

            ### 🧾 Receipt JSON Format:
            Use the following structure for receipts:

            {{
            "document_type": "receipt",
            "receipt_id": "{receipt_id}",
            "merchant_name": "<string>",
            "total_amount": "<string>",
            "tax_total": "<string>",
            "date": "<YYYY-MM-DD>",
            "currency": "<ISO Currency Code if available>",
            "payment_method": "<cash/card/upi/etc. if mentioned>",
            "invoice_number": "<string if present>",
            "timestamp": "<HH:MM if available>",
            "store_address": "<address if available>",
            "details": {{
                "Category Name": {{
                    "Item Name": {{
                        "price": "<unit price as string>",
                        "quantity": "<number as string>",
                        "unit": "<unit of measurement>"
                    }}
                }}
            }},
            "product_category": ["Category1", "Category2", "..."],
            "category_total": {{
                "Category1": "<total amount for category>",
                "Category2": "<total amount for category>"
            }}
            }}

            ### 📦 Available Categories (MUST use these exact names):
            - Food & Drinks
            - Shopping  
            - Housing
            - Transportation
            - Life & Entertainment
            - Communication, PC
            - Financial expenses
            - Investments
            - Others

            ### ✅ Rules:
            - Identify and extract all relevant fields from the receipt—even if field names are miswritten, misspelled, or inconsistent.
            - Normalize all field names (e.g., "Toal Amnt", "Ttl", "TOTAL") to "total_amount".
            - For tax, extract all tax lines individually and add them to calculate `tax_total`.
            - Classify each item into ONE of the available categories above
            - Use exact category names from the list
            - For `unit`, identify and extract units of measurement from item descriptions:
              * Weight: "kg", "kgs", "gram", "grams", "gm", "g"
              * Volume: "lit", "litre", "liter", "ml", "milliliter"  
              * Count: "pieces", "pcs", "units", "nos", "packets", "bottles", "cans"
              * If no unit is mentioned, use "units" as default
            - Calculate accurate totals for each category (price × quantity for each item in category)
            - Ensure category totals add up to the receipt total (excluding tax)
            - Return **only valid JSON**
            - Do not include irrelevant text (greetings, promotions, etc.)

            ### 🔍 Category Classification Guidelines:
            - **Food & Drinks**: Restaurants, cafes, groceries, beverages, snacks, meals
            - **Shopping**: Clothing, electronics, books, general retail items
            - **Housing**: Rent, utilities, home maintenance, furniture
            - **Transportation**: Public transport, taxi, gas, parking
            - **Life & Entertainment**: Movies, games, sports, hobbies
            - **Communication, PC**: Phone bills, internet, software, hardware
            - **Financial expenses**: Bank fees, insurance, loans
            - **Investments**: Stocks, bonds, investment products
            - **Others**: Items that don't fit other categories

            If not a receipt (e.g., certificate, sign, form), structure the JSON accordingly with a clean, consistent key-value format and include `document_type` and `receipt_id` as the first fields.
            """

            
            response = self.gemini_model.generate_content(prompt)
            print("Gemini response: ", response.text)
            
            # Clean the response by removing markdown code block markers and fixing JSON issues
            response_text = response.text.strip()
            
            # Remove markdown code blocks
            if response_text.startswith('```json'):
                response_text = response_text[7:]  # Remove ```json
            elif response_text.startswith('```'):
                response_text = response_text[3:]   # Remove ```
            
            if response_text.endswith('```'):
                response_text = response_text[:-3]  # Remove ending ```
            
            response_text = response_text.strip()
            
            # Fix common JSON issues
            # Remove trailing commas before closing braces/brackets
            response_text = response_text.replace(',}', '}').replace(',]', ']')
            
            # Fix unclosed quotes and brackets
            response_text = response_text.replace('",', '",').replace('",', '",')
            
            # Remove any trailing commas in objects
            import re
            response_text = re.sub(r',(\s*[}\]])', r'\1', response_text)
            
            # Try to parse the JSON
            try:
                structured_data = json.loads(response_text)
            except json.JSONDecodeError as json_error:
                print(f"⚠️  JSON parsing error: {json_error}")
                print(f"⚠️  Attempting to fix JSON structure...")
                
                # Additional fixes for common issues
                # Fix missing quotes around property names
                response_text = re.sub(r'(\w+):', r'"\1":', response_text)
                
                # Fix unclosed strings
                response_text = re.sub(r'"([^"]*)$', r'"\1"', response_text)
                
                # Remove any remaining trailing commas
                response_text = re.sub(r',(\s*[}\]])', r'\1', response_text)
                
                try:
                    structured_data = json.loads(response_text)
                    print("✅ JSON fixed successfully")
                except json.JSONDecodeError:
                    print("❌ Could not fix JSON, using fallback structure")
                    return self._create_fallback_structure(original_text, translated_text, image_path)
            print("✅ Data structured successfully with gemini-2.5-flash Pro")
            return structured_data
            
        except json.JSONDecodeError as e:
            print(f"⚠️  Gemini response was not valid JSON, creating fallback structure")
            return self._create_fallback_structure(original_text, translated_text, image_path)
        except Exception as e:
            print(f"❌ Error structuring data with Gemini: {e}")
            return self._create_fallback_structure(original_text, translated_text, image_path)
    
    def _create_fallback_structure(self, original_text: str, translated_text: str, image_path: str) -> Dict[str, Any]:
        """Create a basic structure if Gemini processing fails."""
        # Generate unique receipt ID
        receipt_id = f"REC_{int(time.time())}_{str(uuid.uuid4())[:8].upper()}"
        
        return {
            "document_type": "receipt",
            "receipt_id": receipt_id,
            "product_category": "other",
            "image_path": image_path,
            "original_text": original_text,
            "translated_text": translated_text,
            "processing_status": "fallback_structure",
            "word_count": len(translated_text.split()) if translated_text else 0,
            "character_count": len(translated_text) if translated_text else 0
        }
    
    def detect_input_type(self, input_path: str) -> str:
        """
        Detect the type of input (image or video).
        
        Args:
            input_path (str): Path to the input file
            
        Returns:
            str: Type of input ('image' or 'video')
        """
        # Get file extension
        _, ext = os.path.splitext(input_path.lower())
        
        # Image formats
        image_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', '.webp'}
        if ext in image_extensions:
            return 'image'
        
        # Video formats
        video_extensions = {'.mp4', '.avi', '.mov', '.wmv', '.flv', '.webm', '.mkv', '.3gp'}
        if ext in video_extensions:
            return 'video'
        
        # Default to image if uncertain
        return 'image'
    
    def extract_text_universal(self, input_path: str) -> str:
        """
        Universal text extraction method that handles images and videos.
        
        Args:
            input_path (str): Path to input file
            
        Returns:
            str: Extracted text
        """
        input_type = self.detect_input_type(input_path)
        
        if input_type == 'image':
            return self.extract_text_from_image(input_path)
        elif input_type == 'video':
            return self.extract_text_from_video(input_path)
        else:
            raise ValueError(f"Unsupported input type: {input_type}")
    
    def process_input(self, input_path: str, save_to_firestore: bool = False) -> Dict[str, Any]:
        """
        Universal processing pipeline: Extract -> Translate -> Structure -> Optionally Save to Firestore.
        Supports images and videos.
        
        Args:
            input_path (str): Path to input file
            save_to_firestore (bool): Whether to save result to Firestore database
            
        Returns:
            Dict: Final structured key-value pairs
        """
        try:
            input_type = self.detect_input_type(input_path)
            print(f"🔄 Processing {input_type}: {input_path}")
            
            # Step 1: Extract text using appropriate API
            print(f"📸 Step 1: Extracting text from {input_type}...")
            original_text = self.extract_text_universal(input_path)
            
            if not original_text:
                return {
                    "error": f"No text found in {input_type}",
                    "input_path": input_path,
                    "input_type": input_type
                }
            
            # Step 2: Translate to English using Translation API
            print("🌐 Step 2: Translating to English...")
            translated_text = self.translate_to_english(original_text)
            
            # Step 3: Structure data using gemini-2.5-flash Pro
            print("🤖 Step 3: Structuring data with Gemini...")
            structured_data = self.structure_with_gemini(original_text, translated_text, input_path)
            
            # Add metadata
            structured_data["input_type"] = input_type
            structured_data["processing_timestamp"] = time.strftime("%Y-%m-%d %H:%M:%S")
            
            # Step 4: Optionally save to Firestore
            if save_to_firestore:
                print("💾 Step 4: Saving to Firestore...")
                firestore_doc_id = self.save_receipt_to_firestore(structured_data.copy())
                
                if firestore_doc_id:
                    structured_data["firestore_document_id"] = firestore_doc_id
                    structured_data["database_status"] = "saved_to_firestore"
                    print("✅ Receipt data saved to Firestore successfully!")
                else:
                    structured_data["database_status"] = "firestore_save_failed"
                    print("⚠️ Failed to save receipt data to Firestore")
            
            print("✅ Processing completed successfully")
            return structured_data
            
        except Exception as e:
            print(f"❌ Error in processing pipeline: {e}")
            return {
                "error": str(e),
                "input_path": input_path,
                "input_type": self.detect_input_type(input_path),
                "processing_stage": "pipeline_error"
            }
    
    def process_input_with_wallet(self, input_path: str, issuer_id: str) -> Dict[str, Any]:
        """
        Complete processing pipeline: Extract -> Translate -> Structure -> Create Google Wallet Pass -> Save to Firestore.
        
        Args:
            input_path (str): Path to input file
            issuer_id (str): Google Wallet issuer ID
            
        Returns:
            Dict: Final structured data with Google Wallet link and Firestore document ID
        """
        try:
            input_type = self.detect_input_type(input_path)
            print(f"🔄 Processing {input_type} with Google Wallet: {input_path}")
            
            # Step 1-3: Standard processing
            result = self.process_input(input_path)
            
            # Check if processing was successful
            if "error" in result:
                return result
            
            # Step 4: Create Google Wallet pass for any document type
            print("🎫 Step 4: Creating Google Wallet pass...")
            wallet_link = self.convert_receipt_to_pass(result, issuer_id)
            
            if wallet_link:
                result["google_wallet_link"] = wallet_link
                result["wallet_status"] = "pass_created"
                print("✅ Google Wallet pass created successfully!")
            else:
                result["wallet_status"] = "pass_creation_failed"
                print("⚠️ Failed to create Google Wallet pass")

            # Step 5: Save to Firestore database
            print("💾 Step 5: Saving receipt data to Firestore...")
            firestore_doc_id = self.save_receipt_to_firestore(result.copy())
            
            if firestore_doc_id:
                result["firestore_document_id"] = firestore_doc_id
                result["database_status"] = "saved_to_firestore"
                print("✅ Receipt data saved to Firestore successfully!")
            else:
                result["database_status"] = "firestore_save_failed"
                print("⚠️ Failed to save receipt data to Firestore")

            return result
            
        except Exception as e:
            print(f"❌ Error in wallet processing pipeline: {e}")
            return {
                "error": str(e),
                "input_path": input_path,
                "input_type": self.detect_input_type(input_path),
                "processing_stage": "wallet_pipeline_error"
            }

    def process_image(self, image_path: str) -> Dict[str, Any]:
        """
        Complete processing pipeline: Extract -> Translate -> Structure.
        
        Args:
            image_path (str): Path to the image file
            
        Returns:
            Dict: Final structured key-value pairs
        """
        try:
            print(f"🔄 Processing: {image_path}")
            
            # Step 1: Extract text using Vision API
            print("📸 Step 1: Extracting text...")
            original_text = self.extract_text_from_image(image_path)
            
            if not original_text:
                return {
                    "error": "No text found in image",
                    "image_path": image_path
                }
            
            # Step 2: Translate to English using Translation API
            print("🌐 Step 2: Translating to English...")
            translated_text = self.translate_to_english(original_text)
            
            # Step 3: Structure data using gemini-2.5-flash Pro
            print("🤖 Step 3: Structuring data with Gemini...")
            structured_data = self.structure_with_gemini(original_text, translated_text, image_path)
            
            print("✅ Processing completed successfully")
            return structured_data
            
        except Exception as e:
            print(f"❌ Error in processing pipeline: {e}")
            return {
                "error": str(e),
                "image_path": image_path,
                "processing_stage": "pipeline_error"
            }
    
    def save_results(self, results: Dict[str, Any], output_file: str = "structured_results.json") -> None:
        """Save results to JSON file."""
        try:
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(results, f, indent=2, ensure_ascii=False)
            print(f"✅ Results saved to: {output_file}")
        except Exception as e:
            print(f"❌ Error saving results: {e}")
    
    def create_receipt_class(self, issuer_id: str) -> str:
        """Create a generic receipt class for Google Wallet."""
        class_suffix = "receipt_class"
        class_id = f'{issuer_id}.{class_suffix}'
        
        # Check if class already exists
        try:
            self.wallet_client.genericclass().get(resourceId=class_id).execute()
            print(f'✅ Receipt class {class_id} already exists')
            return class_id
        except HttpError as e:
            if e.status_code != 404:
                print(f"❌ Error checking class: {e}")
                return class_id
        
        # Create new class
        new_class = {
            'id': class_id,
            'issuerName': 'Receipt Manager',
            'localizedIssuerName': {
                'defaultValue': {
                    'language': 'en-US',
                    'value': 'Receipt Manager'
                }
            }
        }
        
        try:
            response = self.wallet_client.genericclass().insert(body=new_class).execute()
            print(f'✅ Created receipt class: {class_id}')
            return class_id
        except Exception as e:
            print(f"❌ Error creating class: {e}")
            return class_id
    
    def convert_receipt_to_pass(self, receipt_data: Dict[str, Any], issuer_id: str) -> str:
        """Convert structured receipt data to Google Wallet pass using reference implementation."""
        try:
            # Generate unique suffixes
            class_suffix = "receipt_class"
            object_suffix = str(uuid.uuid4()).replace('-', '_')
            
            # Use the reference implementation method
            return self.create_jwt_new_objects(issuer_id, class_suffix, object_suffix, receipt_data)
            
        except Exception as e:
            print(f"❌ Error creating wallet pass: {e}")
            return ""

    def create_jwt_new_objects(self, issuer_id: str, class_suffix: str, object_suffix: str, receipt_data: Dict[str, Any] = None) -> str:
        """Generate a signed JWT that creates a new pass class and object following Google's reference implementation.

        When the user opens the "Add to Google Wallet" URL and saves the pass to
        their wallet, the pass class and object defined in the JWT are
        created. This allows you to create multiple pass classes and objects in
        one API call when the user saves the pass to their wallet.

        Args:
            issuer_id (str): The issuer ID being used for this request.
            class_suffix (str): Developer-defined unique ID for the pass class.
            object_suffix (str): Developer-defined unique ID for the pass object.
            receipt_data (Dict): Optional receipt data to customize the pass.

        Returns:
            An "Add to Google Wallet" link.
        """

        # Create class following reference format
        new_class = {'id': f'{issuer_id}.{class_suffix}'}

        # Extract receipt data if provided
        if receipt_data:
            merchant_name = receipt_data.get('merchant_name', 'Receipt')
            total_amount = receipt_data.get('total_amount', '0.00')
            date = receipt_data.get('date', 'Unknown Date')
            details = receipt_data.get('details', {})
            product_categories = receipt_data.get('product_category', [])
            category_totals = receipt_data.get('category_total', {})
            currency_code = receipt_data.get('currency', 'USD')
            currency_symbol = get_currency_symbol(currency_code)
            
            # Count total items across all categories
            total_items = 0
            for category in details.values():
                total_items += len(category)
            
            # Create text modules for receipt
            text_modules = [{
                'header': 'Receipt Summary',
                'body': f'Total: {currency_symbol}{total_amount}\nDate: {date}\nItems: {total_items}\nCategories: {len(product_categories)}',
                'id': 'RECEIPT_SUMMARY'
            }]
            
            # Add category totals (limit to 3 for wallet display)
            for i, category in enumerate(list(product_categories)):
                category_total = category_totals.get(category, '0.00')
                text_modules.append({
                    'header': f'{category}',
                    'body': f'Total: {currency_symbol}{category_total}',
                    'id': f'CATEGORY_{i+1}'
                })

            # You can add individual items too (up to 40 total modules)
            item_count = 0
            for category, items in details.items():
                for item_name, item_data in items.items():
                    if item_count < 35:  # Save some slots for categories
                        text_modules.append({
                            'header': item_name,
                            'body': f"{currency_symbol}{item_data['price']} × {item_data['quantity']} {item_data['unit']}",
                            'id': f'ITEM_{item_count}'
                        })
                        item_count += 1
        else:
            # Default text module
            text_modules = [{
                'header': 'Receipt Information',
                'body': 'Digital receipt stored in your wallet',
                'id': 'DEFAULT_MODULE'
            }]

        # Create object following reference format
        new_object = {
            'id': f'{issuer_id}.{object_suffix}',
            'classId': f'{issuer_id}.{class_suffix}',
            'state': 'ACTIVE',
            'cardTitle': {
                'defaultValue': {
                    'language': 'en-US',
                    'value': f'Receipt - {receipt_data.get("merchant_name", "Digital Receipt") if receipt_data else "Digital Receipt"}'
                }
            },
            'header': {
                'defaultValue': {
                    'language': 'en-US',
                    'value': f'{get_currency_symbol(receipt_data.get("currency", "USD"))}{receipt_data.get("total_amount", "0.00")} • {receipt_data.get("date", "Today") if receipt_data else "Today"}'
                }
            },
            'textModulesData': text_modules,
            'linksModuleData': {
                'uris': [{
                    'uri': 'https://your-app.com/receipt-details',
                    'description': 'View full receipt details',
                    'id': 'RECEIPT_DETAILS_LINK'
                }]
            },
            'barcode': {
                'type': 'QR_CODE',
                'value': receipt_data.get('receipt_number', f'RECEIPT_{object_suffix}') if receipt_data else f'RECEIPT_{object_suffix}'
            },
            'hexBackgroundColor': '#4285f4',
            'logo': {
                'sourceUri': {
                    'uri': 'https://storage.googleapis.com/wallet-lab-tools-codelab-artifacts-public/pass_google_logo.jpg'
                },
                'contentDescription': {
                    'defaultValue': {
                        'language': 'en-US',
                        'value': 'Receipt logo'
                    }
                }
            }
        }

        # Create the JWT claims following reference implementation
        claims = {
            'iss': self.credentials.service_account_email,
            'aud': 'google',
            'origins':['localhost'],  # Replace with your domain
            'typ': 'savetowallet',
            'payload': {
                # The listed classes and objects will be created
                'genericClasses': [new_class],
                'genericObjects': [new_object]
            }
        }
        
        print("email address#################################################################################### = " , self.credentials.service_account_email)

        # The service account credentials are used to sign the JWT
        signer = crypt.RSASigner.from_service_account_file(self.credentials_path)
        token = jwt.encode(signer, claims).decode('utf-8')

        print('Add to Google Wallet link')
        print(f'https://pay.google.com/gp/v/save/{token}')

        return f'https://pay.google.com/gp/v/save/{token}'
    
    def _create_wallet_jwt(self, class_id: str, pass_object: Dict[str, Any], issuer_id: str) -> str:
        """Create JWT token for Add to Google Wallet link following Google's reference implementation."""
        try:
            # Create the pass class (minimal for JWT) - following reference format
            pass_class = {'id': class_id}
            
            # Create JWT claims following Google's reference implementation
            claims = {
                'iss': self.credentials.service_account_email,
                'aud': 'google',
                'origins':['localhost'],  # Replace with your actual domain
                'typ': 'savetowallet',
                'payload': {
                    # The listed classes and objects will be created
                    'genericClasses': [pass_class],
                    'genericObjects': [pass_object]
                }
            }
            
            # The service account credentials are used to sign the JWT - following reference
            signer = crypt.RSASigner.from_service_account_file(self.credentials_path)
            token = jwt.encode(signer, claims).decode('utf-8')
            
            wallet_link = f'https://pay.google.com/gp/v/save/{token}'
            print(f'🎫 Add to Google Wallet link: {wallet_link}')
            
            return wallet_link
            
        except Exception as e:
            print(f"❌ Error creating JWT: {e}")
            print(f"❌ Credentials path: {self.credentials_path}")
            print(f"❌ Service account email: {getattr(self.credentials, 'service_account_email', 'Not found')}")
            return ""

    def save_receipt_to_firestore(self, receipt_data: Dict[str, Any]) -> str:
        """
        Save receipt data to Firestore.
        
        Args:
            receipt_data (Dict): Structured receipt data to save.
            
        Returns:
            str: Document ID of the saved receipt.
        """
        try:
            # Use existing receipt_id if present, otherwise generate new one
            if "receipt_id" in receipt_data and receipt_data["receipt_id"]:
                receipt_id = receipt_data["receipt_id"]
            else:
                receipt_id = f"REC_{int(time.time())}_{str(uuid.uuid4())[:8].upper()}"
                receipt_data["receipt_id"] = receipt_id
            
            # Add processing timestamp if not present
            if "processing_timestamp" not in receipt_data:
                receipt_data["processing_timestamp"] = time.strftime("%Y-%m-%d %H:%M:%S")
            
            # Save to Firestore in "Receipts detail" collection
            doc_ref = self.firestore_client.collection("Receipts detail").document(receipt_id)
            doc_ref.set(receipt_data)
            print(f"✅ Receipt data saved to Firestore with ID: {receipt_id}")
            return receipt_id
        except Exception as e:
            print(f"❌ Error saving receipt to Firestore: {e}")
            return ""

    def fetch_all_receipts_from_firestore(self) -> List[Dict[str, Any]]:
        """
        Fetch all receipts from Firestore database.
        
        Returns:
            List[Dict]: List of all receipt documents from Firestore
        """
        try:
            receipts = []
            docs = self.firestore_client.collection("Receipts detail").stream()
            
            for doc in docs:
                receipt_data = doc.to_dict()
                receipt_data['firestore_id'] = doc.id
                receipts.append(receipt_data)
            
            print(f"✅ Fetched {len(receipts)} receipts from Firestore")
            return receipts
        except Exception as e:
            print(f"❌ Error fetching receipts from Firestore: {e}")
            return []

    def generate_spending_analysis(self, new_receipt_data: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Generate comprehensive spending analysis using direct calculations and Gemini LLM for insights.
        Fetches all existing receipts from Firestore and combines with new receipt data.
        
        Args:
            new_receipt_data (Dict): New receipt data to include in analysis
            
        Returns:
            Dict: Detailed spending analysis in JSON format
        """
        try:
            print("📊 Generating spending analysis...")
            
            # Fetch all existing receipts from Firestore
            existing_receipts = self.fetch_all_receipts_from_firestore()
            
            # Combine with new receipt data if provided
            all_receipts = existing_receipts.copy()
            if new_receipt_data:
                all_receipts.append(new_receipt_data)
            
            if not all_receipts:
                return {
                    "error": "No receipt data available for analysis",
                    "analysis_id": f"ANALYSIS_{int(time.time())}_{str(uuid.uuid4())[:8].upper()}",
                    "analysis_timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
                }
            
            # Direct mathematical calculations
            total_receipts = len(all_receipts)
            total_spending = 0
            currency_breakdown = {}
            category_totals = {}
            merchant_totals = {}
            monthly_totals = {}
            
            # Process each receipt for calculations
            for receipt in all_receipts:
                # Calculate total spending
                try:
                    amount = float(str(receipt.get("total_amount", "0")).replace("₹", "").replace(",", ""))
                    total_spending += amount
                    
                    # Currency breakdown
                    currency = receipt.get("currency", "INR")
                    currency_breakdown[currency] = currency_breakdown.get(currency, 0) + amount
                    
                    # Category totals
                    category_total = receipt.get("category_total", {})
                    for category, cat_amount in category_total.items():
                        try:
                            cat_value = float(str(cat_amount).replace("₹", "").replace(",", ""))
                            category_totals[category] = category_totals.get(category, 0) + cat_value
                        except (ValueError, TypeError):
                            pass
                    
                    # Merchant totals
                    merchant = receipt.get("merchant_name", "Unknown")
                    merchant_totals[merchant] = merchant_totals.get(merchant, 0) + amount
                    
                    # Monthly totals
                    date = receipt.get("date", "")
                    if date and len(date) >= 7:
                        month_key = date[:7]  # YYYY-MM format
                        monthly_totals[month_key] = monthly_totals.get(month_key, 0) + amount
                        
                except (ValueError, TypeError):
                    pass
            
            # Calculate averages and percentages
            average_receipt_value = total_spending / total_receipts if total_receipts > 0 else 0
            
            # Category percentages
            category_percentages = {}
            for category, amount in category_totals.items():
                if total_spending > 0:
                    category_percentages[category] = round((amount / total_spending) * 100, 1)
                else:
                    category_percentages[category] = 0
            
            # Find top merchant
            top_merchant_name = ""
            top_merchant_amount = 0
            if merchant_totals:
                top_merchant_name = max(merchant_totals, key=merchant_totals.get)
                top_merchant_amount = merchant_totals[top_merchant_name]
            
            # Find highest spending month
            highest_spending_month = ""
            highest_spending_month_amount = 0
            if monthly_totals:
                highest_spending_month = max(monthly_totals, key=monthly_totals.get)
                highest_spending_month_amount = monthly_totals[highest_spending_month]
            
            # Find highest and lowest categories
            highest_category_name = ""
            highest_category_amount = 0
            lowest_category_name = ""
            lowest_category_amount = 0
            if category_totals:
                highest_category_name = max(category_totals, key=category_totals.get)
                highest_category_amount = category_totals[highest_category_name]
                lowest_category_name = min(category_totals, key=category_totals.get)
                lowest_category_amount = category_totals[lowest_category_name]
            
            # Most frequent merchant (merchant with highest total)
            most_frequent_merchant_name = top_merchant_name
            most_frequent_merchant_amount = top_merchant_amount
            
            # Prepare data for LLM summary and suggestions
            receipts_summary = []
            for receipt in all_receipts:
                summary = {
                    "receipt_id": receipt.get("receipt_id", "Unknown"),
                    "merchant_name": receipt.get("merchant_name", "Unknown"),
                    "total_amount": receipt.get("total_amount", "0"),
                    "date": receipt.get("date", "Unknown"),
                    "currency": receipt.get("currency", "INR"),
                    "category_total": receipt.get("category_total", {})
                }
                receipts_summary.append(summary)
            
            # Use LLM only for summary and saving suggestions
            prompt = f"""
            You are a financial analysis expert. Based on the following spending data, provide a detailed summary and saving suggestions.

            ### Spending Data:
            - Total Receipts: {total_receipts}
            - Total Spending: ₹{total_spending:.2f}
            - Average Receipt Value: ₹{average_receipt_value:.2f}
            - Top Category: {highest_category_name} (₹{highest_category_amount:.2f})
            - Top Merchant: {top_merchant_name} (₹{top_merchant_amount:.2f})
            - Category Breakdown: {category_totals}
            - Merchant Breakdown: {merchant_totals}

            ### Receipt Details:
            {json.dumps(receipts_summary, indent=2, ensure_ascii=False)}

            ### Required Output (JSON format):
            {{
              "detailed_summary": "<comprehensive analysis of spending patterns, trends, and insights>",
              "saving_suggestion": "<practical saving tips and recommendations based on spending patterns>"
            }}

            ### Instructions:
            - Analyze spending patterns and trends
            - Identify areas where the user can save money
            - Provide specific, actionable saving suggestions
            - Consider the categories and merchants in the analysis
            - Return ONLY valid JSON without any additional text or markdown formatting

            Generate the summary and suggestions now:
            """
            
            # Get LLM response for summary and suggestions
            response = self.gemini_model.generate_content(prompt)
            llm_text = response.text.strip()
            
            # Clean the response and fix JSON issues
            if llm_text.startswith('```json'):
                llm_text = llm_text[7:]
            elif llm_text.startswith('```'):
                llm_text = llm_text[3:]
            
            if llm_text.endswith('```'):
                llm_text = llm_text[:-3]
            
            llm_text = llm_text.strip()
            
            # Fix common JSON issues
            # Remove trailing commas before closing braces/brackets
            llm_text = llm_text.replace(',}', '}').replace(',]', ']')
            
            # Remove any trailing commas in objects
            import re
            llm_text = re.sub(r',(\s*[}\]])', r'\1', llm_text)
            
            # Parse LLM response
            try:
                llm_data = json.loads(llm_text)
                detailed_summary = llm_data.get("detailed_summary", "Analysis completed successfully.")
                saving_suggestion = llm_data.get("saving_suggestion", "Consider reviewing your spending patterns.")
            except json.JSONDecodeError as json_error:
                print(f"⚠️  JSON parsing error in spending analysis: {json_error}")
                print(f"⚠️  Attempting to fix JSON structure...")
                
                # Additional fixes for common issues
                # Fix missing quotes around property names
                llm_text = re.sub(r'(\w+):', r'"\1":', llm_text)
                
                # Fix unclosed strings
                llm_text = re.sub(r'"([^"]*)$', r'"\1"', llm_text)
                
                # Remove any remaining trailing commas
                llm_text = re.sub(r',(\s*[}\]])', r'\1', llm_text)
                
                try:
                    llm_data = json.loads(llm_text)
                    detailed_summary = llm_data.get("detailed_summary", "Analysis completed successfully.")
                    saving_suggestion = llm_data.get("saving_suggestion", "Consider reviewing your spending patterns.")
                    print("✅ Spending analysis JSON fixed successfully")
                except json.JSONDecodeError:
                    print("❌ Could not fix spending analysis JSON, using default values")
                    detailed_summary = "Analysis completed successfully."
                    saving_suggestion = "Consider reviewing your spending patterns."
            
            # Create final analysis structure
            spending_analysis = {
                "analysis_id": f"ANALYSIS_{int(time.time())}_{str(uuid.uuid4())[:8].upper()}",
                "analysis_timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                "total_receipts": total_receipts,
                "total_spending": total_spending,
                "average_receipt_value": average_receipt_value,
                "currency_breakdown": currency_breakdown,
                "category_totals": category_totals,
                "category_percentages": category_percentages,
                "merchant_totals": merchant_totals,
                "top_merchant_name": top_merchant_name,
                "top_merchant_amount": top_merchant_amount,
                "monthly_totals": monthly_totals,
                "highest_spending_month": highest_spending_month,
                "highest_spending_month_amount": highest_spending_month_amount,
                "highest_category_name": highest_category_name,
                "highest_category_amount": highest_category_amount,
                "lowest_category_name": lowest_category_name,
                "lowest_category_amount": lowest_category_amount,
                "most_frequent_merchant_name": most_frequent_merchant_name,
                "most_frequent_merchant_amount": most_frequent_merchant_amount,
                "detailed_summary": detailed_summary,
                "saving_suggestion": saving_suggestion
            }
            
            # Save analysis to Firestore
            analysis_doc_id = self.save_spending_analysis_to_firestore(spending_analysis)
            if analysis_doc_id:
                spending_analysis["firestore_document_id"] = analysis_doc_id
            
            print("✅ Spending analysis generated successfully")
            return spending_analysis
            
        except Exception as e:
            print(f"❌ Error generating spending analysis: {e}")
            return self._create_fallback_analysis(all_receipts)

    def _create_fallback_analysis(self, receipts: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Create a basic analysis if Gemini processing fails."""
        analysis_id = f"ANALYSIS_{int(time.time())}_{str(uuid.uuid4())[:8].upper()}"
        
        return {
            "analysis_id": analysis_id,
            "analysis_timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "total_receipts": len(receipts),
            "total_spending": 0,
            "average_receipt_value": 0,
            "currency_breakdown": {},
            "category_totals": {},
            "category_percentages": {},
            "merchant_totals": {},
            "top_merchant_name": "",
            "top_merchant_amount": 0,
            "monthly_totals": {},
            "highest_spending_month": "",
            "highest_spending_month_amount": 0,
            "highest_category_name": "",
            "highest_category_amount": 0,
            "lowest_category_name": "",
            "lowest_category_amount": 0,
            "most_frequent_merchant_name": "",
            "most_frequent_merchant_amount": 0,
            "detailed_summary": "Analysis could not be generated due to processing error",
            "saving_suggestion": "No savings suggestion available",
            "processing_status": "fallback_analysis"
        }

    def save_spending_analysis_to_firestore(self, analysis_data: Dict[str, Any]) -> str:
        """
        Save spending analysis to Firestore in "spending_analysis" collection.
        Always overwrites the existing document to maintain only one analysis document.
        
        Args:
            analysis_data (Dict): Spending analysis data to save.
            
        Returns:
            str: Document ID of the saved analysis.
        """
        try:
            # Use a fixed document ID to always overwrite the existing analysis
            fixed_analysis_id = "current_spending_analysis"
            
            # Update the analysis_id in the data to match the fixed ID
            analysis_data["analysis_id"] = fixed_analysis_id
            
            # Clear any existing analysis documents (optional cleanup)
            self._clear_existing_analysis_documents()
            
            # Save to Firestore in "spending_analysis" collection, overwriting existing document
            doc_ref = self.firestore_client.collection("spending_analysis").document(fixed_analysis_id)
            doc_ref.set(analysis_data)
            print(f"✅ Spending analysis saved to Firestore with ID: {fixed_analysis_id} (overwritten)")
            return fixed_analysis_id
        except Exception as e:
            print(f"❌ Error saving spending analysis to Firestore: {e}")
            return ""

    def _clear_existing_analysis_documents(self):
        """
        Clear any existing analysis documents to ensure only one document exists.
        This is optional cleanup to remove any old analysis documents.
        """
        try:
            docs = self.firestore_client.collection("spending_analysis").stream()
            deleted_count = 0
            
            for doc in docs:
                # Skip the current analysis document we're about to create/update
                if doc.id != "current_spending_analysis":
                    doc.reference.delete()
                    deleted_count += 1
            
            if deleted_count > 0:
                print(f"🗑️  Cleared {deleted_count} old analysis documents")
        except Exception as e:
            print(f"⚠️  Warning: Could not clear old analysis documents: {e}")


def main():
    """Main function for text extraction and processing with Google Wallet and Spending Analysis."""
    print("🔍 Universal Text Extractor & Processor with Google Wallet & Spending Analysis")
    print("📸 Supports: Images | 🎬 Videos | 🎫 Google Wallet Passes | 📊 Spending Analysis")
    print("=" * 60)
    
    # Configuration
    credentials_path = "project-rasheed-466518-5cdff45af981.json"
    project_id = "project-rasheed-466518"
    issuer_id = "3388000000022971962"  # Your Google Wallet Merchant/Issuer ID
    
    # Example inputs (you can modify these)
    inputs = [
        "images/AllReceipt.png",  # Image
        # "path/to/your/video.mp4",  # Video (uncomment and add path)
    ]
    
    # Verify credentials exist
    if not os.path.exists(credentials_path):
        print(f"❌ Credentials file not found: {credentials_path}")
        return
    
   
    # Initialize processor
    processor = TextExtractorProcessor(credentials_path, project_id)
    
    # Process all inputs with complete pipeline
    all_results = []
    
    for i, input_path in enumerate(inputs):
        print(f"\n{'='*20} INPUT {i+1} {'='*20}")
        
        # Skip if file doesn't exist
        if not os.path.exists(input_path):
            print(f"⚠️  Skipping {input_path} - file not found")
            continue
        
        # Process input with complete pipeline: Receipt + Wallet + Analysis
        print("🔄 Processing with complete pipeline (Receipt + Wallet + Analysis)...")
        results = process_receipt_with_wallet_and_analysis(input_path, issuer_id, credentials_path)
        all_results.append(results)
        
        # Display receipt results
        receipt_data = results.get("receipt_processing", {})
        print(f"\n📋 STRUCTURED RECEIPT RESULTS for {processor.detect_input_type(input_path).upper()}:")
        print("=" * 50)
        print(json.dumps(receipt_data, indent=2, ensure_ascii=False))
        
        # Display Google Wallet link if created
        if receipt_data.get("google_wallet_link"):
            print(f"\n🎫 GOOGLE WALLET LINK:")
            print("=" * 50)
            print(f"Add to Google Wallet: {receipt_data['google_wallet_link']}")
            print("📱 Click this link on Android device or open in browser to add to Google Wallet")
        
        # Display spending analysis results
        analysis_data = results.get("spending_analysis", {})
        print(f"\n📊 SPENDING ANALYSIS RESULTS:")
        print("=" * 50)
        print(json.dumps(analysis_data, indent=2, ensure_ascii=False))
    
    #     # Generate overall spending analysis (optional - can be called separately)
    #     print(f"\n{'='*20} OVERALL SPENDING ANALYSIS {'='*20}")
    #     overall_analysis = processor.generate_spending_analysis()
    #     print("📊 OVERALL SPENDING ANALYSIS:")
    #     print("=" * 50)
    #     print(json.dumps(overall_analysis, indent=2, ensure_ascii=False))
        
    #     # Save all results
    #     if all_results:
    #         processor.save_results({
    #             "total_processed": len(all_results),
    #             "processing_session": time.strftime("%Y-%m-%d %H:%M:%S"),
    #             "results": all_results,
    #             "overall_analysis": overall_analysis
    #         }, "complete_pipeline_results.json")
        
    # except Exception as e:
    #     print(f"❌ Application error: {e}")


def process_single_input(input_path: str):
    """
    Convenience function to process a single input.
    Perfect for API endpoints.
    
    Args:
        input_path (str): Path to image or video file
        
    Returns:
        Dict: Structured results
    """
    credentials_path = "project-rasheed-466518-5cdff45af981.json"
    project_id = "project-rasheed-466518"
    
    processor = TextExtractorProcessor(credentials_path, project_id)
    return processor.process_input(input_path)


def process_receipt_to_wallet(input_path: str, issuer_id: str = "3388000000022971962", credentials_path: str = "project-rasheed-466518-5cdff45af981.json"):
    """
    Convenience function to process a receipt and create Google Wallet pass with Firestore saving.
    Perfect for API endpoints and frontend integration.
    
    Args:
        input_path (str): Path to receipt image or video file
        issuer_id (str): Google Wallet issuer ID
        credentials_path (str): Path to Google Cloud credentials file
        
    Returns:
        Dict: Structured results with Google Wallet link and Firestore document ID
    """
    project_id = "project-rasheed-466518"
    
    processor = TextExtractorProcessor(credentials_path, project_id)
    return processor.process_input_with_wallet(input_path, issuer_id)


def process_receipt_to_database(input_path: str, credentials_path: str = "project-rasheed-466518-5cdff45af981.json"):
    """
    Convenience function to process a receipt and save to Firestore database only.
    Perfect for API endpoints when wallet functionality is not needed.
    
    Args:
        input_path (str): Path to receipt image or video file
        credentials_path (str): Path to Google Cloud credentials file
        
    Returns:
        Dict: Structured results with Firestore document ID
    """
    project_id = "project-rasheed-466518"
    
    processor = TextExtractorProcessor(credentials_path, project_id)
    return processor.process_input(input_path, save_to_firestore=True)


def generate_spending_analysis_only(credentials_path: str = "project-rasheed-466518-5cdff45af981.json"):
    """
    Convenience function to generate spending analysis from existing Firestore data only.
    Perfect for generating analysis without processing new receipts.
    
    Args:
        credentials_path (str): Path to Google Cloud credentials file
        
    Returns:
        Dict: Spending analysis results
    """
    project_id = "project-rasheed-466518"
    
    processor = TextExtractorProcessor(credentials_path, project_id)
    return processor.generate_spending_analysis()


def process_receipt_with_analysis(input_path: str, credentials_path: str = "project-rasheed-466518-5cdff45af981.json"):
    """
    Convenience function to process a receipt and generate spending analysis.
    Combines receipt processing with spending analysis in one call.
    
    Args:
        input_path (str): Path to receipt image or video file
        credentials_path (str): Path to Google Cloud credentials file
        
    Returns:
        Dict: Combined results with receipt data and spending analysis
    """
    project_id = "project-rasheed-466518"
    
    processor = TextExtractorProcessor(credentials_path, project_id)
    
    # Process the receipt
    receipt_result = processor.process_input(input_path, save_to_firestore=True)
    
    # Generate spending analysis including the new receipt
    analysis_result = processor.generate_spending_analysis(receipt_result)
    
    # Combine results
    combined_result = {
        "receipt_processing": receipt_result,
        "spending_analysis": analysis_result,
        "processing_timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
    }
    
    return combined_result


def process_receipt_with_wallet_and_analysis(input_path: str, issuer_id: str = "3388000000022971962", credentials_path: str = "project-rasheed-466518-5cdff45af981.json"):
    """
    Convenience function to process a receipt, create Google Wallet pass, and generate spending analysis.
    Complete pipeline: Extract -> Translate -> Structure -> Wallet Pass -> Firestore -> Analysis.
    
    Args:
        input_path (str): Path to receipt image or video file
        issuer_id (str): Google Wallet issuer ID
        credentials_path (str): Path to Google Cloud credentials file
        
    Returns:
        Dict: Complete results with receipt data, wallet link, and spending analysis
    """
    project_id = "project-rasheed-466518"
    
    processor = TextExtractorProcessor(credentials_path, project_id)
    
    # Process the receipt with wallet
    wallet_result = processor.process_input_with_wallet(input_path, issuer_id)
    
    # Generate spending analysis including the new receipt
    analysis_result = processor.generate_spending_analysis(wallet_result)
    
    # Combine results
    combined_result = {
        "receipt_processing": wallet_result,
        "spending_analysis": analysis_result,
        "processing_timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
    }
    
    return combined_result


if __name__ == "__main__":
    # Uncomment the line below to test wallet integration only
    # test_wallet_integration()
    
    # Run the full pipeline
    main()
