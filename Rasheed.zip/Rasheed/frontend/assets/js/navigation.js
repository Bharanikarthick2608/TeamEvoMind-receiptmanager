// Navigation Management
class NavigationManager {
    constructor() {
        this.currentRoute = 'receipt-upload';
        this.history = ['receipt-upload'];
        this.breadcrumbs = [];
        
        this.init();
    }

    init() {
        this.setupRouting();
        this.setupSearch();
        this.setupKeyboardShortcuts();
    }

    setupRouting() {
        // Handle browser back/forward buttons
        window.addEventListener('popstate', (e) => {
            if (e.state && e.state.module) {
                this.navigateToModule(e.state.module, false);
            }
        });

        // Set initial state
        const initialState = { module: this.currentRoute };
        history.replaceState(initialState, '', `#${this.currentRoute}`);
    }

    setupSearch() {
        const searchInput = document.querySelector('.search-input');
        if (!searchInput) return;

        // Debounced search functionality
        const debouncedSearch = this.debounce((query) => {
            this.performSearch(query);
        }, 300);

        searchInput.addEventListener('input', (e) => {
            const query = e.target.value.trim();
            if (query.length > 0) {
                debouncedSearch(query);
            } else {
                this.clearSearchResults();
            }
        });

        // Handle Enter key
        searchInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                this.handleSearchEnter(e.target.value.trim());
            }
        });
    }

    setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            // Only trigger if not typing in an input
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
                return;
            }

            // Module shortcuts (Alt + number)
            if (e.altKey && e.key >= '1' && e.key <= '9') {
                e.preventDefault();
                const moduleIndex = parseInt(e.key) - 1;
                const modules = [
                    'dashboard',
                    'receipt-upload',
                    'wallet-passes',
                    'chat-assistant',
                    'spending-trends',
                    'budgeting',
                    'offers',
                    'family-wallet',
                    'expense-reports'
                ];
                
                if (moduleIndex < modules.length) {
                    this.navigateToModule(modules[moduleIndex]);
                }
            }

            // Search shortcut (Ctrl/Cmd + K)
            if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                e.preventDefault();
                this.focusSearch();
            }

            // Go back (Alt + Left)
            if (e.altKey && e.key === 'ArrowLeft') {
                e.preventDefault();
                this.goBack();
            }
        });
    }

    navigateToModule(moduleId, addToHistory = true) {
        // Update URL and history
        if (addToHistory) {
            const state = { module: moduleId };
            history.pushState(state, '', `#${moduleId}`);
            
            // Add to navigation history
            if (this.currentRoute !== moduleId) {
                this.history.push(moduleId);
                // Keep history size reasonable
                if (this.history.length > 10) {
                    this.history.shift();
                }
            }
        }

        // Update current route
        this.currentRoute = moduleId;

        // Use app's showModule method
        if (window.app) {
            window.app.showModule(moduleId);
        }

        // Update breadcrumbs
        this.updateBreadcrumbs(moduleId);

        // Close search results if open
        this.clearSearchResults();
    }

    updateBreadcrumbs(moduleId) {
        const moduleNames = {
            'dashboard': 'Dashboard',
            'receipt-upload': 'Receipt Upload',
            'wallet-passes': 'Wallet Passes',
            'chat-assistant': 'Chat Assistant',
            'spending-trends': 'Spending Trends',
            'budgeting': 'Budgeting',
            'offers': 'Offers & Savings',
            'family-wallet': 'Family Wallet',
            'expense-reports': 'Expense Reports',
            'settings': 'Settings'
        };

        this.breadcrumbs = [
            { name: 'Home', id: 'dashboard' },
            { name: moduleNames[moduleId] || moduleId, id: moduleId }
        ];

        // Update breadcrumb UI if it exists
        this.renderBreadcrumbs();
    }

    renderBreadcrumbs() {
        const breadcrumbContainer = document.querySelector('.breadcrumbs');
        if (!breadcrumbContainer) return;

        const breadcrumbHTML = this.breadcrumbs.map((crumb, index) => {
            const isLast = index === this.breadcrumbs.length - 1;
            return `
                <span class="breadcrumb-item ${isLast ? 'active' : ''}" 
                      ${!isLast ? `onclick="navigation.navigateToModule('${crumb.id}')"` : ''}>
                    ${crumb.name}
                </span>
                ${!isLast ? '<span class="breadcrumb-separator">></span>' : ''}
            `;
        }).join('');

        breadcrumbContainer.innerHTML = breadcrumbHTML;
    }

    performSearch(query) {
        // Mock search results - in a real app, this would query your backend
        const searchResults = this.getSearchResults(query);
        this.displaySearchResults(searchResults);
    }

    getSearchResults(query) {
        const mockData = [
            { type: 'receipt', title: 'Grocery Receipt - ₹45.67', subtitle: 'Target Store, Yesterday', id: 'receipt-1' },
            { type: 'receipt', title: 'Restaurant Bill - ₹28.50', subtitle: 'Pizza Palace, 2 days ago', id: 'receipt-2' },
            { type: 'module', title: 'Spending Trends', subtitle: 'View your spending analytics', id: 'spending-trends' },
            { type: 'module', title: 'Budgeting', subtitle: 'Manage your budget goals', id: 'budgeting' },
            { type: 'item', title: 'Organic Bananas', subtitle: 'Found in 3 receipts', id: 'item-1' },
        ];

        return mockData.filter(item => 
            item.title.toLowerCase().includes(query.toLowerCase()) ||
            item.subtitle.toLowerCase().includes(query.toLowerCase())
        );
    }

    displaySearchResults(results) {
        // Create search results dropdown if it doesn't exist
        let resultsContainer = document.querySelector('.search-results');
        if (!resultsContainer) {
            resultsContainer = document.createElement('div');
            resultsContainer.className = 'search-results';
            document.querySelector('.search-container').appendChild(resultsContainer);
        }

        if (results.length === 0) {
            resultsContainer.innerHTML = `
                <div class="search-result-item no-results">
                    <span class="material-icons">search_off</span>
                    <span>No results found</span>
                </div>
            `;
        } else {
            resultsContainer.innerHTML = results.map(result => `
                <div class="search-result-item" onclick="navigation.handleSearchResultClick('${result.type}', '${result.id}')">
                    <span class="material-icons">${this.getSearchResultIcon(result.type)}</span>
                    <div class="search-result-content">
                        <div class="search-result-title">${result.title}</div>
                        <div class="search-result-subtitle">${result.subtitle}</div>
                    </div>
                </div>
            `).join('');
        }

        resultsContainer.style.display = 'block';

        // Add search results styles if not already added
        if (!document.querySelector('#search-styles')) {
            this.addSearchStyles();
        }
    }

    addSearchStyles() {
        const styles = document.createElement('style');
        styles.id = 'search-styles';
        styles.textContent = `
            .search-results {
                position: absolute;
                top: 100%;
                left: 0;
                right: 0;
                background: white;
                border-radius: var(--border-radius-md);
                box-shadow: var(--shadow-3);
                max-height: 300px;
                overflow-y: auto;
                z-index: var(--z-dropdown);
                display: none;
                margin-top: var(--spacing-sm);
            }
            
            .search-result-item {
                display: flex;
                align-items: center;
                gap: var(--spacing-md);
                padding: var(--spacing-md);
                cursor: pointer;
                transition: var(--transition);
                border-bottom: 1px solid var(--google-border);
            }
            
            .search-result-item:last-child {
                border-bottom: none;
            }
            
            .search-result-item:hover {
                background: var(--google-light-grey);
            }
            
            .search-result-item.no-results {
                color: var(--google-grey);
                cursor: default;
                justify-content: center;
            }
            
            .search-result-item.no-results:hover {
                background: transparent;
            }
            
            .search-result-content {
                flex: 1;
            }
            
            .search-result-title {
                font-weight: 500;
                color: var(--google-dark-grey);
                margin-bottom: 2px;
            }
            
            .search-result-subtitle {
                font-size: var(--font-size-sm);
                color: var(--google-grey);
            }
            
            .breadcrumbs {
                display: flex;
                align-items: center;
                gap: var(--spacing-sm);
                margin-bottom: var(--spacing-md);
                font-size: var(--font-size-sm);
            }
            
            .breadcrumb-item {
                color: var(--google-grey);
                cursor: pointer;
                transition: var(--transition);
            }
            
            .breadcrumb-item:hover:not(.active) {
                color: var(--google-blue);
            }
            
            .breadcrumb-item.active {
                color: var(--google-dark-grey);
                font-weight: 500;
                cursor: default;
            }
            
            .breadcrumb-separator {
                color: var(--google-border);
            }
        `;
        document.head.appendChild(styles);
    }

    getSearchResultIcon(type) {
        const icons = {
            'receipt': 'receipt_long',
            'module': 'apps',
            'item': 'inventory_2',
            'wallet': 'account_balance_wallet'
        };
        return icons[type] || 'search';
    }

    handleSearchResultClick(type, id) {
        switch(type) {
            case 'module':
                this.navigateToModule(id);
                break;
            case 'receipt':
                this.navigateToModule('receipt-upload');
                // Additional logic to load specific receipt
                console.log(`Loading receipt: ${id}`);
                break;
            case 'item':
                this.navigateToModule('spending-trends');
                // Additional logic to filter by item
                console.log(`Filtering by item: ${id}`);
                break;
        }
        
        this.clearSearchResults();
        this.clearSearchInput();
    }

    handleSearchEnter(query) {
        if (!query) return;
        
        // Navigate to search results page or perform global search
        console.log(`Performing global search for: ${query}`);
        window.app?.showNotification(`Searching for "${query}"...`, 'info');
        
        this.clearSearchResults();
    }

    clearSearchResults() {
        const resultsContainer = document.querySelector('.search-results');
        if (resultsContainer) {
            resultsContainer.style.display = 'none';
        }
    }

    clearSearchInput() {
        const searchInput = document.querySelector('.search-input');
        if (searchInput) {
            searchInput.value = '';
        }
    }

    focusSearch() {
        const searchInput = document.querySelector('.search-input');
        if (searchInput) {
            searchInput.focus();
            searchInput.select();
        }
    }

    goBack() {
        if (this.history.length > 1) {
            // Remove current page from history
            this.history.pop();
            // Navigate to previous page
            const previousModule = this.history[this.history.length - 1];
            this.navigateToModule(previousModule, false);
            
            // Update browser history
            const state = { module: previousModule };
            history.pushState(state, '', `#${previousModule}`);
        }
    }

    // Utility method
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
}

// Global navigation instance
let navigation;

// Initialize navigation when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    navigation = new NavigationManager();
    window.navigation = navigation;
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = NavigationManager;
} 