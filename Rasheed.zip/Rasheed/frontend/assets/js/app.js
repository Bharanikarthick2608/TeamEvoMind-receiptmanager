// Currency mapping utility
function getCurrencySymbol(currencyCode) {
    const currencySymbols = {
        'INR': '₹',
        'USD': '$',
        'EUR': '€',
        'GBP': '£',
        'JPY': '¥',
        'CNY': '¥',
        'AED': 'د.إ',
        'SAR': '﷼',
        'CAD': 'C$',
        'AUD': 'A$',
        'CHF': 'CHF',
        'SGD': 'S$',
        'HKD': 'HK$',
        'KRW': '₩',
        'THB': '฿',
        'MYR': 'RM',
        'PHP': '₱',
        'IDR': 'Rp',
        'VND': '₫',
        'BRL': 'R$',
        'MXN': 'MX$',
        'RUB': '₽',
        'TRY': '₺',
        'ZAR': 'R',
        'PLN': 'zł',
        'CZK': 'Kč',
        'HUF': 'Ft',
        'NOK': 'kr',
        'SEK': 'kr',
        'DKK': 'kr',
        'ILS': '₪',
        'EGP': 'E£',
        'LKR': 'Rs',
        'PKR': 'Rs',
        'BDT': '৳',
        'NPR': 'Rs',
        'MMK': 'K',
        'LAK': '₭',
        'KHR': '៛',
        'TWD': 'NT$',
        'QAR': '﷼',
        'KWD': 'د.ك',
        'BHD': 'د.ب',
        'OMR': '﷼',
        'JOD': 'د.ا',
        'LBP': 'ل.ل',
        'SYP': '£',
        'IQD': 'د.ع',
        'IRR': '﷼',
        'AFN': '؋'
    };
    
    return currencySymbols[currencyCode] || currencyCode || '$';
}

// Main App Controller
class AppController {
    constructor() {
        this.currentModule = 'receipt-upload';
        this.sidebarCollapsed = false;
        this.isMobile = window.innerWidth <= 768;
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.checkMobileView();
        this.initializeModules();
    }

    setupEventListeners() {
        // Window resize handler
        window.addEventListener('resize', () => {
            this.checkMobileView();
        });

        // Global keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            // Ctrl/Cmd + B to toggle sidebar
            if ((e.ctrlKey || e.metaKey) && e.key === 'b') {
                e.preventDefault();
                this.toggleSidebar();
            }
            
            // Escape to close modals
            if (e.key === 'Escape') {
                this.closeAllModals();
            }
        });

        // Global click handler for outside clicks
        document.addEventListener('click', (e) => {
            // Close sidebar on mobile when clicking outside
            if (this.isMobile && !e.target.closest('.sidebar') && !e.target.closest('.sidebar-toggle')) {
                const sidebar = document.getElementById('sidebar');
                if (sidebar.classList.contains('show')) {
                    sidebar.classList.remove('show');
                }
            }
        });
    }

    checkMobileView() {
        const wasMobile = this.isMobile;
        this.isMobile = window.innerWidth <= 768;
        
        // Reset sidebar state when switching between mobile/desktop
        if (wasMobile !== this.isMobile) {
            const sidebar = document.getElementById('sidebar');
            if (this.isMobile) {
                sidebar.classList.remove('collapsed');
                sidebar.classList.remove('show');
            } else {
                sidebar.classList.remove('show');
            }
        }
    }

    initializeModules() {
        // Initialize any global module functionality
        console.log('🚀 App initialized successfully');
    }

    toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const toggleIcon = document.getElementById('toggle-icon');
        
        if (this.isMobile) {
            // On mobile, show/hide sidebar
            sidebar.classList.toggle('show');
        } else {
            // On desktop, collapse/expand sidebar
            sidebar.classList.toggle('collapsed');
            this.sidebarCollapsed = !this.sidebarCollapsed;
            
            // Update toggle icon
            toggleIcon.textContent = this.sidebarCollapsed ? 'chevron_right' : 'chevron_left';
        }
    }

    showModule(moduleId) {
        // Hide all modules
        document.querySelectorAll('.module-container').forEach(module => {
            module.classList.remove('active');
        });

        // Remove active state from all nav items
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });

        // Show selected module
        const moduleElement = document.getElementById(`${moduleId}-module`);
        if (moduleElement) {
            moduleElement.classList.add('active');
            this.currentModule = moduleId;
            
            // Update header
            this.updateHeader(moduleId);
            
            // Add active state to clicked nav item
            event.target.closest('.nav-item').classList.add('active');
            
            // Close sidebar on mobile after selection
            if (this.isMobile) {
                document.getElementById('sidebar').classList.remove('show');
            }
            
            // Trigger module-specific initialization
            this.initializeModule(moduleId);
        }
    }

    updateHeader(moduleId) {
        const titles = {
            'dashboard': {
                title: 'Dashboard',
                subtitle: 'Overview of your receipt data and insights'
            },
            'receipt-upload': {
                title: 'Receipt Upload',
                subtitle: 'Upload your receipt in any form – we handle the rest.'
            },
            'wallet-passes': {
                title: 'Wallet Passes',
                subtitle: 'Manage your Google Wallet passes'
            },
            'chat-assistant': {
                title: 'Chat Assistant',
                subtitle: 'Get help with your receipt management'
            },
            'spending-trends': {
                title: 'Spending Trends',
                subtitle: 'Analyze your spending patterns and trends'
            },
            'budgeting': {
                title: 'Budgeting',
                subtitle: 'Set and track your budget goals'
            },
            'offers': {
                title: 'Offers & Savings',
                subtitle: 'Discover deals and savings opportunities'
            },
            'family-wallet': {
                title: 'Family Wallet',
                subtitle: 'Manage family expenses and shared budgets'
            },
            'expense-reports': {
                title: 'Expense Reports',
                subtitle: 'Generate detailed expense reports'
            },
            'settings': {
                title: 'Settings',
                subtitle: 'Configure your account and preferences'
            }
        };

        const moduleInfo = titles[moduleId] || { title: 'Unknown', subtitle: '' };
        
        document.getElementById('module-title').textContent = moduleInfo.title;
        document.getElementById('module-subtitle').textContent = moduleInfo.subtitle;
    }

    initializeModule(moduleId) {
        // Call module-specific initialization functions
        switch(moduleId) {
            case 'receipt-upload':
                if (typeof initializeReceiptUpload === 'function') {
                    initializeReceiptUpload();
                }
                break;
            case 'dashboard':
                if (typeof initializeDashboard === 'function') {
                    initializeDashboard();
                }
                break;
            // Add other module initializations as needed
        }
    }

    closeAllModals() {
        document.querySelectorAll('.modal-backdrop').forEach(modal => {
            modal.classList.remove('show');
        });
    }

    showNotification(message, type = 'success') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <span class="material-icons">${type === 'success' ? 'check_circle' : type === 'error' ? 'error' : 'info'}</span>
                <span>${message}</span>
            </div>
            <button class="notification-close" onclick="this.parentElement.remove()">
                <span class="material-icons">close</span>
            </button>
        `;

        // Add styles if not already added
        if (!document.querySelector('#notification-styles')) {
            const styles = document.createElement('style');
            styles.id = 'notification-styles';
            styles.textContent = `
                .notification {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    background: white;
                    border-radius: var(--border-radius-md);
                    box-shadow: var(--shadow-3);
                    padding: var(--spacing-md);
                    display: flex;
                    align-items: center;
                    gap: var(--spacing-sm);
                    z-index: var(--z-tooltip);
                    min-width: 300px;
                    animation: slideInRight 0.3s ease;
                }
                
                .notification-success {
                    border-left: 4px solid var(--google-green);
                }
                
                .notification-error {
                    border-left: 4px solid var(--google-red);
                }
                
                .notification-info {
                    border-left: 4px solid var(--google-blue);
                }
                
                .notification-content {
                    display: flex;
                    align-items: center;
                    gap: var(--spacing-sm);
                    flex: 1;
                }
                
                .notification-close {
                    background: none;
                    border: none;
                    cursor: pointer;
                    padding: 0;
                    color: var(--google-grey);
                }
                
                .notification-close:hover {
                    color: var(--google-dark-grey);
                }
            `;
            document.head.appendChild(styles);
        }

        // Add to page
        document.body.appendChild(notification);

        // Auto remove after 5 seconds
        setTimeout(() => {
            if (notification.parentElement) {
                notification.style.animation = 'slideOutRight 0.3s ease';
                setTimeout(() => notification.remove(), 300);
            }
        }, 5000);
    }

    // Utility methods
    formatCurrency(amount, currency = 'USD') {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: currency
        }).format(amount);
    }

    formatDate(date, options = {}) {
        const defaultOptions = {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        };
        return new Intl.DateTimeFormat('en-US', { ...defaultOptions, ...options }).format(new Date(date));
    }

    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
}

// Global functions for HTML onclick handlers
function toggleSidebar() {
    window.app.toggleSidebar();
}

function showModule(moduleId) {
    window.app.showModule(moduleId);
}

function closeModal() {
    window.app.closeAllModals();
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new AppController();
});

// Export for use in modules
window.AppController = AppController; 