// Receipt Upload Module
class ReceiptUploadManager {
    constructor() {
        this.currentFile = null;
        this.processing = false;
        this.results = null;
        this.selectedMethod = 'image';
        
        // Backend API configuration
        this.apiBaseUrl = 'http://localhost:8000/api'; // Updated to match backend API structure
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setupDropZone();
    }

    setupEventListeners() {
        // File input change
        const fileInput = document.getElementById('file-input');
        if (fileInput) {
            fileInput.addEventListener('change', (e) => this.handleFileSelect(e));
        }

        // Drag and drop events
        const dropZone = document.querySelector('.drop-zone');
        if (dropZone) {
            dropZone.addEventListener('dragover', (e) => this.handleDragOver(e));
            dropZone.addEventListener('dragleave', (e) => this.handleDragLeave(e));
            dropZone.addEventListener('drop', (e) => this.handleDrop(e));
        }
    }

    setupDropZone() {
        const dropZone = document.querySelector('.drop-zone');
        if (!dropZone) return;

        // Prevent default drag behaviors
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            dropZone.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
            });
        });
    }

    selectMethod(method) {
        // Remove active from all tabs
        document.querySelectorAll('.method-tab').forEach(tab => {
            tab.classList.remove('active');
        });

        // Add active to selected tab
        event.target.closest('.method-tab').classList.add('active');
        
        this.selectedMethod = method;
        console.log(`Selected method: ${method}`);

        // Update UI based on selected method
        this.updateUIForMethod(method);
    }

    updateUIForMethod(method) {
        const dropZone = document.querySelector('.drop-zone');
        const fileInput = document.getElementById('file-input');

        switch(method) {
            case 'image':
                fileInput.accept = 'image/*';
                dropZone.querySelector('h3').textContent = 'Drag & drop your receipt image here';
                dropZone.querySelector('.supported-formats').textContent = 'Supports: JPEG, PNG (Max 10MB)';
                break;
            case 'video':
                fileInput.accept = 'video/*';
                dropZone.querySelector('h3').textContent = 'Drag & drop your receipt video here';
                dropZone.querySelector('.supported-formats').textContent = 'Supports: MP4, AVI, MOV (Max 50MB)';
                break;
            case 'camera':
                this.openCamera();
                break;
            case 'manual':
                this.openManualEntry();
                break;
        }
    }

    handleDragOver(e) {
        e.preventDefault();
        const dropZone = e.currentTarget;
        dropZone.classList.add('drag-over');
    }

    handleDragLeave(e) {
        e.preventDefault();
        const dropZone = e.currentTarget;
        if (!dropZone.contains(e.relatedTarget)) {
            dropZone.classList.remove('drag-over');
        }
    }

    handleDrop(e) {
        e.preventDefault();
        const dropZone = e.currentTarget;
        dropZone.classList.remove('drag-over');
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            this.processFile(files[0]);
        }
    }

    handleFileSelect(e) {
        const file = e.target.files[0];
        if (file) {
            this.processFile(file);
        }
    }

    processFile(file) {
        // Prevent duplicate processing
        if (this.processing) {
            console.log('⚠️ Already processing a file, ignoring duplicate request');
            return;
        }

        // Validate file
        if (!this.validateFile(file)) {
            return;
        }

        this.currentFile = file;
        
        // Show file preview
        this.showFilePreview(file);
        
        // Start processing
        this.uploadAndProcess(file);
    }

    validateFile(file) {
        const maxSize = this.selectedMethod === 'video' ? 50 * 1024 * 1024 : 10 * 1024 * 1024; // 50MB for video, 10MB for images
        
        if (file.size > maxSize) {
            window.app.showNotification(`File size too large. Maximum ${this.selectedMethod === 'video' ? '50MB' : '10MB'} allowed.`, 'error');
            return false;
        }

        const validTypes = {
            'image': ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
            'video': ['video/mp4', 'video/avi', 'video/mov', 'video/wmv']
        };

        const allowedTypes = validTypes[this.selectedMethod] || validTypes['image'];
        
        if (!allowedTypes.includes(file.type)) {
            window.app.showNotification(`Invalid file type. Please select a valid ${this.selectedMethod} file.`, 'error');
            return false;
        }

        return true;
    }

    showFilePreview(file) {
        const resultsContent = document.getElementById('results-content');
        
        // Create preview HTML
        const preview = document.createElement('div');
        preview.className = 'file-preview';
        preview.innerHTML = `
            <div class="preview-header">
                <h4>📄 ${file.name}</h4>
                <span class="file-size">${this.formatFileSize(file.size)}</span>
            </div>
            <div class="preview-body">
                <div class="processing-status">
                    <div class="loading-spinner"></div>
                    <span>Processing your receipt...</span>
                </div>
            </div>
        `;

        // Add preview styles
        if (!document.querySelector('#preview-styles')) {
            const styles = document.createElement('style');
            styles.id = 'preview-styles';
            styles.textContent = `
                .file-preview {
                    text-align: left;
                    background: var(--google-light-grey);
                    border-radius: var(--border-radius-md);
                    padding: var(--spacing-lg);
                    margin-bottom: var(--spacing-md);
                }
                
                .preview-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: var(--spacing-md);
                    padding-bottom: var(--spacing-sm);
                    border-bottom: 1px solid var(--google-border);
                }
                
                .preview-header h4 {
                    margin: 0;
                    color: var(--google-dark-grey);
                }
                
                .file-size {
                    font-size: var(--font-size-sm);
                    color: var(--google-grey);
                }
                
                .processing-status {
                    display: flex;
                    align-items: center;
                    gap: var(--spacing-md);
                    padding: var(--spacing-md);
                    background: white;
                    border-radius: var(--border-radius-md);
                    color: var(--google-blue);
                }
                
                .results-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                    gap: var(--spacing-md);
                    margin-top: var(--spacing-md);
                }
                
                .result-card {
                    background: white;
                    padding: var(--spacing-md);
                    border-radius: var(--border-radius-md);
                    border: 1px solid var(--google-border);
                }
                
                .result-card h5 {
                    color: var(--google-blue);
                    margin-bottom: var(--spacing-sm);
                }
                
                .result-value {
                    font-weight: 600;
                    color: var(--google-dark-grey);
                }
                
                .receipt-actions {
                    display: flex;
                    gap: var(--spacing-sm);
                    margin-top: var(--spacing-md);
                }
                
                .wallet-link {
                    display: inline-flex;
                    align-items: center;
                    gap: var(--spacing-sm);
                    padding: var(--spacing-sm) var(--spacing-md);
                    background: var(--gradient-primary);
                    color: white;
                    text-decoration: none;
                    border-radius: var(--border-radius-md);
                    font-weight: 500;
                    transition: var(--transition);
                }
                
                .wallet-link:hover {
                    transform: translateY(-2px);
                    box-shadow: var(--shadow-2);
                }
            `;
            document.head.appendChild(styles);
        }

        resultsContent.innerHTML = '';
        resultsContent.appendChild(preview);
    }

    async uploadAndProcess(file) {
        console.log('🚀 Starting receipt upload and processing for:', file.name);
        this.processing = true;

        try {
            // Get processing options
            const saveToDb = document.getElementById('save-to-db').checked;
            const generateWallet = document.getElementById('generate-wallet').checked;

            // Create FormData
            const formData = new FormData();
            formData.append('file', file);

            // Determine endpoint based on options
            let endpoint = '/receipt/process';
            if (!generateWallet && saveToDb) {
                endpoint = '/receipt/process-simple';
            } else if (!generateWallet && !saveToDb) {
                endpoint = '/receipt/process-no-save';
            }

            // Make API request
            const response = await fetch(`${this.apiBaseUrl}${endpoint}`, {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();
            this.results = result;

            // Show results
            this.displayResults(result);
            
            console.log('✅ Receipt processing completed successfully for:', file.name);
            window.app.showNotification('Receipt processed successfully!', 'success');

        } catch (error) {
            console.error('❌ Error processing receipt:', error);
            this.showError('Failed to process receipt. Please try again.');
            window.app.showNotification('Failed to process receipt. Please check your connection.', 'error');
        } finally {
            console.log('🏁 Receipt processing finished for:', file.name);
            this.processing = false;
        }
    }

    displayResults(data) {
        const resultsContent = document.getElementById('results-content');
        
        // Create results HTML
        const resultsHTML = `
            <div class="file-preview">
                <div class="preview-header">
                    <h4>✅ ${this.currentFile.name}</h4>
                    <span class="file-size">${this.formatFileSize(this.currentFile.size)}</span>
                </div>
                <div class="preview-body">
                    ${this.generateResultsHTML(data)}
                    <div class="receipt-actions">
                        <button class="btn btn-primary" onclick="receiptUpload.showFullPreview()">
                            <span class="material-icons">visibility</span>
                            View Details
                        </button>
                        ${data.google_wallet_link ? `
                            <a href="${data.google_wallet_link}" target="_blank" class="wallet-link">
                                <span class="material-icons">account_balance_wallet</span>
                                Add to Google Wallet
                            </a>
                        ` : ''}
                        ${data.firestore_document_id ? `
                            <button class="btn btn-success" onclick="receiptUpload.downloadReceipt()">
                                <span class="material-icons">download</span>
                                Download
                            </button>
                        ` : ''}
                    </div>
                </div>
            </div>
        `;

        resultsContent.innerHTML = resultsHTML;
    }

    generateResultsHTML(data) {
        if (data.error) {
            return `
                <div class="processing-status" style="color: var(--google-red);">
                    <span class="material-icons">error</span>
                    <span>Error: ${data.error}</span>
                </div>
            `;
        }

        // Extract key information
        const merchantName = data.merchant_name || 'Unknown Merchant';
        const totalAmount = data.total_amount || '0.00';
        const date = data.date || 'Unknown Date';
        const itemCount = data.details ? Object.values(data.details).reduce((count, category) => count + Object.keys(category).length, 0) : 0;

        return `
            <div class="results-grid">
                <div class="result-card">
                    <h5>Merchant</h5>
                    <div class="result-value">${merchantName}</div>
                </div>
                <div class="result-card">
                    <h5>Total Amount</h5>
                    <div class="result-value">${getCurrencySymbol(data.currency)}${totalAmount}</div>
                </div>
                <div class="result-card">
                    <h5>Date</h5>
                    <div class="result-value">${date}</div>
                </div>
                <div class="result-card">
                    <h5>Items</h5>
                    <div class="result-value">${itemCount} items</div>
                </div>
            </div>
        `;
    }

    showError(message) {
        const resultsContent = document.getElementById('results-content');
        resultsContent.innerHTML = `
            <div class="processing-status" style="color: var(--google-red);">
                <span class="material-icons">error</span>
                <span>${message}</span>
            </div>
        `;
    }

    showFullPreview() {
        if (!this.results) {
            window.app.showNotification('No receipt data available', 'error');
            return;
        }

        const modal = document.getElementById('preview-modal');
        const modalContent = document.getElementById('modal-content');
        
        modalContent.innerHTML = this.generateFullPreviewHTML(this.results);
        
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
    }

    generateFullPreviewHTML(data) {
        let html = `
            <div class="receipt-preview">
                <div class="receipt-header">
                    <h3>${data.merchant_name || 'Digital Receipt'}</h3>
                    <p>Receipt ID: ${data.receipt_id}</p>
                    <p>Date: ${data.date || 'Unknown'}</p>
                </div>
        `;

        if (data.details) {
            html += `<div class="receipt-items">`;
            
            for (const [category, items] of Object.entries(data.details)) {
                html += `
                    <div class="category-section">
                        <h4>${category}</h4>
                        <div class="items-list">
                `;
                
                for (const [itemName, itemData] of Object.entries(items)) {
                    html += `
                        <div class="item-row">
                            <span class="item-name">${itemName}</span>
                            <span class="item-details">${itemData.quantity} ${itemData.unit} × ${getCurrencySymbol(data.currency)}${itemData.price}</span>
                        </div>
                    `;
                }
                
                html += `
                        </div>
                        <div class="category-total">
                            Category Total: ${getCurrencySymbol(data.currency)}${data.category_total?.[category] || '0.00'}
                        </div>
                    </div>
                `;
            }
            
            html += `</div>`;
        }

        html += `
                <div class="receipt-footer">
                    <div class="total-row">
                        <strong>Total Amount: ${getCurrencySymbol(data.currency)}${data.total_amount || '0.00'}</strong>
                    </div>
                    ${data.tax_total ? `<div class="tax-row">Tax: ${getCurrencySymbol(data.currency)}${data.tax_total}</div>` : ''}
                </div>
            </div>
        `;

        // Add preview styles
        if (!document.querySelector('#full-preview-styles')) {
            const styles = document.createElement('style');
            styles.id = 'full-preview-styles';
            styles.textContent = `
                .receipt-preview {
                    max-width: 600px;
                    margin: 0 auto;
                }
                
                .receipt-header {
                    text-align: center;
                    padding-bottom: var(--spacing-lg);
                    border-bottom: 2px solid var(--google-border);
                    margin-bottom: var(--spacing-lg);
                }
                
                .receipt-header h3 {
                    color: var(--google-blue);
                    margin-bottom: var(--spacing-sm);
                }
                
                .category-section {
                    margin-bottom: var(--spacing-lg);
                    padding: var(--spacing-md);
                    background: var(--google-light-grey);
                    border-radius: var(--border-radius-md);
                }
                
                .category-section h4 {
                    color: var(--google-green);
                    margin-bottom: var(--spacing-md);
                    border-bottom: 1px solid var(--google-border);
                    padding-bottom: var(--spacing-sm);
                }
                
                .item-row {
                    display: flex;
                    justify-content: space-between;
                    padding: var(--spacing-xs) 0;
                    border-bottom: 1px solid rgba(0,0,0,0.1);
                }
                
                .item-name {
                    font-weight: 500;
                }
                
                .item-details {
                    color: var(--google-grey);
                }
                
                .category-total {
                    text-align: right;
                    font-weight: 600;
                    color: var(--google-blue);
                    margin-top: var(--spacing-sm);
                    padding-top: var(--spacing-sm);
                    border-top: 1px solid var(--google-border);
                }
                
                .receipt-footer {
                    margin-top: var(--spacing-lg);
                    padding-top: var(--spacing-lg);
                    border-top: 2px solid var(--google-border);
                    text-align: right;
                }
                
                .total-row {
                    font-size: var(--font-size-lg);
                    color: var(--google-green);
                    margin-bottom: var(--spacing-sm);
                }
                
                .tax-row {
                    color: var(--google-grey);
                }
            `;
            document.head.appendChild(styles);
        }

        return html;
    }

    downloadReceipt() {
        if (!this.results) {
            window.app.showNotification('No receipt data to download', 'error');
            return;
        }

        // Create downloadable JSON
        const dataStr = JSON.stringify(this.results, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        
        // Create download link
        const url = URL.createObjectURL(dataBlob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `receipt_${this.results.receipt_id || 'data'}.json`;
        
        // Trigger download
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);

        window.app.showNotification('Receipt data downloaded successfully!', 'success');
    }

    openCamera() {
        // Camera functionality would be implemented here
        window.app.showNotification('Camera functionality coming soon!', 'info');
    }

    openManualEntry() {
        // Manual entry functionality would be implemented here
        window.app.showNotification('Manual entry functionality coming soon!', 'info');
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
}

// Global functions for HTML onclick handlers
function selectMethod(method) {
    window.receiptUpload.selectMethod(method);
}

function handleFileSelect(event) {
    window.receiptUpload.handleFileSelect(event);
}

function closeModal() {
    const modal = document.getElementById('preview-modal');
    modal.classList.remove('show');
    document.body.style.overflow = 'auto';
}

function downloadReceipt() {
    window.receiptUpload.downloadReceipt();
}

// Initialize module when called
function initializeReceiptUpload() {
    if (!window.receiptUpload) {
        console.log('🔧 Initializing ReceiptUploadManager...');
        window.receiptUpload = new ReceiptUploadManager();
    } else {
        console.log('⚠️ ReceiptUploadManager already initialized, skipping...');
    }
    return window.receiptUpload;
}

// Auto-initialize only if this is the default module and app is ready
document.addEventListener('DOMContentLoaded', () => {
    // Wait for app to be fully initialized
    setTimeout(() => {
        // Only initialize if not already done and if we're on the upload module
        if (!window.receiptUpload && (!window.app || window.app.currentModule === 'receipt-upload')) {
            initializeReceiptUpload();
        }
    }, 200);
}); 