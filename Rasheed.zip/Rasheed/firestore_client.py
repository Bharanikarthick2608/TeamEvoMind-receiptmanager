from google.cloud import firestore
from google.oauth2 import service_account
import os

# Find the credentials file
def find_credentials_file():
    """Find the Google Cloud credentials file in multiple possible locations."""
    filename = "project-rasheed-466518-5cdff45af981.json"
    
    # Possible locations to check
    possible_paths = [
        # Relative to current directory
        os.path.join(os.path.dirname(__file__), filename),
        
        # Relative to parent directory
        os.path.join(os.path.dirname(os.path.dirname(__file__)), filename),
        
        # In the same directory as this script
        os.path.join(os.getcwd(), filename),
        
        # One level up from current working directory
        os.path.join(os.path.dirname(os.getcwd()), filename),
    ]
    
    for path in possible_paths:
        abs_path = os.path.abspath(path)
        if os.path.exists(abs_path):
            return abs_path
    
    raise FileNotFoundError(f"Could not find {filename} in any expected location")

CREDENTIALS_PATH = find_credentials_file()
credentials = service_account.Credentials.from_service_account_file(CREDENTIALS_PATH)
db = firestore.Client(credentials=credentials) 