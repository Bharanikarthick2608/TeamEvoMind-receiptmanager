from fastapi import FastAPI
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from fastapi import Request, Response
import os

from app.routers import summary, categories, trends, suggestions
from app.routers.summary import parse_receipt, filter_by_date
from app.firestore_client import db
from datetime import datetime
from collections import OrderedDict
from dateutil.relativedelta import relativedelta
from collections import defaultdict
from calendar import monthrange

app = FastAPI(title='Project Raseed - Personal Finance Dashboard')

# Setup Jinja2 templates
TEMPLATES_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'templates')
templates = Jinja2Templates(directory=TEMPLATES_PATH)

app.include_router(summary.router)
app.include_router(categories.router)
app.include_router(trends.router)
app.include_router(suggestions.router)

@app.get('/')
def root():
    return {'message': 'Welcome to Project Raseed API'}

@app.get('/dashboard', response_class=HTMLResponse)
def dashboard(request: Request, start_date: str = None, end_date: str = None, month: int = None, year: int = None):
    docs = db.collection('Receipts detail').stream()
    receipts = []
    for doc in docs:
        data = doc.to_dict()
        # Use 'date' and 'category_total' fields
        date_str = data.get('date', '')  # format: YYYY-MM-DD
        cat_total = data.get('category_total', {})
        # Sum all values in category_total except 'currency'
        day_total = 0
        for k, v in cat_total.items():
            if k == 'currency':
                continue
            try:
                day_total += float(v.replace(',', ''))
            except Exception:
                continue
        receipts.append({
            'date': date_str,
            'category_total': cat_total,
            'day_total': day_total,
            'receipt_id': data.get('receipt_id', ''),
        })

    # Optionally filter by date
    def parse_date(ts):
        try:
            return datetime.strptime(ts, '%Y-%m-%d')
        except Exception:
            return None
    if start_date:
        start_date_dt = datetime.fromisoformat(start_date)
    else:
        start_date_dt = None
    if end_date:
        end_date_dt = datetime.fromisoformat(end_date)
    else:
        end_date_dt = None
    filtered_receipts = []
    for r in receipts:
        dt = parse_date(r['date'])
        if not dt:
            continue
        if start_date_dt and dt < start_date_dt:
            continue
        if end_date_dt and dt > end_date_dt:
            continue
        filtered_receipts.append(r)
    receipts = filtered_receipts if (start_date or end_date) else receipts

    # Calculate spend_per_day
    spend_per_day = {}
    for r in receipts:
        date = r['date']
        spend_per_day[date] = spend_per_day.get(date, 0) + r['day_total']

    # Calculate total_spend
    total_spend = sum(r['day_total'] for r in receipts)

    # Calculate category_spend
    category_spend = {}
    for r in receipts:
        for k, v in r['category_total'].items():
            if k == 'currency':
                continue
            try:
                category_spend[k] = category_spend.get(k, 0) + float(v.replace(',', ''))
            except Exception:
                continue
    top_category = max(category_spend, key=category_spend.get) if category_spend else ''
    num_receipts = len(receipts)
    avg_spend = total_spend / num_receipts if num_receipts else 0

    # Transactions for table (one per category per day)
    transactions = []
    for r in receipts:
        date_str = r['date']
        for k, v in r['category_total'].items():
            if k == 'currency':
                continue
            try:
                amt = float(v.replace(',', ''))
            except Exception:
                amt = 0
            transactions.append({
                "receipt_id": r["receipt_id"],
                "date": date_str,
                "category": k,
                "item": "",
                "price": f"₹{amt:.2f}",
                "quantity": 1,
                "total_price": f"₹{amt:.2f}"
            })
    transactions.sort(key=lambda x: x['date'], reverse=True)
    suggestions = [
        'You are over budget in Food category!',
        'Consider reducing grocery spend next month.',
        'You frequently buy Pizza. Try a new dish!'
    ]
    # Calculate current month and year
    now = datetime.now()
    current_year = now.year
    current_month = now.month
    # Calculate total_spend_year
    total_spend_year = 0
    monthly_expenses = {}
    for r in receipts:
        dt = parse_date(r['date'])
        if not dt:
            continue
        if dt.year == current_year:
            total_spend_year += r['day_total']
        month_key = dt.strftime('%Y-%m')
        monthly_expenses.setdefault(month_key, 0)
        monthly_expenses[month_key] += r['day_total']
    # Calculate percent_change (current month vs avg of previous months)
    this_month_key = f"{current_year}-{current_month:02d}"
    this_month_expense = monthly_expenses.get(this_month_key, 0)
    past_months = [k for k in monthly_expenses if k != this_month_key]
    avg_past = sum(monthly_expenses[k] for k in past_months) / len(past_months) if past_months else 0
    if avg_past:
        percent_change = ((this_month_expense - avg_past) / avg_past) * 100
    else:
        percent_change = 0
    # Category colors (customize as needed)
    category_colors = {
        'Food & Drinks': '#FF7043',           # Orange
        'Shopping': '#8E24AA',               # Purple
        'Housing': '#3949AB',                # Indigo
        'Transportation': '#039BE5',         # Light Blue
        'Vehicle': '#6D4C41',                # Brown
        'Life & Entertainment': '#43A047',   # Green
        'Communication, PC': '#FBC02D',      # Yellow
        'Financial Expenses': '#D32F2F',     # Red
        'Investments': '#0288D1',            # Blue
        'Income': '#388E3C',                 # Dark Green
        'Others': '#757575',                 # Grey
    }
    for cat in category_spend:
        if cat not in category_colors:
            category_colors[cat] = '#888888'

    # Reorder category_spend and category_colors so 'Others' is always last
    def move_others_last(d):
        if 'Others' in d:
            items = [(k, v) for k, v in d.items() if k != 'Others']
            items.append(('Others', d['Others']))
            return dict(items)
        return d
    category_spend = move_others_last(category_spend)
    # category_colors is already a dict, but for the JS chart, order matters only for the spend dict

    # Prepare spend_per_day_6m and spend_per_day_1y as daily data
    all_dates = sorted(spend_per_day.keys())
    from datetime import timedelta
    def get_last_n_days(n):
        days = set()
        dt = now.date()
        for i in range(n):
            days.add((dt - timedelta(days=i)).strftime('%Y-%m-%d'))
        return days
    last_6m_days = get_last_n_days(180)
    last_1y_days = get_last_n_days(365)
    spend_per_day_6m = OrderedDict()
    spend_per_day_1y = OrderedDict()
    spend_per_day_all = OrderedDict()
    for date in sorted(spend_per_day.keys()):
        if date in last_6m_days:
            spend_per_day_6m[date] = spend_per_day[date]
        if date in last_1y_days:
            spend_per_day_1y[date] = spend_per_day[date]
        spend_per_day_all[date] = spend_per_day[date]
    print('spend_per_day_6m:', spend_per_day_6m)
    print('spend_per_day_1y:', spend_per_day_1y)

    # Calculate highest category increase compared to previous month
    # Build category spend per month
    category_month_spend = defaultdict(lambda: defaultdict(float))  # category -> month -> spend
    for r in receipts:
        dt = parse_date(r['date'])
        if not dt:
            continue
        month = dt.strftime('%Y-%m')
        for k, v in r['category_total'].items():
            if k == 'currency':
                continue
            try:
                amt = float(v.replace(',', ''))
            except Exception:
                amt = 0
            category_month_spend[k][month] += amt
    # Find the most recent month with data
    all_months = set()
    for cat, month_data in category_month_spend.items():
        all_months.update(month_data.keys())
    if all_months:
        sorted_months = sorted(all_months)
        if len(sorted_months) >= 2:
            last_month = sorted_months[-1]
            prev_month = sorted_months[-2]
            max_increase = 0
            max_cat = ''
            for cat, month_data in category_month_spend.items():
                curr = month_data.get(last_month, 0)
                prev = month_data.get(prev_month, 0)
                if prev > 0:
                    pct = ((curr - prev) / prev) * 100
                else:
                    pct = 0
                if pct > max_increase and curr > prev:
                    max_increase = pct
                    max_cat = cat
            if max_cat and max_increase > 0:
                trend_category_rise_text = f"↑ {max_increase:.0f}% rise in {max_cat}"
            else:
                trend_category_rise_text = ''
        else:
            trend_category_rise_text = ''
    else:
        trend_category_rise_text = ''

    # Budget data graph
    budget_data = {}
    try:
        budget_docs = db.collection('Budget collection').stream()
        for doc in budget_docs:
            data = doc.to_dict()
            budget_data.update(data)  # Assuming each doc is like {"Food & Drinks": 5000, ...}
    except Exception as e:
        print("Error fetching Budget:", e)
    print('budget_data:', budget_data)

    try:
        budget_docs = db.collection('Budget').stream()
        for doc in budget_docs:
            data = doc.to_dict()
            for k in budget_data.keys():
                if k in data:
                    budget_data[k] = float(data[k])
    except Exception as e:
        print("Error fetching Budget:", e)

    # Total spent so far per category
    spent_data = {cat: 0 for cat in budget_data}
    for r in receipts:
        for k, v in r['category_total'].items():
            if k == 'currency' or k not in spent_data:
                continue
            try:
                spent_data[k] += float(v.replace(',', ''))
            except Exception:
                continue
    

    # Reorder budget_data to move "Others" to the end
    if "Others" in budget_data:
        budget_data = OrderedDict(
            (k, v) for k, v in budget_data.items() if k != "Others"
        )
        budget_data["Others"] = data["Others"]

    # --- Calendar Heatmap Data ---
    # Find all years in receipts
    all_years = set()
    for r in receipts:
        dt = parse_date(r['date'])
        if dt:
            all_years.add(dt.year)
    if not all_years:
        all_years = {datetime.now().year}
    available_years = sorted(all_years)
    # Force default to current month/year if not provided
    now = datetime.now()
    sel_year = None
    sel_month = None
    if year is None or str(year).strip() == '':
        sel_year = now.year
    else:
        try:
            sel_year = int(year)
        except Exception:
            sel_year = now.year
    if month is None or str(month).strip() == '':
        sel_month = now.month
    else:
        try:
            if '-' in str(month):
                sel_month = int(str(month).split('-')[1])
            else:
                sel_month = int(month)
        except Exception:
            sel_month = now.month
    # Ensure calendar_month and calendar_year are always integers
    sel_year = int(sel_year)
    sel_month = int(sel_month)
    # Build spend_per_day for selected month/year
    spend_per_day_month = {}
    for r in receipts:
        dt = parse_date(r['date'])
        if dt and dt.year == sel_year and dt.month == sel_month:
            spend_per_day_month[dt.day] = spend_per_day_month.get(dt.day, 0) + r['day_total']
    # Build calendar grid (weeks)
    first_weekday, num_days = monthrange(sel_year, sel_month)
    # Calendar grid: list of weeks, each week is list of dicts {day, spend, date}
    calendar_grid = []
    week = []
    day_num = 1
    # Fill leading empty days
    for _ in range(first_weekday):
        week.append({'day': '', 'spend': None, 'date': ''})
    while day_num <= num_days:
        week.append({
            'day': day_num,
            'spend': spend_per_day_month.get(day_num, 0),
            'date': f"{sel_year:04d}-{sel_month:02d}-{day_num:02d}"
        })
        if len(week) == 7:
            calendar_grid.append(week)
            week = []
        day_num += 1
    # Fill trailing empty days
    if week:
        while len(week) < 7:
            week.append({'day': '', 'spend': None, 'date': ''})
        calendar_grid.append(week)
    # For color scale
    spends = [v for v in spend_per_day_month.values() if v > 0]
    min_spend = min(spends) if spends else 0
    max_spend = max(spends) if spends else 1

    # Calculate avg_spend_percent for donut chart
    if num_receipts > 1 and total_spend > 0:
        avg_spend_percent = int(round((avg_spend / (total_spend / num_receipts)) * 100))
    else:
        avg_spend_percent = 100 if num_receipts == 1 else 0

    # Sub-KPI: Daily Average Spend
    if spend_per_day:
        daily_avg_spend = sum(spend_per_day.values()) / len(spend_per_day)
    else:
        daily_avg_spend = 0
    # Sub-KPI: Top Category % of Total Spend
    if top_category and total_spend > 0:
        top_category_percent = (category_spend[top_category] / total_spend) * 100
    else:
        top_category_percent = 0
    # Sub-KPI: Most Recent Receipt Date
    if receipts:
        most_recent_date = max(r['date'] for r in receipts if r['date'])
        try:
            most_recent_date_fmt = datetime.strptime(most_recent_date, '%Y-%m-%d').strftime('%b %d, %Y')
        except Exception:
            most_recent_date_fmt = most_recent_date
    else:
        most_recent_date_fmt = ''
    # Sub-KPI: Min/Max Spend per Receipt
    if receipts:
        min_spend = min(r['day_total'] for r in receipts)
        max_spend = max(r['day_total'] for r in receipts)
    else:
        min_spend = 0
        max_spend = 0

    # Category icons mapping (emoji for now)
    category_icons = {
        'Food & Drinks': '🍽️',
        'Utilities': '🏠',
        'Travel': '✈️',
        'Entertainment': '🎮',
        'Shopping': '🛒',
        'Transport': '🚗',
        'Housing': '🏡',
        'Vehicle': '🚙',
        'Life & Entertainment': '🎉',
        'Communication, PC': '💻',
        'Financial Expenses': '💸',
        'Investments': '📈',
        'Income': '💵',
        'Others': '📦',
    }
    # Prepare legend data: list of dicts with icon, name, amount, percent, background_color
    legend_data = []
    for cat, amt in category_spend.items():
        percent = (amt / total_spend * 100) if total_spend else 0
        legend_data.append({
            'icon': category_icons.get(cat, '📦'),
            'name': cat,
            'amount': amt,
            'percent': percent,
            'background_color': category_colors.get(cat, '#888888'),
        })
    # Sort by amount descending
    legend_data.sort(key=lambda x: x['amount'], reverse=True)

    # --- Expense Trends Data for Chart and KPI ---
    # 1. Daily: current month, day-to-day
    trend_daily = OrderedDict()
    now = datetime.now()
    for r in receipts:
        dt = parse_date(r['date'])
        if dt and dt.year == now.year and dt.month == now.month:
            trend_daily[dt.day] = trend_daily.get(dt.day, 0) + r['day_total']
    # Fill missing days with 0
    _, num_days = monthrange(now.year, now.month)
    for d in range(1, num_days+1):
        if d not in trend_daily:
            trend_daily[d] = 0
    trend_daily = OrderedDict(sorted(trend_daily.items()))

    # 2. Monthly: current year, month-on-month
    trend_monthly = OrderedDict()
    for r in receipts:
        dt = parse_date(r['date'])
        if dt and dt.year == now.year:
            m = dt.month
            trend_monthly[m] = trend_monthly.get(m, 0) + r['day_total']
    for m in range(1, 13):
        if m not in trend_monthly:
            trend_monthly[m] = 0
    trend_monthly = OrderedDict(sorted(trend_monthly.items()))

    # 3. Yearly: all years, year-on-year
    trend_yearly = OrderedDict()
    for r in receipts:
        dt = parse_date(r['date'])
        if dt:
            y = dt.year
            trend_yearly[y] = trend_yearly.get(y, 0) + r['day_total']
    for y in sorted(all_years):
        if y not in trend_yearly:
            trend_yearly[y] = 0
    trend_yearly = OrderedDict(sorted(trend_yearly.items()))

    # KPIs
    # Daily: latest day vs previous day
    trend_kpi_daily = 0
    if len(trend_daily) > 1:
        days = list(trend_daily.keys())
        latest, prev = days[-1], days[-2]
        prev_val = trend_daily[prev]
        latest_val = trend_daily[latest]
        if prev_val:
            trend_kpi_daily = ((latest_val - prev_val) / prev_val) * 100
        else:
            trend_kpi_daily = 0
    # Monthly: current month vs previous month
    trend_kpi_monthly = 0
    if len(trend_monthly) > 1:
        months = list(trend_monthly.keys())
        curr, prev = months[-1], months[-2]
        prev_val = trend_monthly[prev]
        curr_val = trend_monthly[curr]
        if prev_val:
            trend_kpi_monthly = ((curr_val - prev_val) / prev_val) * 100
        else:
            trend_kpi_monthly = 0
    # Yearly: current year vs previous year
    trend_kpi_yearly = 0
    if len(trend_yearly) > 1:
        years = list(trend_yearly.keys())
        curr, prev = years[-1], years[-2]
        prev_val = trend_yearly[prev]
        curr_val = trend_yearly[curr]
        if prev_val:
            trend_kpi_yearly = ((curr_val - prev_val) / prev_val) * 100
        else:
            trend_kpi_yearly = 0

    return templates.TemplateResponse('dashboard.html', {
        'request': request,
        'total_spend': f'₹{total_spend:.2f}',
        'top_category': top_category,
        'num_receipts': num_receipts,
        'avg_spend': f'₹{avg_spend:.2f}',
        'category_spend': category_spend,
        'spend_per_day': spend_per_day,
        'spend_per_day_6m': spend_per_day_6m,
        'spend_per_day_1y': spend_per_day_1y,
        'spend_per_day_all': spend_per_day_all,
        'transactions': transactions[:10],
        'suggestions': suggestions,
        'total_spend_year': f'{total_spend_year:.2f}',
        'percent_change': percent_change,
        'category_colors': category_colors,
        'trend_category_rise_text': trend_category_rise_text,
        'calendar_grid': calendar_grid,
        'calendar_month': sel_month,
        'calendar_year': sel_year,
        'calendar_years': available_years,
        'calendar_min_spend': min_spend,
        'calendar_max_spend': max_spend,
        'avg_spend_percent': avg_spend_percent,
        'daily_avg_spend': daily_avg_spend,
        'top_category_percent': top_category_percent,
        'most_recent_date_fmt': most_recent_date_fmt,
        'min_spend': min_spend,
        'max_spend': max_spend,
        'category_legend': legend_data,
        'trend_daily': trend_daily,
        'trend_monthly': trend_monthly,
        'trend_yearly': trend_yearly,
        'trend_kpi_daily': trend_kpi_daily,
        'trend_kpi_monthly': trend_kpi_monthly,
        'trend_kpi_yearly': trend_kpi_yearly,
        'budget_data': budget_data,
        'spent_data': spent_data,
    })

@app.get('/calendar-heatmap', response_class=HTMLResponse)
def calendar_heatmap(request: Request, month: int = None, year: int = None):
    # --- Calendar Heatmap Data (same as dashboard) ---
    docs = db.collection('Receipts detail').stream()
    receipts = []
    for doc in docs:
        data = doc.to_dict()
        date_str = data.get('date', '')
        cat_total = data.get('category_total', {})
        day_total = 0
        for k, v in cat_total.items():
            if k == 'currency':
                continue
            try:
                day_total += float(v.replace(',', ''))
            except Exception:
                continue
        receipts.append({
            'date': date_str,
            'category_total': cat_total,
            'day_total': day_total,
            'receipt_id': data.get('receipt_id', ''),
        })
    def parse_date(ts):
        try:
            return datetime.strptime(ts, '%Y-%m-%d')
        except Exception:
            return None
    now = datetime.now()
    try:
        sel_year = int(year) if year else now.year
    except Exception:
        sel_year = now.year
    try:
        if month and '-' in str(month):
            sel_month = int(str(month).split('-')[1])
        else:
            sel_month = int(month) if month else now.month
    except Exception:
        sel_month = now.month
    spend_per_day_month = {}
    for r in receipts:
        dt = parse_date(r['date'])
        if dt and dt.year == sel_year and dt.month == sel_month:
            spend_per_day_month[dt.day] = spend_per_day_month.get(dt.day, 0) + r['day_total']
    first_weekday, num_days = monthrange(sel_year, sel_month)
    calendar_grid = []
    week = []
    day_num = 1
    for _ in range(first_weekday):
        week.append({'day': '', 'spend': None, 'date': ''})
    while day_num <= num_days:
        week.append({
            'day': day_num,
            'spend': spend_per_day_month.get(day_num, 0),
            'date': f"{sel_year:04d}-{sel_month:02d}-{day_num:02d}"
        })
        if len(week) == 7:
            calendar_grid.append(week)
            week = []
        day_num += 1
    if week:
        while len(week) < 7:
            week.append({'day': '', 'spend': None, 'date': ''})
        calendar_grid.append(week)
    spends = [v for v in spend_per_day_month.values() if v > 0]
    min_spend = min(spends) if spends else 0
    max_spend = max(spends) if spends else 1
    return templates.TemplateResponse('calendar_heatmap.html', {
        'request': request,
        'calendar_grid': calendar_grid,
        'calendar_min_spend': min_spend,
        'calendar_max_spend': max_spend,
    }) 