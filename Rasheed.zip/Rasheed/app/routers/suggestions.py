from fastapi import APIRouter
from typing import List

router = APIRouter()

@router.get('/dashboard/suggestions')
def get_suggestions():
    return {
        'suggestions': [
            'You are over budget in Food category!',
            'Consider reducing grocery spend next month.',
            'You frequently buy Pizza. Try a new dish!'
        ]
    } 