from fastapi import APIRouter, Query, Depends
from typing import Optional
from app.firestore_client import db
from app.models.summary import SummaryResponse
from app.models.receipt import Receipt, Item
from datetime import datetime

router = APIRouter()

CURRENCY = '₹'

def parse_item_string(item_str: str):
    # Format: '₹500/1'
    price_part, qty_part = item_str.replace(CURRENCY, '').split('/')
    price = float(price_part)
    quantity = int(qty_part)
    return price, quantity, price * quantity

def parse_receipt(doc):
    data = doc.to_dict()
    parsed_items = []
    for category, items in data['details'].items():
        for item, val in items.items():
            price, quantity, total_price = parse_item_string(val)
            parsed_items.append(Item(
                category=category,
                item=item,
                price=price,
                quantity=quantity,
                total_price=total_price
            ))
    return Receipt(
        receipt_id=data['receipt_id'],
        date=data['date'],
        details=data['details'],
        parsed_items=parsed_items
    )

def filter_by_date(receipts, start_date, end_date):
    if not start_date and not end_date:
        return receipts
    filtered = []
    for r in receipts:
        dt = datetime.fromisoformat(r.date.replace('Z', '+00:00'))
        if start_date and dt < start_date:
            continue
        if end_date and dt > end_date:
            continue
        filtered.append(r)
    return filtered

@router.get('/dashboard/summary', response_model=SummaryResponse)
def get_summary(start_date: Optional[str] = Query(None), end_date: Optional[str] = Query(None)):
    docs = db.collection('products').stream()
    receipts = [parse_receipt(doc) for doc in docs]
    if start_date:
        start_date_dt = datetime.fromisoformat(start_date)
    else:
        start_date_dt = None
    if end_date:
        end_date_dt = datetime.fromisoformat(end_date)
    else:
        end_date_dt = None
    receipts = filter_by_date(receipts, start_date_dt, end_date_dt)
    total_spend = sum(item.total_price for r in receipts for item in r.parsed_items)
    category_spend = {}
    for r in receipts:
        for item in r.parsed_items:
            category_spend[item.category] = category_spend.get(item.category, 0) + item.total_price
    top_category = max(category_spend, key=category_spend.get) if category_spend else ''
    num_receipts = len(receipts)
    avg_spend = total_spend / num_receipts if num_receipts else 0
    return SummaryResponse(
        total_spend=f'{CURRENCY}{total_spend:.2f}',
        top_category=top_category,
        num_receipts=num_receipts,
        avg_spend_per_receipt=f'{CURRENCY}{avg_spend:.2f}'
    ) 