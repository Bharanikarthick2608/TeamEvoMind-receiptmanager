from fastapi import APIRouter, Query
from typing import List, Optional
from app.firestore_client import db
from app.models.trend import TrendPoint, Transaction
from app.routers.summary import parse_receipt, filter_by_date
from datetime import datetime

router = APIRouter()
CURRENCY = '₹'

@router.get('/dashboard/trends', response_model=List[TrendPoint])
def get_trends(start_date: Optional[str] = Query(None), end_date: Optional[str] = Query(None)):
    docs = db.collection('products').stream()
    receipts = [parse_receipt(doc) for doc in docs]
    if start_date:
        start_date_dt = datetime.fromisoformat(start_date)
    else:
        start_date_dt = None
    if end_date:
        end_date_dt = datetime.fromisoformat(end_date)
    else:
        end_date_dt = None
    receipts = filter_by_date(receipts, start_date_dt, end_date_dt)
    spend_per_day = {}
    for r in receipts:
        date = r.date[:10]
        spend_per_day[date] = spend_per_day.get(date, 0) + sum(item.total_price for item in r.parsed_items)
    return [TrendPoint(date=k, total_spend=f'{CURRENCY}{v:.2f}') for k, v in sorted(spend_per_day.items())]

@router.get('/dashboard/transactions', response_model=List[Transaction])
def get_transactions(start_date: Optional[str] = Query(None), end_date: Optional[str] = Query(None)):
    docs = db.collection('products').stream()
    receipts = [parse_receipt(doc) for doc in docs]
    if start_date:
        start_date_dt = datetime.fromisoformat(start_date)
    else:
        start_date_dt = None
    if end_date:
        end_date_dt = datetime.fromisoformat(end_date)
    else:
        end_date_dt = None
    receipts = filter_by_date(receipts, start_date_dt, end_date_dt)
    transactions = []
    for r in receipts:
        for item in r.parsed_items:
            transactions.append(Transaction(
                receipt_id=r.receipt_id,
                date=r.date,
                category=item.category,
                item=item.item,
                price=f'{CURRENCY}{item.price:.2f}',
                quantity=item.quantity,
                total_price=f'{CURRENCY}{item.total_price:.2f}'
            ))
    transactions.sort(key=lambda x: x.date, reverse=True)
    return transactions 