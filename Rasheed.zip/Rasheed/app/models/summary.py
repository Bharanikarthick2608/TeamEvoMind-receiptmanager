from pydantic import BaseModel
from typing import Dict

class SummaryResponse(BaseModel):
    total_spend: str
    top_category: str
    num_receipts: int
    avg_spend_per_receipt: str

class CategorySpend(BaseModel):
    category: str
    spend: str 