from pydantic import BaseModel
from typing import Dict, List, Any

class Item(BaseModel):
    category: str
    item: str
    price: float
    quantity: int
    total_price: float

class Receipt(BaseModel):
    receipt_id: str
    date: str
    details: Dict[str, Dict[str, str]]
    parsed_items: List[Item] 