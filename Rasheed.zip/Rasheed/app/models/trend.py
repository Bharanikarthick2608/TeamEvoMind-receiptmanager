from pydantic import BaseModel
from typing import List

class TrendPoint(BaseModel):
    date: str
    total_spend: str

class Transaction(BaseModel):
    receipt_id: str
    date: str
    category: str
    item: str
    price: str
    quantity: int
    total_price: str 