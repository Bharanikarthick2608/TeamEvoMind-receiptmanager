from fastapi import APIRouter, Query
from typing import List, Optional
from firestore_client import db
from models.summary import CategorySpend
from routers.summary import parse_receipt, filter_by_date
from datetime import datetime

router = APIRouter()
CURRENCY = '₹'

@router.get('/dashboard/categories', response_model=List[CategorySpend])
def get_categories(start_date: Optional[str] = Query(None), end_date: Optional[str] = Query(None)):
    docs = db.collection('products').stream()
    receipts = [parse_receipt(doc) for doc in docs]
    if start_date:
        start_date_dt = datetime.fromisoformat(start_date)
    else:
        start_date_dt = None
    if end_date:
        end_date_dt = datetime.fromisoformat(end_date)
    else:
        end_date_dt = None
    receipts = filter_by_date(receipts, start_date_dt, end_date_dt)
    category_spend = {}
    for r in receipts:
        for item in r.parsed_items:
            category_spend[item.category] = category_spend.get(item.category, 0) + item.total_price
    return [CategorySpend(category=k, spend=f'{CURRENCY}{v:.2f}') for k, v in category_spend.items()] 