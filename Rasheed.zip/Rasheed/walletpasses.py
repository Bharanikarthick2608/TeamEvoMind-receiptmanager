import os
import sys
import json
from datetime import datetime
from typing import Dict, List, Any, Optional
from google.cloud import firestore
from google.oauth2 import service_account

class WalletPassesManager:
    """
    Manages wallet passes functionality by connecting to Firestore
    and retrieving receipt data for display in the wallet passes page.
    """
    
    def __init__(self, credentials_path: str, project_id: str = "project-rasheed-466518"):
        """
        Initialize the WalletPassesManager with Firestore connection.
        
        Args:
            credentials_path: Path to Google Cloud credentials JSON file
            project_id: Google Cloud project ID
        """
        self.credentials_path = credentials_path
        self.project_id = project_id
        self.firestore_client = None
        self._initialize_firestore()
    
    def _initialize_firestore(self):
        """Initialize Firestore client with credentials."""
        try:
            credentials = service_account.Credentials.from_service_account_file(
                self.credentials_path
            )
            self.firestore_client = firestore.Client(
                credentials=credentials,
                project=self.project_id
            )
            print("✅ Firestore client initialized successfully for Wallet Passes")
        except Exception as e:
            print(f"❌ Failed to initialize Firestore client: {e}")
            self.firestore_client = None
    
    def get_all_receipts(self, limit: int = 50, offset: int = 0) -> Dict[str, Any]:
        """
        Retrieve all receipts from Firestore for wallet passes display.
        
        Args:
            limit: Maximum number of receipts to return
            offset: Number of receipts to skip for pagination
            
        Returns:
            Dictionary containing receipts data and pagination info
        """
        if not self.firestore_client:
            return {
                "error": "Firestore client not initialized",
                "receipts": [],
                "pagination": {"total": 0, "limit": limit, "offset": offset, "has_more": False}
            }
        
        try:
            # Get receipts from Firestore
            receipts_ref = self.firestore_client.collection("Receipts detail")
            
            # Apply pagination and ordering by processing timestamp
            query = receipts_ref.order_by("processing_timestamp", direction="DESCENDING").limit(limit).offset(offset)
            docs = query.stream()
            
            receipts = []
            for doc in docs:
                receipt_data = doc.to_dict()
                receipt_data["id"] = doc.id
                
                # Format the receipt data for wallet passes display
                formatted_receipt = self._format_receipt_for_display(receipt_data)
                receipts.append(formatted_receipt)
            
            # Get total count for pagination
            total_count = len(list(receipts_ref.stream()))
            
            return {
                "receipts": receipts,
                "pagination": {
                    "total": total_count,
                    "limit": limit,
                    "offset": offset,
                    "has_more": offset + limit < total_count
                }
            }
            
        except Exception as e:
            print(f"❌ Error retrieving receipts for wallet passes: {e}")
            return {
                "error": f"Failed to retrieve receipts: {str(e)}",
                "receipts": [],
                "pagination": {"total": 0, "limit": limit, "offset": offset, "has_more": False}
            }
    
    def get_receipt_by_id(self, receipt_id: str) -> Dict[str, Any]:
        """
        Get a specific receipt by ID for detailed view.
        
        Args:
            receipt_id: The receipt ID to retrieve
            
        Returns:
            Dictionary containing detailed receipt data
        """
        if not self.firestore_client:
            return {"error": "Firestore client not initialized"}
        
        try:
            doc_ref = self.firestore_client.collection("Receipts detail").document(receipt_id)
            doc = doc_ref.get()
            
            if not doc.exists:
                return {"error": f"Receipt {receipt_id} not found"}
            
            receipt_data = doc.to_dict()
            receipt_data["id"] = doc.id
            
            # Format the receipt data for detailed display
            formatted_receipt = self._format_receipt_for_display(receipt_data, detailed=True)
            return formatted_receipt
            
        except Exception as e:
            print(f"❌ Error retrieving receipt {receipt_id}: {e}")
            return {"error": f"Failed to retrieve receipt: {str(e)}"}
    
    def _format_receipt_for_display(self, receipt_data: Dict[str, Any], detailed: bool = False) -> Dict[str, Any]:
        """
        Format receipt data for display in wallet passes interface.
        
        Args:
            receipt_data: Raw receipt data from Firestore
            detailed: Whether to include detailed information
            
        Returns:
            Formatted receipt data for display
        """
        try:
            # Extract basic information
            merchant_name = receipt_data.get("merchant_name", "Unknown Merchant")
            total_amount = receipt_data.get("total_amount", "0.00")
            date = receipt_data.get("date", "Unknown Date")
            processing_timestamp = receipt_data.get("processing_timestamp", "")
            
            # Calculate budget status based on amount
            budget_status = self._calculate_budget_status(total_amount)
            
            # Get OCR confidence
            ocr_confidence = receipt_data.get("ocr_confidence", 0)
            
            # Count items
            items_count = self._count_items(receipt_data)
            
            # Get category
            category = self._get_primary_category(receipt_data)
            
            # Get status icon
            status_icon = self._get_status_icon(receipt_data)
            
            formatted_receipt = {
                "id": receipt_data.get("id", ""),
                "merchant_name": merchant_name,
                "total_amount": total_amount,
                "date": date,
                "processing_timestamp": processing_timestamp,
                "budget_status": budget_status,
                "ocr_confidence": f"{ocr_confidence}%",
                "items_count": f"{items_count} items",
                "category": category,
                "status_icon": status_icon,
                "wallet_link": receipt_data.get("google_wallet_link", None)
            }
            
            if detailed:
                # Add detailed information for full receipt view
                formatted_receipt.update({
                    "raw_data": receipt_data,
                    "items": receipt_data.get("items", []),
                    "category_breakdown": receipt_data.get("category_total", {}),
                    "tax_amount": receipt_data.get("tax_amount", "0.00"),
                    "currency": receipt_data.get("currency", "USD"),
                    "receipt_image_url": receipt_data.get("receipt_image_url", ""),
                    "processing_metadata": {
                        "processing_time": receipt_data.get("processing_time", ""),
                        "ocr_confidence": ocr_confidence,
                        "language_detected": receipt_data.get("language_detected", "en"),
                        "text_extracted": receipt_data.get("extracted_text", "")
                    }
                })
            
            return formatted_receipt
            
        except Exception as e:
            print(f"❌ Error formatting receipt data: {e}")
            return {
                "id": receipt_data.get("id", ""),
                "merchant_name": "Error formatting data",
                "total_amount": "0.00",
                "date": "Unknown",
                "budget_status": "Unknown",
                "ocr_confidence": "0%",
                "items_count": "0 items",
                "category": "Unknown",
                "status_icon": "error"
            }
    
    def _calculate_budget_status(self, total_amount: str) -> str:
        """
        Calculate budget status based on total amount.
        
        Args:
            total_amount: Total amount as string
            
        Returns:
            Budget status string
        """
        try:
            # Remove currency symbols and convert to float
            amount_str = str(total_amount).replace("$", "").replace("₹", "").replace(",", "")
            amount = float(amount_str)
            
            # Simple budget logic (can be enhanced with actual budget data)
            if amount <= 1000:
                return "Under Budget"
            elif amount <= 2500:
                return "Near Limit"
            else:
                return "Over Budget"
                
        except (ValueError, AttributeError):
            return "Unknown"
    
    def _count_items(self, receipt_data: Dict[str, Any]) -> int:
        """
        Count the number of items in the receipt.
        
        Args:
            receipt_data: Receipt data from Firestore
            
        Returns:
            Number of items
        """
        try:
            items = receipt_data.get("items", [])
            if isinstance(items, list):
                return len(items)
            elif isinstance(items, dict):
                return len(items.keys())
            else:
                return 0
        except:
            return 0
    
    def _get_primary_category(self, receipt_data: Dict[str, Any]) -> str:
        """
        Get the primary category from receipt data.
        
        Args:
            receipt_data: Receipt data from Firestore
            
        Returns:
            Primary category name
        """
        try:
            category_total = receipt_data.get("category_total", {})
            if category_total and isinstance(category_total, dict):
                # Return the category with highest amount
                max_category = max(category_total.items(), key=lambda x: float(str(x[1]).replace("$", "").replace("₹", "").replace(",", "")))
                return max_category[0]
            else:
                return "General"
        except:
            return "General"
    
    def _get_status_icon(self, receipt_data: Dict[str, Any]) -> str:
        """
        Get status icon based on receipt data.
        
        Args:
            receipt_data: Receipt data from Firestore
            
        Returns:
            Status icon identifier
        """
        try:
            # Check if wallet link exists
            if receipt_data.get("google_wallet_link"):
                return "success"
            
            # Check OCR confidence
            ocr_confidence = receipt_data.get("ocr_confidence", 0)
            if ocr_confidence >= 90:
                return "success"
            elif ocr_confidence >= 70:
                return "warning"
            else:
                return "error"
                
        except:
            return "unknown"
    
    def get_wallet_passes_summary(self) -> Dict[str, Any]:
        """
        Get summary statistics for wallet passes.
        
        Returns:
            Dictionary with wallet passes summary
        """
        if not self.firestore_client:
            return {"error": "Firestore client not initialized"}
        
        try:
            receipts_ref = self.firestore_client.collection("Receipts detail")
            docs = receipts_ref.stream()
            
            total_receipts = 0
            total_amount = 0
            wallet_passes_count = 0
            categories = {}
            
            for doc in docs:
                receipt_data = doc.to_dict()
                total_receipts += 1
                
                # Calculate total amount
                try:
                    amount_str = str(receipt_data.get("total_amount", "0")).replace("$", "").replace("₹", "").replace(",", "")
                    amount = float(amount_str)
                    total_amount += amount
                except:
                    pass
                
                # Count wallet passes
                if receipt_data.get("google_wallet_link"):
                    wallet_passes_count += 1
                
                # Count categories
                category = self._get_primary_category(receipt_data)
                categories[category] = categories.get(category, 0) + 1
            
            return {
                "total_receipts": total_receipts,
                "total_amount": f"${total_amount:.2f}",
                "wallet_passes_count": wallet_passes_count,
                "categories_count": len(categories),
                "top_categories": sorted(categories.items(), key=lambda x: x[1], reverse=True)[:5]
            }
            
        except Exception as e:
            print(f"❌ Error getting wallet passes summary: {e}")
            return {"error": f"Failed to get summary: {str(e)}"}

# Example usage and testing
def test_wallet_passes_manager():
    """Test the WalletPassesManager functionality."""
    try:
        # Find credentials file
        credentials_path = "project-rasheed-466518-5cdff45af981.json"
        
        # Initialize manager
        manager = WalletPassesManager(credentials_path)
        
        # Test getting receipts
        result = manager.get_all_receipts(limit=10)
        
        if "error" in result:
            print(f"❌ Error: {result['error']}")
        else:
            print(f"✅ Retrieved {len(result['receipts'])} receipts")
            print(f"📊 Total receipts in database: {result['pagination']['total']}")
            
            # Print first receipt as example
            if result['receipts']:
                first_receipt = result['receipts'][0]
                print(f"📄 Sample receipt: {first_receipt['merchant_name']} - {first_receipt['total_amount']}")
        
        # Test summary
        summary = manager.get_wallet_passes_summary()
        if "error" not in summary:
            print(f"📈 Summary: {summary['total_receipts']} receipts, {summary['wallet_passes_count']} wallet passes")
        
    except Exception as e:
        print(f"❌ Test failed: {e}")

if __name__ == "__main__":
    test_wallet_passes_manager()
