import os
import json
import time
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from google.cloud import firestore
from google.oauth2 import service_account
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import seaborn as sns
import pandas as pd
import numpy as np
from collections import defaultdict
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import plotly.offline as pyo

class SpendingAnalyzer:
    def __init__(self, credentials_path: str = "project-rasheed-466518-5cdff45af981.json"):
        """
        Initialize the spending analyzer with Firestore connection.
        
        Args:
            credentials_path (str): Path to Google Cloud credentials file
        """
        self.credentials_path = credentials_path
        self.db = self._initialize_firestore()
        self.colors = {
            'Food & Drinks': '#FF6B6B',
            'Shopping': '#4ECDC4',
            'Housing': '#45B7D1',
            'Transportation': '#96CEB4',
            'Life & Entertainment': '#FFEAA7',
            'Communication, PC': '#DDA0DD',
            'Financial expenses': '#98D8C8',
            'Investments': '#F7DC6F',
            'Others': '#BB8FCE'
        }
        
    def _initialize_firestore(self) -> firestore.Client:
        """Initialize Firestore client."""
        try:
            credentials = service_account.Credentials.from_service_account_file(
                self.credentials_path,
                scopes=["https://www.googleapis.com/auth/cloud-platform"]
            )
            
            db = firestore.Client(project="project-rasheed-466518", credentials=credentials)
            print("✅ Firestore client initialized successfully!")
            return db
        except Exception as e:
            print(f"❌ Error initializing Firestore: {e}")
            raise
    
    def fetch_spending_analysis(self) -> Dict[str, Any]:
        """
        Fetch the latest spending analysis from Firestore.
        
        Returns:
            Dict: Spending analysis data
        """
        try:
            doc_ref = self.db.collection("spending_analysis").document("current_spending_analysis")
            doc = doc_ref.get()
            
            if doc.exists:
                analysis_data = doc.to_dict()
                print("✅ Spending analysis data fetched successfully")
                return analysis_data
            else:
                print("⚠️  No spending analysis found in Firestore")
                return {}
                
        except Exception as e:
            print(f"❌ Error fetching spending analysis: {e}")
            return {}
    
    def fetch_all_receipts(self) -> List[Dict[str, Any]]:
        """
        Fetch all receipts from Firestore for detailed analysis.
        
        Returns:
            List[Dict]: List of all receipt documents
        """
        try:
            receipts = []
            docs = self.db.collection("Receipts detail").stream()
            
            for doc in docs:
                receipt_data = doc.to_dict()
                receipt_data['firestore_id'] = doc.id
                receipts.append(receipt_data)
            
            print(f"✅ Fetched {len(receipts)} receipts from Firestore")
            return receipts
        except Exception as e:
            print(f"❌ Error fetching receipts: {e}")
            return []
    
    def process_spending_data(self, analysis_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process spending data and generate insights.
        
        Args:
            analysis_data (Dict): Raw spending analysis data
            
        Returns:
            Dict: Processed insights and chart data
        """
        try:
            # Extract key metrics
            total_receipts = analysis_data.get("total_receipts", 0)
            total_spending = analysis_data.get("total_spending", 0)
            average_receipt = analysis_data.get("average_receipt_value", 0)
            
            # Category analysis
            category_totals = analysis_data.get("category_totals", {})
            category_percentages = analysis_data.get("category_percentages", {})
            
            # Merchant analysis
            merchant_totals = analysis_data.get("merchant_totals", {})
            top_merchant = analysis_data.get("top_merchant_name", "")
            top_merchant_amount = analysis_data.get("top_merchant_amount", 0)
            
            # Monthly analysis
            monthly_totals = analysis_data.get("monthly_totals", {})
            highest_month = analysis_data.get("highest_spending_month", "")
            highest_month_amount = analysis_data.get("highest_spending_month_amount", 0)
            
            # Calculate trends
            monthly_trend = self._calculate_monthly_trend(monthly_totals)
            
            # Generate insights
            insights = {
                "summary_metrics": {
                    "total_receipts": total_receipts,
                    "total_spending": total_spending,
                    "average_receipt": average_receipt,
                    "currency": "INR"
                },
                "category_breakdown": {
                    "totals": category_totals,
                    "percentages": category_percentages,
                    "top_category": max(category_totals.items(), key=lambda x: x[1]) if category_totals else ("", 0),
                    "lowest_category": min(category_totals.items(), key=lambda x: x[1]) if category_totals else ("", 0)
                },
                "merchant_insights": {
                    "top_merchant": (top_merchant, top_merchant_amount),
                    "merchant_totals": merchant_totals,
                    "top_merchants": sorted(merchant_totals.items(), key=lambda x: x[1], reverse=True)[:5]
                },
                "monthly_trends": {
                    "monthly_totals": monthly_totals,
                    "highest_month": (highest_month, highest_month_amount),
                    "trend_direction": monthly_trend["direction"],
                    "trend_percentage": monthly_trend["percentage"]
                },
                "ai_forecast": self._generate_ai_forecast(monthly_totals, total_spending),
                "saving_recommendations": self._generate_saving_recommendations(category_totals, merchant_totals)
            }
            
            return insights
            
        except Exception as e:
            print(f"❌ Error processing spending data: {e}")
            return {}
    
    def _calculate_monthly_trend(self, monthly_totals: Dict[str, float]) -> Dict[str, Any]:
        """Calculate monthly spending trend."""
        if len(monthly_totals) < 2:
            return {"direction": "stable", "percentage": 0}
        
        # Sort months chronologically
        sorted_months = sorted(monthly_totals.items())
        if len(sorted_months) >= 2:
            current_month = sorted_months[-1][1]
            previous_month = sorted_months[-2][1]
            
            if previous_month > 0:
                percentage_change = ((current_month - previous_month) / previous_month) * 100
                direction = "rising" if percentage_change > 0 else "falling" if percentage_change < 0 else "stable"
                return {"direction": direction, "percentage": abs(percentage_change)}
        
        return {"direction": "stable", "percentage": 0}
    
    def _generate_ai_forecast(self, monthly_totals: Dict[str, float], total_spending: float) -> Dict[str, Any]:
        """Generate AI-powered spending forecast."""
        try:
            if not monthly_totals:
                return {"predictions": [], "insight": "Insufficient data for forecasting"}
            
            # Calculate average monthly spending
            avg_monthly = sum(monthly_totals.values()) / len(monthly_totals)
            
            # Simple trend-based forecast
            sorted_months = sorted(monthly_totals.items())
            if len(sorted_months) >= 2:
                recent_trend = (sorted_months[-1][1] - sorted_months[-2][1]) / sorted_months[-2][1] if sorted_months[-2][1] > 0 else 0
            else:
                recent_trend = 0
            
            # Generate predictions for next 3 months
            predictions = []
            current_amount = avg_monthly
            
            for i in range(1, 4):
                # Apply trend with some randomness
                trend_factor = 1 + (recent_trend * 0.5) + (np.random.normal(0, 0.05))
                predicted_amount = current_amount * trend_factor
                
                # Calculate confidence based on data consistency
                confidence = max(75, 95 - (i * 5))  # Decreasing confidence for further months
                
                predictions.append({
                    "month": f"Month {i}",
                    "amount": round(predicted_amount, 2),
                    "confidence": confidence
                })
                
                current_amount = predicted_amount
            
            # Generate insight
            if recent_trend > 0.1:
                insight = f"Based on your current trend, you're likely to exceed your monthly budget by ₹{round(avg_monthly * 0.2, 2)}. Consider reducing discretionary expenses."
            elif recent_trend < -0.1:
                insight = "Great job! Your spending is trending downward. Consider maintaining this pattern."
            else:
                insight = "Your spending is relatively stable. Consider setting specific savings goals."
            
            return {
                "predictions": predictions,
                "insight": insight,
                "trend_direction": "increasing" if recent_trend > 0 else "decreasing" if recent_trend < 0 else "stable"
            }
            
        except Exception as e:
            return {"predictions": [], "insight": f"Forecast error: {str(e)}"}
    
    def _generate_saving_recommendations(self, category_totals: Dict[str, float], merchant_totals: Dict[str, float]) -> List[str]:
        """Generate personalized saving recommendations."""
        recommendations = []
        
        # Analyze highest spending categories
        if category_totals:
            top_category = max(category_totals.items(), key=lambda x: x[1])
            if top_category[1] > sum(category_totals.values()) * 0.3:  # More than 30% of total
                recommendations.append(f"Focus on reducing {top_category[0]} expenses - it accounts for {round(top_category[1]/sum(category_totals.values())*100, 1)}% of your spending")
        
        # Analyze merchant patterns
        if merchant_totals:
            top_merchant = max(merchant_totals.items(), key=lambda x: x[1])
            if top_merchant[1] > sum(merchant_totals.values()) * 0.2:  # More than 20% of total
                recommendations.append(f"Consider alternatives to {top_merchant[0]} - you spend ₹{top_merchant[1]:.2f} there")
        
        # General recommendations
        if len(recommendations) < 3:
            recommendations.extend([
                "Set up a monthly budget and track your expenses",
                "Look for discounts and loyalty programs at your frequent merchants",
                "Consider bulk purchasing for non-perishable items"
            ])
        
        return recommendations[:3]  # Return top 3 recommendations
    
    def generate_charts(self, insights: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate interactive charts using Plotly.
        
        Args:
            insights (Dict): Processed spending insights
            
        Returns:
            Dict: Chart data for frontend rendering
        """
        try:
            charts = {}
            
            # 1. Monthly Spending Trend Chart
            monthly_totals = insights.get("monthly_trends", {}).get("monthly_totals", {})
            if monthly_totals:
                months = list(monthly_totals.keys())
                amounts = list(monthly_totals.values())
                
                charts["monthly_trend"] = {
                    "type": "line",
                    "data": {
                        "x": months,
                        "y": amounts,
                        "mode": "lines+markers",
                        "name": "Monthly Spending",
                        "line": {"color": "#4285f4", "width": 4, "shape": "spline"},
                        "marker": {"size": 10, "color": "#4285f4", "line": {"color": "white", "width": 2}}
                    },
                    "layout": {
                        "title": {"text": "Monthly Spending Trend", "font": {"size": 16, "color": "#1a1a1a"}},
                        "xaxis": {
                            "title": {"text": "Month", "font": {"size": 12, "color": "#666"}},
                            "showgrid": False,
                            "zeroline": False,
                            "tickfont": {"size": 11, "color": "#666"}
                        },
                        "yaxis": {
                            "title": {"text": "Amount (₹)", "font": {"size": 12, "color": "#666"}},
                            "showgrid": False,
                            "zeroline": False,
                            "tickfont": {"size": 11, "color": "#666"}
                        },
                        "template": "plotly_white",
                        "height": 300,
                        "margin": {"l": 50, "r": 30, "t": 50, "b": 50},
                        "plot_bgcolor": "rgba(0,0,0,0)",
                        "paper_bgcolor": "rgba(0,0,0,0)",
                        "showlegend": False
                    }
                }
            
            # 2. Category Breakdown Pie Chart
            category_totals = insights.get("category_breakdown", {}).get("totals", {})
            if category_totals:
                charts["category_pie"] = {
                    "type": "pie",
                    "data": {
                        "labels": list(category_totals.keys()),
                        "values": list(category_totals.values()),
                        "hole": 0.4,
                        "marker": {"colors": list(self.colors.values())[:len(category_totals)]},
                        "textinfo": "percent+label",
                        "textposition": "outside",
                        "textfont": {"size": 11, "color": "#666"}
                    },
                    "layout": {
                        "title": {"text": "Spending by Category", "font": {"size": 16, "color": "#1a1a1a"}},
                        "template": "plotly_white",
                        "height": 300,
                        "margin": {"l": 30, "r": 30, "t": 50, "b": 30},
                        "plot_bgcolor": "rgba(0,0,0,0)",
                        "paper_bgcolor": "rgba(0,0,0,0)",
                        "showlegend": False
                    }
                }
            
            # 3. Top Merchants Bar Chart
            merchant_totals = insights.get("merchant_insights", {}).get("merchant_totals", {})
            if merchant_totals:
                top_merchants = sorted(merchant_totals.items(), key=lambda x: x[1], reverse=True)[:10]
                merchants = [item[0] for item in top_merchants]
                amounts = [item[1] for item in top_merchants]
                
                charts["top_merchants"] = {
                    "type": "bar",
                    "data": {
                        "x": merchants,
                        "y": amounts,
                        "marker": {"color": "#34a853"}
                    },
                    "layout": {
                        "title": "Top Merchants by Spending",
                        "xaxis": {"title": "Merchant"},
                        "yaxis": {"title": "Amount (₹)"},
                        "template": "plotly_white",
                        "height": 400
                    }
                }
            
            return charts
            
        except Exception as e:
            print(f"❌ Error generating charts: {e}")
            return {}
    
    def generate_dashboard_data(self) -> Dict[str, Any]:
        """
        Generate complete dashboard data including insights and charts.
        
        Returns:
            Dict: Complete dashboard data
        """
        try:
            # Fetch data from Firestore
            analysis_data = self.fetch_spending_analysis()
            
            if not analysis_data:
                return {"error": "No spending analysis data available"}
            
            # Process insights
            insights = self.process_spending_data(analysis_data)
            
            # Generate charts
            charts = self.generate_charts(insights)
            
            # Combine all data
            dashboard_data = {
                "insights": insights,
                "charts": charts,
                "raw_data": analysis_data,
                "generated_at": datetime.now().isoformat()
            }
            
            return dashboard_data
            
        except Exception as e:
            print(f"❌ Error generating dashboard data: {e}")
            return {"error": f"Failed to generate dashboard: {str(e)}"}

# Convenience functions for API integration
def get_spending_dashboard(credentials_path: str = None) -> Dict[str, Any]:
    """
    Get complete spending dashboard data.
    
    Args:
        credentials_path (str): Path to Google Cloud credentials file (optional)
        
    Returns:
        Dict: Complete dashboard data
    """
    try:
        # Use default path if none provided
        if credentials_path is None:
            credentials_path = "project-rasheed-466518-5cdff45af981.json"
        
        analyzer = SpendingAnalyzer(credentials_path)
        return analyzer.generate_dashboard_data()
    except Exception as e:
        print(f"❌ Error in get_spending_dashboard: {e}")
        return {"error": f"Failed to generate dashboard: {str(e)}"}

def get_spending_insights(credentials_path: str = None) -> Dict[str, Any]:
    """
    Get spending insights only.
    
    Args:
        credentials_path (str): Path to Google Cloud credentials file (optional)
        
    Returns:
        Dict: Spending insights
    """
    try:
        # Use default path if none provided
        if credentials_path is None:
            credentials_path = "project-rasheed-466518-5cdff45af981.json"
        
        analyzer = SpendingAnalyzer(credentials_path)
        analysis_data = analyzer.fetch_spending_analysis()
        
        if not analysis_data:
            return {"error": "No spending analysis data available"}
        
        return analyzer.process_spending_data(analysis_data)
    except Exception as e:
        print(f"❌ Error in get_spending_insights: {e}")
        return {"error": f"Failed to generate insights: {str(e)}"}

if __name__ == "__main__":
    # Test the spending analyzer
    print("🔍 Testing Spending Analyzer...")
    
    analyzer = SpendingAnalyzer()
    dashboard_data = analyzer.generate_dashboard_data()
    
    if "error" not in dashboard_data:
        print("✅ Dashboard data generated successfully!")
        print(f"📊 Total receipts: {dashboard_data['insights']['summary_metrics']['total_receipts']}")
        print(f"💰 Total spending: ₹{dashboard_data['insights']['summary_metrics']['total_spending']:,.2f}")
        print(f"📈 Trend direction: {dashboard_data['insights']['monthly_trends']['trend_direction']}")
    else:
        print(f"❌ Error: {dashboard_data['error']}")
