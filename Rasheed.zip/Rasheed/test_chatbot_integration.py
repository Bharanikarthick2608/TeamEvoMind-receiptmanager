#!/usr/bin/env python3
"""
Test script for the Intelligent Receipt Management Assistant integration.
This script tests the chatbot endpoints and functionality.
"""

import requests
import json
import time

def test_chatbot_health():
    """Test the chatbot health endpoint."""
    print("🔍 Testing chatbot health endpoint...")
    
    try:
        response = requests.get("http://localhost:8000/api/chat/health")
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Chatbot health check passed: {data}")
            return True
        else:
            print(f"❌ Chatbot health check failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Error testing chatbot health: {e}")
        return False

def test_chatbot_text_input():
    """Test the chatbot text input functionality."""
    print("🔍 Testing chatbot text input...")
    
    try:
        response = requests.post(
            "http://localhost:8000/api/chat/process_speech",
            json={"text": "Hello, can you help me with my spending analysis?"},
            headers={"Content-Type": "application/json"}
        )
        
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Chatbot text input test passed")
            print(f"📝 Response: {data.get('assistant_message', 'No message')[:100]}...")
            print(f"🎵 Audio file: {data.get('audio_filename', 'No audio')}")
            return True
        else:
            print(f"❌ Chatbot text input test failed: {response.status_code}")
            print(f"Error: {response.text}")
            return False
    except Exception as e:
        print(f"❌ Error testing chatbot text input: {e}")
        return False

def test_main_health():
    """Test the main API health endpoint."""
    print("🔍 Testing main API health endpoint...")
    
    try:
        response = requests.get("http://localhost:8000/api/health")
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Main API health check passed")
            print(f"🤖 Chatbot status: {data.get('chatbot', {}).get('status', 'Unknown')}")
            return True
        else:
            print(f"❌ Main API health check failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Error testing main API health: {e}")
        return False

def main():
    """Run all tests."""
    print("🚀 Starting Intelligent Receipt Management Assistant Integration Tests")
    print("=" * 70)
    
    # Wait a moment for the server to be ready
    print("⏳ Waiting for server to be ready...")
    time.sleep(2)
    
    tests = [
        ("Main API Health", test_main_health),
        ("Chatbot Health", test_chatbot_health),
        ("Chatbot Text Input", test_chatbot_text_input),
    ]
    
    passed = 0
    total = len(tests)
    
    for test_name, test_func in tests:
        print(f"\n📋 Running: {test_name}")
        if test_func():
            passed += 1
        else:
            print(f"❌ {test_name} failed")
    
    print("\n" + "=" * 70)
    print(f"📊 Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! The Intelligent Receipt Management Assistant is working correctly.")
    else:
        print("⚠️  Some tests failed. Please check the server logs and configuration.")
    
    print("\n💡 To test the full functionality:")
    print("   1. Start the server: python Backend/app_backend.py")
    print("   2. Open: http://localhost:8000/app.html")
    print("   3. Navigate to 'Intelligent Assistant' in the sidebar")
    print("   4. Try voice or text input!")

if __name__ == "__main__":
    main() 